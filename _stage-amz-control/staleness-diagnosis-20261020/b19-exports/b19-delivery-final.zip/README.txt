商品套图交付包

项目：真实闭环 · 参考图
生成时间：2026-10-20T03:51:56.676Z
包含图片：5 张（每张一个已采用候选）

清单：
- 主图·干净背景：images/shot_main_clean-act-02f239357376473d9aa7ff9c8e419cb7.png（candidate act-02f239357376473d9aa7ff9c8e419cb7 · sha256 4c8c68cf7a0a…）
- 卖点信息图：images/shot_infographic_benefits-act-893b00e5ab0a4679b026d4aac1a70ca8.png（candidate act-893b00e5ab0a4679b026d4aac1a70ca8 · sha256 2fa38cd63646…）
- 场景图·使用中：images/shot_scene_lifestyle-act-46bd1c08babc460f84f202a546fd8921.png（candidate act-46bd1c08babc460f84f202a546fd8921 · sha256 1655f53cc27c…）
- 细节图·材质工艺：images/shot_detail_material-act-021de106771a476681ffd399565d4ab0.png（candidate act-021de106771a476681ffd399565d4ab0 · sha256 ea50b044b790…）
- 尺寸图：images/shot_size_dimensions-act-d2f33b438dac4a9b806035a4a298bf97.png（candidate act-d2f33b438dac4a9b806035a4a298bf97 · sha256 5e0f06aff41b…）

manifest.json 记录每张图的来源与指纹；checks.json 记录门禁与审核发现。
本包只包含已采用的候选；未采用候选与完整历史请用「导出项目包」。