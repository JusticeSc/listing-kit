#!/usr/bin/env python
"""V2.4.4 证据：候选字节流、Blob 持久化与容量管理（0 次真实模型调用）。

检查：
  1) domain / workspace / harness 通过 node --check（ESM 语法门）。
  2) C01..C10 契约套件在真实 Chromium 全过；既有契约套件回归全过。
  3) 单张生成到成功时自动取回字节：候选记录绑定来源 action/task；asset 里同 sha 的
     Blob 存在；界面出现预览与 sha256/尺寸元信息。
  4) Blob hash：IndexedDB 字节重算 sha256 == 候选记录 == 响应头 X-Image-Sha256；
     媒体信息（64×64 PNG、字节数）与字节本身一致。
  5) 刷新预览：刷新后候选不重复、不重新下载，预览从 IndexedDB 恢复（naturalWidth>0）。
  6) 取回失败一次：候选未保存、批次提示给出原因与下一步、不产生半份记录；
     停止新增提交后按提示手动保存成功且 sha 稳定。
  7) 配额异常：批次立即停（不空转）、没有半份记录、提示给可恢复指引；
     清出空间（解除注入）后手动重试成功。
  8) 整套批次：剩余图片自动保存候选，进度含「已成功 4」且无「待保存候选」残留。
  9) 零意外 console error / page error；截图落盘；正式入口 --check 全过。

运行：
  uv run --locked python tools/verify_v2_4_4_candidate_blob.py
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import zlib
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import v2_stage_nav as stage_nav  # noqa: E402  （V2.UI.2 六阶段工作台导航）
import v2_verify_shared as shared  # noqa: E402  （正式 server/夹具/共同业务操作）
from v2_verify_shared import (  # noqa: E402
    png_bytes, run_entry, read_suite, compile_all,
)


PRODUCT_DIR = ROOT / "app" / "product_v2"
HARNESS_DIR = ROOT / "evals" / "product-v2" / "harness"
EVIDENCE_DIR = ROOT / "evals" / "product-v2"

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
}

DOMAIN_FILES = [
    "app/product_v2/domain/shared.js",
    "app/product_v2/domain/errors.js",
    "app/product_v2/domain/slots.js",
    "app/product_v2/domain/intake.js",
    "app/product_v2/domain/brief.js",
    "app/product_v2/domain/invalidation.js",
    "app/product_v2/domain/suite-plan.js",
    "app/product_v2/domain/suite.js",
    "app/product_v2/domain/specs.js",
    "app/product_v2/domain/prompt.js",
    "app/product_v2/domain/confirm.js",
    "build/frontend-node/app/product_v2/domain/attempt.js",
    "app/product_v2/domain/batch.js",
    "app/product_v2/domain/candidate.js",
    "app/product_v2/domain/index.js",
    "app/product_v2/workspace.js",
    "evals/product-v2/harness/candidate-contract.js",
]

EXPECTED_CASES = [f"C{index:02d}" for index in range(1, 11)]
NEGATIVE_CASES = ["C02", "C04", "C10"]
REGRESSION_SUITES = (
    ("attempt", "attempt-contract.html", "__V2_ATTEMPT_RESULTS__"),
    ("batch", "batch-contract.html", "__V2_BATCH_RESULTS__"),
    ("confirm", "confirm-contract.html", "__V2_CONFIRM_RESULTS__"),
    ("prompt_edit", "prompt-edit-contract.html", "__V2_PROMPT_EDIT_RESULTS__"),
    ("suite_editor", "suite-editor-contract.html", "__V2_SUITE_EDITOR_RESULTS__"),
)







def run_node_checks() -> dict:
    results = []
    for relative in DOMAIN_FILES:
        completed = subprocess.run(["node", "--check", str(ROOT / relative)],
                                   cwd=str(ROOT), capture_output=True, text=True, check=False)
        results.append({"file": relative, "rc": completed.returncode,
                        "stderr": completed.stderr.strip()[-200:]})
    return {"files": results, "ok": all(item["rc"] == 0 for item in results)}





SEED_SLOTS = """
async (projectId) => {
  const domain = await import("/domain/index.js");
  const storage = await import("/storage/index.js");
  const opened = await storage.openStorage({});
  try {
    const repository = opened.repository;
    const slot = (slotId, value) => {
      const definition = domain.coreSlotDefinition(slotId);
      return {
        schema_version: 1, slot_id: slotId, label: definition.label,
        authority: "core_fixed", value_type: definition.value_type,
        critical: definition.critical, value: value, source: "user_input",
        status: "confirmed", confidence: null,
        evidence: [{ kind: "user", ref: "v244-seed" }], depends_on: [],
      };
    };
    await repository.documents.save(projectId, {
      kind: "fact_slot", documentId: "product_name", payload: slot("product_name", "便携保温杯"),
    });
    await repository.documents.save(projectId, {
      kind: "fact_slot", documentId: "product_category", payload: slot("product_category", "保温杯"),
    });
    await repository.documents.save(projectId, {
      kind: "fact_slot", documentId: "signature_features",
      payload: slot("signature_features", ["304不锈钢内胆", "12小时保温"]),
    });
    return { slots: 3 };
  } finally {
    opened.close();
  }
}
"""

PROBE = """
async () => {
  const db = await new Promise((resolve, reject) => {
    const request = indexedDB.open("amz-listing-kit-v2");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  const read = (store) => new Promise((resolve, reject) => {
    const request = db.transaction(store, "readonly").objectStore(store).getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  const documents = await read("documents");
  const projects = await read("projects");
  const assets = await read("assets");
  db.close();
  const chains = {};
  for (const item of documents.filter((row) => row.kind === "generation_attempt")) {
    (chains[item.document_id] = chains[item.document_id] || []).push({
      version: item.version, payload: item.payload,
    });
  }
  for (const key of Object.keys(chains)) {
    chains[key].sort((left, right) => left.version - right.version);
  }
  const candidates = {};
  for (const item of documents.filter((row) => row.kind === "candidate")) {
    (candidates[item.document_id] = candidates[item.document_id] || []).push({
      version: item.version, payload: item.payload,
    });
  }
  for (const key of Object.keys(candidates)) {
    candidates[key].sort((left, right) => left.version - right.version);
  }
  const plans = documents.filter((item) => item.kind === "suite_plan")
    .sort((left, right) => left.version - right.version);
  const plan = plans.length ? plans[plans.length - 1] : null;
  const rows = [...document.querySelectorAll("#attempt-list .attempt-row")].map((node) => {
    const img = node.querySelector(".attempt-preview img");
    const candidateMeta = node.querySelector(".attempt-candidate");
    return {
      shot_id: node.getAttribute("data-shot-id"),
      state: node.getAttribute("data-attempt-state"),
      badges: [...node.querySelectorAll(".badge")].map((item) => item.textContent),
      meta: [...node.querySelectorAll("p.meta")].map((item) => item.textContent).join(" | "),
      candidate_meta: candidateMeta ? candidateMeta.textContent : null,
      preview: img ? {
        src: img.getAttribute("src") || "",
        complete: img.complete,
        natural_width: img.naturalWidth,
      } : null,
      buttons: [...node.querySelectorAll("button")].map((item) =>
        ({ text: item.textContent, disabled: item.disabled })),
    };
  });
  const errorNode = document.getElementById("attempt-error");
  const progressNode = document.getElementById("batch-progress");
  const hintNode = document.getElementById("batch-hint");
  return {
    project_ids: projects.map((item) => item.project_id),
    shot_ids: plan ? plan.payload.shots.map((shot) => shot.shot_id) : [],
    attempt_chains: chains,
    candidate_chains: candidates,
    asset_rows: assets.map((item) => ({
      sha256: item.sha256, media_type: item.media_type, byte_size: item.byte_size,
      width: item.width, height: item.height, role: item.role,
      has_blob: item.blob instanceof Blob,
    })),
    ui: {
      error: errorNode ? errorNode.textContent : "",
      error_hidden: errorNode ? errorNode.hidden : true,
      rows: rows,
      batch: {
        progress: progressNode ? progressNode.textContent : "",
        hint: hintNode ? hintNode.textContent : "",
      },
    },
  };
}
"""

HASH_ASSET = """
async ({ sha256 }) => {
  const db = await new Promise((resolve, reject) => {
    const request = indexedDB.open("amz-listing-kit-v2");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  const rows = await new Promise((resolve, reject) => {
    const request = db.transaction("assets", "readonly").objectStore("assets").getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  db.close();
  const record = rows.find((item) => item.sha256 === sha256);
  if (!record || !(record.blob instanceof Blob)) return { found: false };
  const buffer = await record.blob.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  const hex = Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0")).join("");
  return {
    found: true, sha256: hex, byte_size: buffer.byteLength,
    media_type: record.media_type, width: record.width, height: record.height,
    role: record.role,
  };
}
"""

# 配额故障注入：只拦 assets 仓的 add，把 DOMException 伪装成浏览器配额耗尽。
# 产品代码不需要任何测试钩子——故障发生在 IndexedDB 协议层，走真实错误转译路径。
INSTALL_IDB_FAULT = """
() => {
  if (window.__v244Patched) return true;
  const original = IDBObjectStore.prototype.add;
  IDBObjectStore.prototype.add = function (...args) {
    if (window.__v244FailAssetWrites && this.name === "assets") {
      throw new DOMException("simulated quota", "QuotaExceededError");
    }
    return original.apply(this, args);
  };
  window.__v244Patched = true;
  return true;
}
"""

SET_IDB_FAULT = """
(fail) => {
  window.__v244FailAssetWrites = Boolean(fail);
  return window.__v244FailAssetWrites;
}
"""

MARK_FETCH_FAIL = "MARK-FETCH-FAIL-V244"


def save_edit(page, shot_id: str, text: str, reason: str, wait_ms: int = 600) -> None:
    card = f'#prompt-list .shot-spec[data-shot-id="{shot_id}"]'
    page.fill(card + " textarea.prompt-edit-text", text)
    page.fill(card + " input.prompt-edit-reason", reason)
    page.click(card + " .prompt-edit-block button")
    page.wait_for_timeout(wait_ms)


def append_prompt_mark(page, shot_id: str, mark: str, reason: str) -> None:
    card = f'#prompt-list .shot-spec[data-shot-id="{shot_id}"]'
    current = page.input_value(card + " textarea.prompt-edit-text")
    save_edit(page, shot_id, current + "\n\n" + mark + "：这张图的取回场景由验证器决定。", reason)


def chain_of(data: dict, shot_id: str) -> list:
    return data["attempt_chains"].get(shot_id, [])


def candidate_of(data: dict, shot_id: str) -> list:
    return data["candidate_chains"].get(shot_id, [])


def row_of(data: dict, shot_id: str) -> dict | None:
    return next((row for row in data["ui"]["rows"] if row["shot_id"] == shot_id), None)


def chain_json(data: dict, shot_id: str) -> str:
    return json.dumps(chain_of(data, shot_id), ensure_ascii=False, sort_keys=True)


def candidate_json(data: dict, shot_id: str) -> str:
    return json.dumps(candidate_of(data, shot_id), ensure_ascii=False, sort_keys=True)


BOOT_GATE_JS = """() => {
    const el = (id) => document.getElementById(id);
    const pending = el('boot-pending');
    const error = el('boot-error');
    const projectView = el('project-view');
    const create = el('new-project-name');
    const bootError = Boolean(error && !error.hidden
        && (error.textContent || '').trim().length > 0);
    return Boolean(pending && pending.hidden && !bootError
        && ((create && !create.disabled)
            || (projectView && !projectView.hidden)));
}"""


def _boot_snapshot(page) -> dict:
    """UI 启动门各里程碑的当前快照：只读 DOM 状态，不读任何业务/秘密内容。"""
    try:
        return dict(page.evaluate("""() => {
            const el = (id) => document.getElementById(id);
            const text = (id) => (el(id) || {}).textContent || '';
            return {
                ready_state: document.readyState,
                url: location.href,
                boot_pending_hidden: el('boot-pending') ? el('boot-pending').hidden : null,
                boot_error: text('boot-error').slice(0, 500),
                boot_error_hidden: el('boot-error') ? el('boot-error').hidden : null,
                create_visible: el('new-project-name')
                    ? !el('new-project-name').hidden : null,
                create_disabled: el('new-project-name')
                    ? el('new-project-name').disabled : null,
                project_view_hidden: el('project-view') ? el('project-view').hidden : null,
                scripts: [...document.scripts].map((item) =>
                    (item.src || '(inline)').slice(-120)).slice(0, 12),
            };
        }"""))
    except Exception as error:  # noqa: BLE001 - 诊断快照失败本身也是证据
        return {"snapshot_error": f"{type(error).__name__}: {error}"}


def _redact_url(url: str) -> str:
    """诊断只保留同源路径与查询键名，不保留任何查询值/凭据/业务内容。"""
    try:
        parts = urllib.parse.urlsplit(url or "")
        keys = sorted({key for key, _ in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)})
        query = ("?" + ",".join(keys)) if keys else ""
        return f"{parts.scheme}://{parts.netloc}{parts.path}{query}"
    except Exception:  # noqa: BLE001 - URL 形状异常时退回空占位，不丢整条诊断
        return "<unparseable-url>"


class BootCausalObserver:
    """RC19 因果诊断：本地显式验证 host 的单调时钟事件关联。

    只记录本地回环验证 host 的 bind/listen/accept/请求处理进入与完成/关闭、
    浏览器导航目标/实际 URL/requestfailed/response 与 UI 启动门里程碑。
    只记方法/路径/状态与诊断标识，不记 key、请求体或商品图片内容。
    诊断能力与机制修复分开：本类只证明“观测到什么”，不声称根因。
    """

    def __init__(self) -> None:
        self.origin = time.monotonic()
        self.lock = threading.Lock()
        self.server_events: list[dict] = []
        self.browser_events: list[dict] = []
        self.attempts: list[dict] = []

    def now_ms(self) -> float:
        return round((time.monotonic() - self.origin) * 1000.0, 3)

    def server(self, kind: str, **fields) -> None:
        event = {"t_ms": self.now_ms(), "kind": kind}
        event.update(fields)
        with self.lock:
            self.server_events.append(event)

    def browser(self, kind: str, **fields) -> None:
        event = {"t_ms": self.now_ms(), "kind": kind}
        event.update(fields)
        with self.lock:
            self.browser_events.append(event)

    def failing_attempts(self) -> list[dict]:
        return [item for item in self.attempts if not item.get("ready")]

    def first_failure(self) -> dict | None:
        failures = self.failing_attempts()
        return dict(failures[0]) if failures else None

    def window(self, start_ms: float, end_ms: float) -> dict:
        with self.lock:
            server = [event for event in self.server_events
                      if start_ms <= float(event.get("t_ms", 0.0)) <= end_ms]
            browser = [event for event in self.browser_events
                       if start_ms <= float(event.get("t_ms", 0.0)) <= end_ms]
        return {"server_events": server, "browser_events": browser}

    def causal_branch(self, attempt: dict) -> str:
        """§11.6.2 四条显式诊断分支；无法区分时如实返回 unknown 缺观测。"""
        window = self.window(float(attempt.get("start_ms", 0.0)),
                             float(attempt.get("end_ms", 0.0)))
        accepted = [event for event in window["server_events"]
                    if event.get("kind") == "accept"]
        started = [event for event in window["server_events"]
                   if event.get("kind") == "request_start"]
        finished = [event for event in window["server_events"]
                    if event.get("kind") == "request_finish"]
        ready_wait_failed = attempt.get("phase") == "ready_wait"
        navigation_failed = attempt.get("phase") == "navigation"
        if not accepted and not started:
            if navigation_failed:
                return "no_accept_navigation_failed"
            return "no_accept_ready_failed"
        if started and not finished:
            return "accepted_unfinished"
        if finished and ready_wait_failed:
            return "responded_ui_not_ready"
        if navigation_failed:
            return "navigation_failed_with_server_trace"
        return "unknown_missing_discriminating_observation"

    def summary(self) -> dict:
        first = self.first_failure()
        branch = self.causal_branch(first) if first else "no_failure_observed"
        return {
            "attempts": [dict(item) for item in self.attempts],
            "first_failure": first,
            "causal_branch": branch,
            "server_event_count": len(self.server_events),
            "browser_event_count": len(self.browser_events),
            "server_events": [dict(item) for item in self.server_events],
            "browser_events": [dict(item) for item in self.browser_events],
        }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="V2.4.4 候选字节流、Blob 持久化与容量管理验证")
    parser.add_argument("--label", default="")
    parser.add_argument("--boot-diagnostic", default="",
                        choices=["", "disabled-listener", "stalled-response", "stalled-ui-boot"],
                        help="仅用于单独验证启动诊断判红能力：关闭监听/卡住响应/卡住 UI 启动各一次，不进入 CI 默认路径。")
    args = parser.parse_args()

    from playwright.sync_api import expect, sync_playwright  # noqa: PLC0415

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    checks: list[dict] = []
    console_errors: list[str] = []
    page_errors: list[str] = []
    screenshots: list[str] = []

    def check(check_id: str, title: str, ok: bool, detail: object = None) -> None:
        checks.append({"id": check_id, "title": title, "ok": bool(ok), "detail": detail})

    node_result = run_node_checks()
    check("V2.4.4-00", "domain / workspace / harness 通过 node --check（ESM 语法门）",
          node_result["ok"],
          {"failed": [item for item in node_result["files"] if item["rc"] != 0][:3]})

    static_server, static_url = shared.start_static_server()
    suites: dict = {}
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            try:
                suites["candidate"] = read_suite(
                    browser, static_url + "/harness/candidate-contract.html",
                    "__V2_CANDIDATE_RESULTS__", console_errors, page_errors)
                for name, page_name, variable in REGRESSION_SUITES:
                    suites[name] = read_suite(
                        browser, static_url + "/harness/" + page_name, variable,
                        console_errors, page_errors)
            finally:
                browser.close()
    finally:
        static_server.stop()

    suite = suites["candidate"]
    case_ids = [item["id"] for item in suite.get("cases", [])]
    missing = [case for case in EXPECTED_CASES if case not in case_ids]
    failed_cases = [item for item in suite.get("cases", []) if not item.get("ok")]
    check("V2.4.4-01", "C01–C10 契约套件全过且用例齐全",
          suite.get("status") == "passed" and not missing and not failed_cases,
          {"status": suite.get("status"), "missing": missing,
           "failed": [{"id": item["id"], "error": item.get("error")} for item in failed_cases[:3]]})
    negative_seen = [case for case in NEGATIVE_CASES if case in case_ids]
    check("V2.4.4-02", "反向探针确实执行（坏 PNG / 非法身份 / 兼容性参数）",
          negative_seen == NEGATIVE_CASES and not failed_cases,
          {"expected": NEGATIVE_CASES, "seen": negative_seen})
    regression = {name: {"status": value.get("status"), "failed": value.get("failed_ids", [])}
                  for name, value in suites.items() if name != "candidate"}
    check("V2.4.4-02b", "既有契约套件回归：Attempt / 批次 / 确认单 / Prompt 编辑 / 套图编辑器全过",
          all(item["status"] == "passed" and not item["failed"] for item in regression.values()),
          regression)

    from app.product_v2_http import ProductV2Server  # noqa: PLC0415
    from app.product_v2_server import create_app  # noqa: PLC0415
    from src.providers.v2_fake_image import FakeImageProvider  # noqa: PLC0415
    from src.providers.v2_fake_semantic import FakeSemanticProvider  # noqa: PLC0415
    from src.providers.v2_image import ImageFailure, ImageTaskResult  # noqa: PLC0415

    mode: dict = {"tasks": {}, "fetch_fault": False}

    class MarkerImageProvider(FakeImageProvider):
        """按 Prompt 标记决定这张图的取回场景；替身保持无状态：场景表放在验证器里。"""

        def submit(self, request):
            self.calls["submit"] += 1
            prompt = request.prompt or ""
            task_id = FakeImageProvider.task_id_for(request.action_id)
            if MARK_FETCH_FAIL in prompt:
                mode["tasks"][task_id] = "fetch_fail"
            return ImageTaskResult(
                provider_id=self.provider_id, model_id=self.model_id,
                task_id=task_id, status="RUNNING")

        def result(self, request):
            self.calls["result"] += 1
            # 取回故障在验证器解除前一直生效：批次会自动重试取回，只失败一次的话
            # 产品在第一轮就重试成功，用户根本看不到失败（实测 progress 已成功 5/待提交 0）。
            if mode["fetch_fault"] and mode["tasks"].get(request.task_id) == "fetch_fail":
                raise ImageFailure(
                    "provider_failed", "RESULT_DOWNLOAD_FAILED",
                    "结果图片下载失败；没有产生可用的候选字节。",
                    retry_policy="retryable")
            return FakeImageProvider.result(self, request)

    boot_observer = BootCausalObserver()
    image_provider = MarkerImageProvider(scenario="ok")

    class BootObserverMiddleware:
        """启动诊断观测：只看 ASGI 边界，不改产品语义。

        P3 换框架后不再包装标准库 socketserver 的内部方法（get_request/finish_request
        等已不存在）；观测点改为 ASGI 边界，事件含义保持同族：
        ``accept``/``request_start`` = 连接已被服务器接收并进入应用，
        ``request_finish`` = 该请求处理结束。
        """

        def __init__(self, app, observer) -> None:
            self.app = app
            self.observer = observer
            self.stall_next = False

        async def __call__(self, scope, receive, send) -> None:
            if scope.get("type") != "http":
                await self.app(scope, receive, send)
                return
            path = str(scope.get("path", ""))
            if self.stall_next:
                self.stall_next = False
                self.observer.server("injected_stalled_response", path=path)
                await asyncio.sleep(35)
            self.observer.server("accept", path=path,
                                 active_threads=threading.active_count())
            self.observer.server("request_start", path=path,
                                 active_threads=threading.active_count())
            try:
                await self.app(scope, receive, send)
            finally:
                self.observer.server("request_finish", path=path,
                                     active_threads=threading.active_count())

    observer_app = BootObserverMiddleware(create_app(
        provider_factory=lambda: FakeSemanticProvider(scenario="ok"),
        image_provider_factory=lambda: image_provider), boot_observer)
    server = ProductV2Server(observer_app, "127.0.0.1", 0)
    server.start()
    actual_host, actual_port = server.host, server.port
    assert int(actual_port) != 0, "验证 host 必须读回 0 号端口分配的真实端口"
    base = server.base_url
    boot_observer.server("bind", host=actual_host, port=actual_port, listening=True)
    boot_observer.server("serve_start", host=actual_host, port=actual_port, base=base,
                         running=server.running)
    if args.boot_diagnostic == "disabled-listener":
        # 受控红证明：显式关闭监听，浏览器建连必须失败且诊断保留 no_accept 分支。
        boot_observer.server("injected_disabled_listener", base=base)
        server.stop()
        boot_observer.server("listener_closed", running=server.running)
    elif args.boot_diagnostic == "stalled-response":
        # 受控红证明：只让本验证 host 第一次请求前显式等待 35 秒。
        # 35 秒超过默认导航超时（30 秒），第一次 goto 必因超时失败并留下首失败；
        # 第二次尝试不再延迟、正常成功，证明“重试成功不关闭首个失败”。
        observer_app.stall_next = True
    submit_requests: list[dict] = []
    status_requests: list[str] = []
    result_requests: list[dict] = []
    ui: dict = {}
    stage = "setup"
    interrupted: str | None = None
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    temp_root = Path(tempfile.mkdtemp(prefix="amz-v244-"))
    profile = temp_root / "profile"
    reference = temp_root / "ref.png"
    reference.write_bytes(png_bytes(16, 16, (36, 92, 160)))

    try:
        with sync_playwright() as pw:
            context = pw.chromium.launch_persistent_context(
                str(profile), headless=True, viewport={"width": 1280, "height": 980})
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.on("console", lambda message: console_errors.append(message.text)
                        if message.type == "error" else None)
                page.on("pageerror", lambda error: page_errors.append(str(error)))
                if args.boot_diagnostic == "stalled-ui-boot":
                    # 受控红证明：响应正常到达，但页面启动门永远不满足（pending 保持可见）。
                    # 用 context 级 init script 把 hidden 钉死为 false：产品 boot 代码仍原样
                    # 运行到 hidden=true 写出，只是写出不生效，门条件永远不成立。
                    # page 级 add_init_script 在持久 context 下不生效，必须用 context 级注册。
                    context.add_init_script("""
                        const pin = () => {
                            const pending = document.getElementById('boot-pending');
                            if (!pending) return false;
                            pending.hidden = false;
                            try {
                                Object.defineProperty(pending, 'hidden', {
                                    configurable: true, get: () => false, set: () => {},
                                });
                            } catch (err) { /* 钉死失败则保持单次写回 */ }
                            return true;
                        };
                        if (document.documentElement) {
                            if (!pin()) {
                                new MutationObserver((_, observer) => {
                                    if (pin()) observer.disconnect();
                                }).observe(document.documentElement, {childList: true, subtree: true});
                            }
                        } else {
                            document.addEventListener('DOMContentLoaded', () => {
                                if (!pin() && document.documentElement) {
                                    new MutationObserver((_, observer) => {
                                        if (pin()) observer.disconnect();
                                    }).observe(document.documentElement, {childList: true, subtree: true});
                                }
                            }, {once: true});
                        }
                    """)
                    boot_observer.browser("injected_stalled_ui_boot")


                def payload_of(request) -> dict:
                    try:
                        return json.loads(request.post_data or "{}")
                    except ValueError:
                        return {}

                def on_request(request) -> None:
                    if request.method != "POST":
                        return
                    if "/api/v2/images/submit" in request.url:
                        body = payload_of(request)
                        submit_requests.append({
                            "action_id": body.get("action_id"),
                            "prompt": body.get("prompt"),
                            "size": body.get("size"),
                        })
                    elif "/api/v2/images/status" in request.url:
                        status_requests.append(str(payload_of(request).get("task_id")))
                    elif "/api/v2/images/result" in request.url:
                        result_requests.append({
                            "task_id": str(payload_of(request).get("task_id")),
                            "status": None, "declared_sha": "",
                        })

                def on_response(response) -> None:
                    if "/api/v2/images/result" not in response.url:
                        return
                    task_id = str(payload_of(response.request).get("task_id"))
                    for item in reversed(result_requests):
                        if item["task_id"] == task_id and item["status"] is None:
                            item["status"] = response.status
                            item["declared_sha"] = str(
                                response.headers.get("x-image-sha256") or "").lower()
                            break

                page.on("request", on_request)
                page.on("response", on_response)

                failed_requests: list[str] = []

                def _record_request_failed(request) -> None:
                    text = _redact_url(request.url) + " :: " + str(request.failure)
                    failed_requests.append(text)
                    boot_observer.browser("requestfailed", url=text,
                                          failure=str(request.failure)[:240])

                def _record_response(response) -> None:
                    # 启动诊断只记同源文档/模块响应的状态与 URL 形状，不读正文。
                    try:
                        url = str(response.url)
                    except Exception:  # noqa: BLE001 - 响应对象异常时保留最小可定位信息
                        url = "<unknown-response-url>"
                    if url.startswith(base):
                        boot_observer.browser("response", url=_redact_url(url),
                                              status=response.status)

                page.on("requestfailed", _record_request_failed)
                page.on("response", _record_response)

                # 启动诊断：加载/重载后必须等“启动完成”门；导航异常与 ready 失败都要捕获。
                # 不做环境/产品归因：观测只记录首个失败的 URL、时间、阶段、控制台、
                # requestfailed/response、UI 启动里程碑及同窗 host 事件；后一次成功不关闭首个失败。
                boot_retries: list[str] = []

                def load_page(url: str | None = None, attempts: int = 2) -> None:
                    for attempt in range(attempts):
                        before = len(failed_requests)
                        navigation_target = url if url is not None else page.url
                        attempt_record: dict = {
                            "load": url if url is not None else "<reload>",
                            "attempt": attempt,
                            "navigation_target": _redact_url(navigation_target),
                            "start_ms": boot_observer.now_ms(),
                            "ready": False,
                            "phase": "navigation",
                            "console_tail": list(console_errors[-3:]),
                            "page_error_tail": list(page_errors[-3:]),
                        }
                        boot_observer.browser("navigation_start",
                                              target=attempt_record["navigation_target"],
                                              mode="goto" if url is not None else "reload",
                                              attempt=attempt)
                        try:
                            if url is None:
                                page.reload(wait_until="networkidle")
                            else:
                                page.goto(url, wait_until="networkidle")
                            attempt_record["phase"] = "ready_wait"
                            page.wait_for_function(BOOT_GATE_JS, timeout=20_000)
                            attempt_record["ready"] = True
                            attempt_record["phase"] = "ready"
                            attempt_record["end_ms"] = boot_observer.now_ms()
                            attempt_record["actual_url"] = _redact_url(page.url)
                            attempt_record["boot"] = _boot_snapshot(page)
                            boot_observer.attempts.append(attempt_record)
                            boot_observer.browser(
                                "navigation_ready",
                                actual_url=attempt_record["actual_url"], attempt=attempt)
                            return
                        except Exception as error:  # noqa: BLE001
                            attempt_record["end_ms"] = boot_observer.now_ms()
                            try:
                                attempt_record["actual_url"] = _redact_url(page.url)
                            except Exception:  # noqa: BLE001 - 页面对象已不可用时保留导航前目标
                                attempt_record["actual_url"] = attempt_record["navigation_target"]
                            attempt_record["error"] = (
                                f"{type(error).__name__}: {str(error)[:500]}")
                            attempt_record["boot"] = _boot_snapshot(page)
                            attempt_record["failed_requests"] = list(
                                failed_requests[before:before + 8])
                            attempt_record["server_running"] = server.running
                            attempt_record["server_address"] = [server.host, server.port]
                            window = boot_observer.window(
                                float(attempt_record["start_ms"]),
                                float(attempt_record["end_ms"]))
                            attempt_record["server_events"] = window["server_events"]
                            attempt_record["browser_events"] = window["browser_events"]
                            attempt_record["causal_branch"] = boot_observer.causal_branch(
                                attempt_record)
                            boot_observer.attempts.append(attempt_record)
                            boot_observer.browser(
                                "navigation_failed",
                                phase=attempt_record["phase"],
                                error=attempt_record["error"], attempt=attempt)
                            boot_retries.append(
                                f"attempt={attempt} phase={attempt_record['phase']} "
                                f"{attempt_record['error']} "
                                f"branch={attempt_record['causal_branch']} "
                                f"refused={attempt_record['failed_requests'][:3]}")
                            if attempt == attempts - 1:
                                raise
                            page.wait_for_timeout(500)

                def probe() -> dict:
                    return page.evaluate(PROBE)

                def row(shot_id: str):
                    return page.locator(
                        f'#attempt-list .attempt-row[data-shot-id="{shot_id}"]')

                def wait_state(shot_id: str, state: str, timeout: int = 30_000) -> None:
                    expect(row(shot_id)).to_have_attribute(
                        "data-attempt-state", state, timeout=timeout)

                def wait_states(expectations: dict, timeout: int = 90_000) -> None:
                    page.wait_for_function(
                        """(wanted) => {
                            const rows = [...document.querySelectorAll('#attempt-list .attempt-row')];
                            return Object.entries(wanted).every(([id, state]) => {
                                const node = rows.find((item) =>
                                    item.getAttribute('data-shot-id') === id);
                                return node && node.getAttribute('data-attempt-state') === state;
                            });
                        }""",
                        arg=expectations, timeout=timeout)

                def wait_preview(shot_id: str, timeout: int = 30_000) -> None:
                    # 预览图带 loading="lazy"：先滚动到这一行（用户也会这样做），
                    # 否则刷新后页面停在顶部，图片永远不进入加载队列。
                    page.locator(
                        f'#attempt-list .attempt-row[data-shot-id="{shot_id}"]'
                        " .attempt-preview img"
                    ).scroll_into_view_if_needed(timeout=timeout)
                    page.wait_for_function(
                        """(shot) => {
                            const node = document.querySelector(
                                '#attempt-list .attempt-row[data-shot-id="' + shot + '"]');
                            const img = node && node.querySelector('.attempt-preview img');
                            return Boolean(img && img.complete && img.naturalWidth > 0);
                        }""",
                        arg=shot_id, timeout=timeout)

                def wait_candidate_ui(shot_id: str, timeout: int = 30_000) -> None:
                    # 只等界面上的候选标记（同步谓词）；字节与身份仍由 probe 重新读 IndexedDB 核对。
                    # 注意：wait_for_function 不会等待 async 谓词（Promise 恒为真值），这里必须同步。
                    page.wait_for_function(
                        """(shot) => {
                            const node = document.querySelector(
                                '#attempt-list .attempt-row[data-shot-id="' + shot + '"]');
                            return Boolean(node && node.querySelector('.attempt-candidate'));
                        }""", arg=shot_id, timeout=timeout)

                def wait_hint_contains(text: str, timeout: int = 30_000) -> None:
                    # 批次路径的失败原因在批次提示区（generation-view renderBatch → batchHint），
                    # 不是单张路径的 #attempt-error。
                    try:
                        page.wait_for_function(
                            """(wanted) => {
                                const node = document.getElementById('batch-hint');
                                return Boolean(node && !node.hidden
                                    && node.textContent.includes(wanted));
                            }""", arg=text, timeout=timeout)
                    except Exception as error:  # noqa: BLE001 - 超时也要报出真实观测
                        area = page.evaluate("""() => {
                          const el = (id) => document.getElementById(id);
                          return {
                            hint: (el('batch-hint') || {}).textContent || '',
                            hint_hidden: el('batch-hint') ? el('batch-hint').hidden : null,
                            progress: (el('batch-progress') || {}).textContent || '',
                            error: (el('attempt-error') || {}).textContent || '',
                            status: (el('attempt-status') || {}).textContent || '',
                          };
                        }""")
                        raise AssertionError(f"等待批次提示「{text}」超时：{area}") from error

                def wait_batch_idle(timeout: int = 90_000) -> None:
                    # 批次运行中 renderBatch 会追加「批次进行中：…」；批次结束后只剩计数。
                    # 单张按钮在批次 active 期间是禁用的（generation-view inFlight 含 batchActive），
                    # 所以点「保存候选图片」之前必须等批次真的结束。
                    page.wait_for_function(
                        """() => {
                            const node = document.getElementById('batch-progress');
                            return Boolean(node && !node.textContent.includes('批次进行中'));
                        }""", timeout=timeout)

                def confirm_generation(wanted: list | None = None) -> dict:
                    # 授权集合必须是"本次确认将消费的图"（4_3 同因：禁止复用首批快照，
                    # 否则 confirm_and_submit 在 set(authorized)==set(shot_ids) 恒假）。
                    scope = list(wanted) if wanted is not None else list(probe()["shot_ids"])
                    gate = shared.confirm_and_submit(page, expect, probe, submit_requests,
                                                     shot_ids=scope)
                    assert gate["ok"], f"确认必须产生本次授权的新消费：{gate['after_actions']}"
                    return gate

                def add_shots(template_id: str, count: int = 1) -> list:
                    stage_nav.goto(page, "plan")
                    before = list(probe()["shot_ids"])
                    for _ in range(count):
                        page.select_option("#suite-template", template_id)
                        page.click("#suite-add-template")
                        page.wait_for_timeout(250)
                    after = list(probe()["shot_ids"])
                    return [shot for shot in after if shot not in before]

                def click_row_button(shot_id: str, text: str) -> None:
                    row(shot_id).locator(f'button:has-text("{text}")').first.click()

                def wait_save_enabled(shot_id: str, timeout: int = 30_000) -> None:
                    # 「保存候选图片」是本地动作：批次运行中也可用，只有同一张的取回在途时短暂禁用。
                    # 故障解除后按用户可见路径点它，不再依赖批次自己重试（用户看得到的是按钮 + 提示）。
                    expect(row(shot_id).locator('button:has-text("保存候选图片")')
                           .first).to_be_enabled(timeout=timeout)

                def submits_for(action_id: str) -> int:
                    return len([item for item in submit_requests
                                if item["action_id"] == action_id])

                def results_for(task_id: str) -> list:
                    return [item for item in result_requests
                            if item["task_id"] == task_id]

                # ---------------- 项目准备：空白项目 → 参考图 → 资料 → 槽位 → 套图 → 确认 ----------------
                stage = "prep"
                load_page(base + "/")
                page.fill("#new-project-name", "审计商品 · 候选字节")
                page.click("#create-project")
                expect(page.locator("#project-view")).to_be_visible()
                page.set_input_files("#ref-file", str(reference))
                expect(page.locator("#ref-list .ref-row")).to_have_count(1)
                page.fill("#intake-name", "便携保温杯")
                page.fill("#intake-description", "316ml 不锈钢保温杯，旋盖密封。")
                page.fill("#intake-selling-points", "12小时保温\n304不锈钢内胆")
                page.wait_for_timeout(1200)
                project_ids = page.evaluate(
                    "async () => { const db = await new Promise((resolve) => {"
                    " const request = indexedDB.open(\"amz-listing-kit-v2\");"
                    " request.onsuccess = () => resolve(request.result); });"
                    " const rows = await new Promise((resolve) => { const req ="
                    " db.transaction(\"projects\", \"readonly\").objectStore(\"projects\").getAll();"
                    " req.onsuccess = () => resolve(req.result); });"
                    " db.close(); return rows.map((item) => item.project_id); }")
                page.evaluate(SEED_SLOTS, project_ids[0])
                load_page()
                stage_nav.goto(page, "plan")
                page.click("#suite-seed")
                expect(page.locator("#shot-list .shot-row")).to_have_count(4)
                # Issue #9：编译前先做普通决定（用户真实路径）；choices 进 ui 证据。
                ui["decisions"] = shared.decide_for_compile(page, probe()["shot_ids"])
                stage_nav.goto(page, "generate")
                expect(page.locator("#prompt-list .shot-spec")).to_have_count(4)
                initial = probe()
                shot_ids = initial["shot_ids"]
                compile_all(page, shot_ids)
                ok_shot = shot_ids[0]
                # 摘要默认范围=未提交全集（ui-contract §4.6「主按钮只提交摘要明确列出的集合。
                # 默认是未提交的图；成功、在途、Unknown 不混入」）：空白项目首批就是 4 张。
                # 逐图场景不靠产品的"单图摘要开关"（不存在），而是每个场景前 add_shots 新增一张，
                # 新增图是当时唯一未提交图 → 摘要范围天然为 1 张，语义仍与合同一致。
                ready = probe()
                confirm_scope = page.evaluate(
                    """() => [...document.querySelectorAll('#confirm-list .confirm-shot')]
                         .map((node) => ({shot: node.getAttribute('data-shot-id'),
                                          badges: [...node.querySelectorAll('.badge')]
                                            .map((item) => item.textContent)}))""")
                confirm_status = page.locator("#confirm-status").inner_text()
                confirm_generation(shot_ids)
                ui["base_shots"] = shot_ids
                ui["boot_retries"] = list(boot_retries)
                ui["boot_diagnosis"] = boot_observer.summary()
                first_boot_failure = boot_observer.first_failure()
                # 首个失败即使被后一次加载掩盖，也必须显式判红：重试成功不关闭首个失败。
                # 受控诊断模式里第一次 prep 加载被显式注入破坏：-03b 在诊断模式下期望红
                # （首失败保留），默认路径仍期望绿（无首失败）。
                check("V2.4.4-03b", "启动诊断：首次加载失败不可被重试成功掩盖（首失败保留因果分支）",
                      (first_boot_failure is not None) if args.boot_diagnostic else (first_boot_failure is None),
                      {"first_failure": first_boot_failure,
                       "causal_branch": boot_observer.summary()["causal_branch"],
                       "boot_retries": list(boot_retries)})
                if args.boot_diagnostic:
                    diagnosis = boot_observer.summary()
                    check("V2.4.4-03d",
                          f"诊断红证明（{args.boot_diagnostic}）：受控注入必须留下首失败与分支",
                          first_boot_failure is not None,
                          {"mode": args.boot_diagnostic,
                           "first_failure": first_boot_failure,
                           "causal_branch": diagnosis["causal_branch"]})
                check("V2.4.4-03",
                      "就绪：首批摘要范围=未提交全集（4 张）、候选栏为空且只有参考图字节",
                      len(ready["ui"]["rows"]) == 4
                      and all(item["state"] == "none" for item in ready["ui"]["rows"])
                      and all(item["preview"] is None for item in ready["ui"]["rows"])
                      and len(ready["asset_rows"]) == 1
                      and ready["candidate_chains"] == {}
                      and [item["shot"] for item in confirm_scope] == shot_ids
                      and all("本次发送" in item["badges"] for item in confirm_scope)
                      and "发送 4 张" in confirm_status,
                      {"rows": len(ready["ui"]["rows"]),
                       "assets": len(ready["asset_rows"]),
                       "scope": [item["shot"] for item in confirm_scope],
                       "status": confirm_status})
                # ---------------- 单张成功：候选自动入库，三方 sha256 一致 ----------------
                stage = "check04-single"
                # 首批摘要已提交 ok 单张：confirm_and_submit 内 settle 已等到终态；
                # 这里只等行状态投影与预览（禁止再点已消费的单图按钮）。
                wait_state(ok_shot, "succeeded")
                single = probe()
                att4_chain = chain_of(single, ok_shot)
                att4 = att4_chain[-1]["payload"] if att4_chain else {}
                cand4 = candidate_of(single, ok_shot)
                rec4 = cand4[-1]["payload"] if cand4 else {}
                asset4 = next((item for item in single["asset_rows"]
                               if item["sha256"] == rec4.get("asset_sha256")), None)
                hashed4 = (page.evaluate(HASH_ASSET, {"sha256": rec4.get("asset_sha256")})
                           if rec4.get("asset_sha256") else {"found": False})
                resolved4 = results_for(att4.get("task_id") or "")
                declared4 = next((item["declared_sha"] for item in resolved4
                                  if item["status"] == 200 and item["declared_sha"]), "")
                row4 = row_of(single, ok_shot) or {}
                preview4 = row4.get("preview") or {}
                meta4 = row4.get("candidate_meta") or ""
                check("V2.4.4-04",
                      "单张成功：候选自动入库；记录 sha = 重算 sha = 响应头 sha；64×64 预览可见",
                      len(cand4) == 1
                      and rec4.get("action_id") == att4["action_id"]
                      and rec4.get("task_id") == att4["task_id"]
                      and rec4.get("media_type") == "image/png"
                      and rec4.get("width") == 64 and rec4.get("height") == 64
                      and bool(asset4) and asset4["has_blob"] and asset4["role"] == "candidate"
                      and hashed4.get("found") is True
                      and hashed4.get("sha256") == rec4.get("asset_sha256")
                      and hashed4.get("byte_size") == rec4.get("byte_size")
                      and declared4 == rec4.get("asset_sha256")
                      and preview4.get("natural_width", 0) > 0
                      and "候选已保存到本地" in meta4
                      and len(resolved4) == 1,
                      {"chain": len(cand4), "declared": declared4[:12],
                       "recomputed": str(hashed4.get("sha256"))[:12],
                       "record": str(rec4.get("asset_sha256"))[:12],
                       "result_requests": len(resolved4)})

                # ---------------- 刷新：候选不重复、零新增取回请求、预览恢复 ----------------
                stage = "check05-reload"
                requests_before_reload = len(result_requests)
                before_reload = probe()
                load_page()
                stage_nav.goto(page, "generate")
                wait_preview(ok_shot)
                after_reload = probe()
                check("V2.4.4-05",
                      "刷新恢复：候选记录与字节保留、不重复保存、零新增取回请求、预览仍可见",
                      candidate_json(after_reload, ok_shot) == candidate_json(before_reload, ok_shot)
                      and len(result_requests) == requests_before_reload
                      and len(after_reload["asset_rows"]) == len(before_reload["asset_rows"])
                      and ((row_of(after_reload, ok_shot) or {}).get("preview") or {})
                      .get("natural_width", 0) > 0,
                      {"result_requests_before": requests_before_reload,
                       "result_requests_after": len(result_requests),
                       "candidate_changed": candidate_json(after_reload, ok_shot)
                       != candidate_json(before_reload, ok_shot),
                       "candidate_before": candidate_json(before_reload, ok_shot)[:2200],
                       "candidate_after": candidate_json(after_reload, ok_shot)[:2200],
                       "assets_before": len(before_reload["asset_rows"]),
                       "assets_after": len(after_reload["asset_rows"]),
                       "preview": (row_of(after_reload, ok_shot) or {})})

                # ---------------- 取回失败一次：无半份记录、可恢复、重试后 sha 一致 ----------------
                stage = "check06-fetch-fail"
                fail_shot = add_shots("detail_material", 1)[0]
                # Issue #9：新增图先做印字决定再编译（无控件图返回 False）。
                shared.decide_for_compile(page, [fail_shot])
                compile_all(page, [fail_shot])
                append_prompt_mark(page, fail_shot, MARK_FETCH_FAIL, "验证取回失败一次")
                # 保存必须真的落库：请求文本要带上标记，否则替身不会进入取回失败场景。
                card6 = f'#prompt-list .shot-spec[data-shot-id="{fail_shot}"]'
                saved6 = page.input_value(card6 + " textarea.prompt-edit-text")
                assert MARK_FETCH_FAIL in saved6, "人工文本没有保存到 Prompt 卡"
                mode["fetch_fault"] = True
                before6 = probe()
                assets6_before = len(before6["asset_rows"])
                confirm_generation([fail_shot])
                wait_state(fail_shot, "succeeded")
                wait_hint_contains("RESULT_DOWNLOAD_FAILED")
                # 取回故障期间批次会一直自己重试（每轮 4s），故障不解除它不会结束：
                # 用户按提示走的是「先停止新增提交，再点这一行的保存候选图片」。
                page.click("#batch-stop")
                wait_batch_idle()
                failed_try = probe()
                att6_chain = chain_of(failed_try, fail_shot)
                att6 = att6_chain[-1]["payload"] if att6_chain else {}
                hint6 = failed_try["ui"]["batch"]["hint"]
                sent6 = [item for item in submit_requests
                         if item["action_id"] == att6.get("action_id")]
                # 批次语义：取回故障时 attempt 已 succeeded（提交结论不受掩盖），
                # 候选缺失走 fetch_queue + hint（含失败原因与下一步），无半份记录。
                no_half6 = (candidate_of(failed_try, fail_shot) == []
                            and len(failed_try["asset_rows"]) == assets6_before
                            and att6.get("state") == "succeeded")
                mode["fetch_fault"] = False
                wait_save_enabled(fail_shot)
                click_row_button(fail_shot, "保存候选图片")
                wait_candidate_ui(fail_shot)
                recovered6 = probe()
                rec6_chain = candidate_of(recovered6, fail_shot)
                rec6 = rec6_chain[-1]["payload"] if rec6_chain else {}
                hashed6 = (page.evaluate(HASH_ASSET, {"sha256": rec6["asset_sha256"]})
                           if rec6 else {"found": False})
                resolved6 = results_for(att6.get("task_id") or "")
                declared6 = next((item["declared_sha"] for item in resolved6
                                  if item["status"] == 200 and item["declared_sha"]), "")
                check("V2.4.4-06",
                      "取回失败：提交结论不受掩盖、原因与下一步可见、无半份记录、停止后手动保存 sha 与响应头一致",
                      bool(att6) and bool(rec6)
                      and no_half6
                      and bool(sent6) and MARK_FETCH_FAIL in (sent6[0]["prompt"] or "")
                      and "取回候选失败" in hint6 and "RESULT_DOWNLOAD_FAILED" in hint6
                      and "保存候选图片" in hint6
                      and len(candidate_of(recovered6, fail_shot)) == 1
                      and rec6.get("action_id") == att6["action_id"]
                      and hashed6.get("found") is True
                      and hashed6.get("sha256") == rec6.get("asset_sha256")
                      and declared6 == rec6.get("asset_sha256")
                      and submits_for(att6["action_id"]) == 1
                      # 批次会自动重试取回：故障期间全部 502，解除后最后一次 200（同一 task id）。
                      and len(resolved6) >= 2
                      and all(item["status"] == 502 for item in resolved6[:-1])
                      and resolved6[-1]["status"] == 200,
                      {"hint": hint6[:200], "statuses": [item["status"] for item in resolved6],
                       "attempt_chain": len(att6_chain), "candidate_chain": len(rec6_chain),
                       "half_record": not no_half6, "rec6": bool(rec6)})

                # ---------------- 配额异常：无半份记录、指引可恢复、解除后保存成功 ----------------
                stage = "check07-quota"
                # 新增图是当时唯一未提交图：摘要范围=1 张，配额故障只影响这一张。
                quota_shot = add_shots("infographic_benefits", 1)[0]
                # Issue #9：新增印字图先做决定再编译。
                shared.decide_for_compile(page, [quota_shot])
                compile_all(page, [quota_shot])
                before7 = probe()
                assets7_before = len(before7["asset_rows"])
                page.evaluate(INSTALL_IDB_FAULT)
                page.evaluate(SET_IDB_FAULT, True)
                confirm_generation([quota_shot])
                wait_state(quota_shot, "succeeded")
                # 候选保存被本地存储挡住：批次必须立刻停（不再空转），原因与下一步在提示区。
                wait_batch_idle()
                quota_failed = probe()
                quota_hint = quota_failed["ui"]["batch"]["hint"]
                quota_progress = quota_failed["ui"]["batch"]["progress"]
                quota_no_half = (candidate_of(quota_failed, quota_shot) == []
                                 and len(quota_failed["asset_rows"]) == assets7_before)
                page.evaluate(SET_IDB_FAULT, False)
                wait_save_enabled(quota_shot)
                click_row_button(quota_shot, "保存候选图片")
                wait_candidate_ui(quota_shot)
                quota_ok = probe()
                rec7_chain = candidate_of(quota_ok, quota_shot)
                rec7 = rec7_chain[-1]["payload"] if rec7_chain else {}
                hashed7 = (page.evaluate(HASH_ASSET, {"sha256": rec7["asset_sha256"]})
                           if rec7 else {"found": False})
                check("V2.4.4-07",
                      "配额异常：批次停而不空转、不留半份记录、提示含原因与下一步；解除后同一 action 保存成功",
                      bool(rec7) and hashed7.get("found") is True
                      and quota_no_half
                      and "浏览器存储空间不足" in quota_hint
                      and "保存候选图片" in quota_hint
                      and "已停止新增提交" in quota_progress
                      and "批次进行中" not in quota_progress
                      and len(candidate_of(quota_ok, quota_shot)) == 1
                      and hashed7.get("sha256") == rec7.get("asset_sha256"),
                      {"hint": quota_hint[:200], "progress": quota_progress[:200],
                       "candidate_chain": len(rec7_chain),
                       "half_record": not quota_no_half})

                # ---------------- 整套批次：只提交剩余图一次；全部成功且候选全部入库 ----------------
                stage = "check08-batch"
                # 剩余 2 张新图是当时全部未提交图：摘要范围=2（"发送 2 张"），
                # 已成功/已入库的图不得混入这次提交（ui-contract §4.6）。
                batch_shots = add_shots("detail_material", 1) + add_shots("scene_lifestyle", 1)
                # Issue #9：新增图先做印字决定再编译（无控件图返回 False）。
                shared.decide_for_compile(page, batch_shots)
                compile_all(page, batch_shots)
                submits_before8 = len(submit_requests)
                confirm_generation(batch_shots)
                wait_states({shot: "succeeded" for shot in batch_shots})
                for shot in batch_shots:
                    wait_candidate_ui(shot)
                finished = probe()
                final_rows = finished["ui"]["rows"]
                all_ids = [*shot_ids, fail_shot, quota_shot, *batch_shots]
                all_stored = all(candidate_of(finished, shot) for shot in all_ids)
                chains_ok = all(
                    bool(chain_of(finished, shot))
                    and chain_of(finished, shot)[-1]["payload"]["state"] == "succeeded"
                    and bool(candidate_of(finished, shot))
                    and candidate_of(finished, shot)[-1]["payload"]["action_id"]
                    == chain_of(finished, shot)[-1]["payload"]["action_id"]
                    for shot in all_ids)
                captured8 = submit_requests[submits_before8:]
                expected8 = [chain_of(finished, shot)[-1]["payload"]["action_id"]
                             for shot in batch_shots]
                check("V2.4.4-08",
                      "整套批次：只提交剩余图一次；全部成功且候选全部入库；进度与提示一致",
                      len(captured8) == len(batch_shots)
                      and [item["action_id"] for item in captured8] == expected8
                      and len(final_rows) == len(all_ids)
                      and all(item["state"] == "succeeded" for item in final_rows)
                      and all_stored and chains_ok
                      and f"已成功 {len(all_ids)}" in finished["ui"]["batch"]["progress"]
                      and "待保存候选" not in finished["ui"]["batch"]["progress"]
                      and "候选还没保存" not in finished["ui"]["batch"]["hint"],
                      {"captured": len(captured8),
                       "rows": len(final_rows),
                       "progress": finished["ui"]["batch"]["progress"],
                       "hint": finished["ui"]["batch"]["hint"]})
                ui["final"] = {
                    "attempt_states": {item["shot_id"]: item["state"] for item in final_rows},
                    "candidate_versions": {shot: len(candidate_of(finished, shot))
                                           for shot in all_ids},
                    "result_requests": len(result_requests),
                    "submit_requests": len(submit_requests),
                }
                screenshot_rel = f"evals/product-v2/v2.4.4-candidate-blob-{stamp}.png"
                page.screenshot(path=str(ROOT / screenshot_rel), full_page=True)
                screenshots.append(screenshot_rel)
            finally:
                context.close()
    except Exception as error:  # noqa: BLE001 - 中断也要留下证据文件
        interrupted = f"[{stage}] {type(error).__name__}: {error}"
    finally:
        boot_observer.server("shutdown_start", stage=stage,
                             running=server.running)
        try:
            server.stop()
            boot_observer.server("shutdown_finish", closed=True,
                                 running=server.running)
        except Exception as shutdown_error:  # noqa: BLE001
            boot_observer.server("shutdown_finish", closed=False,
                                 error=f"{type(shutdown_error).__name__}: {shutdown_error}")
    # 中断/完成都保留完整诊断：首个失败独立于后一次成功存在。
    ui["boot_diagnosis_final"] = boot_observer.summary()
    ui["boot_retries_final"] = list(boot_retries) if "boot_retries" in locals() else []
    if "failed_requests" in locals():
        ui["failed_requests_final"] = list(failed_requests)

    if interrupted:
        diagnosis = boot_observer.summary()
        failed_loads = boot_observer.failing_attempts()
        check("V2.4.4-99", "浏览器闭环在完成前中断", False,
              {"interrupted": interrupted,
               "stage": stage,
               "first_boot_failure": boot_observer.first_failure(),
               "failed_loads": failed_loads,
               "causal_branch": diagnosis["causal_branch"],
               "failed_requests": (list(failed_requests[:8])
                                   if "failed_requests" in locals() else []),
               "page_url": (_redact_url(page.url) if "page" in locals() else None),
               "base": base,
               "server_events": boot_observer.server_events[-40:],
               "browser_events": boot_observer.browser_events[-40:]})

    # 全部加载完成后再次核对首个失败：后一次成功不能使整轮全绿。
    # 受控诊断模式本身期望红：-03c 只在默认路径要求“无首失败”，诊断模式由 -03d 证明判红能力。
    final_first_failure = boot_observer.first_failure()
    final_branch = boot_observer.summary()["causal_branch"]
    if not args.boot_diagnostic:
        check("V2.4.4-03c", "启动诊断终核：整轮任一次加载失败都保留并判红（observer 证明，非因果修复）",
              final_first_failure is None,
              {"first_failure": final_first_failure,
               "causal_branch": final_branch,
               "attempts": boot_observer.summary()["attempts"]})
    else:
        check("V2.4.4-03e", f"诊断红证明终核（{args.boot_diagnostic}）：受控失败必须保留到整轮结束",
              final_first_failure is not None,
              {"mode": args.boot_diagnostic,
               "first_failure": final_first_failure,
               "causal_branch": final_branch})

    expected_noise = ("Failed to load resource: the server responded with a status of 504",
                      "Failed to load resource: the server responded with a status of 502",
                      "net::ERR_ABORTED")
    unexpected_console = [item for item in console_errors
                          if not any(noise in item for noise in expected_noise)]
    check("V2.4.4-09", "零意外 console error / page error（预期内的取回 502 与刷新中断除外）",
          not unexpected_console and not page_errors,
          {"console": console_errors[:6], "unexpected": unexpected_console,
           "page": page_errors[:5]})

    entry = run_entry(["--check"])
    check("V2.4.4-10", "正式入口自检仍全过（V2.4.4 不破坏既有入口）",
          entry["rc"] == 0 and any("通过。" in line for line in entry["tail"]), entry)

    failed = [item for item in checks if not item["ok"]]
    status = "passed" if not failed else "failed"
    finished_at = datetime.now().strftime("%Y-%m-%dT%H:%M:%S%z")
    boundary = (
        "证明候选字节在真实浏览器与真实 IndexedDB 上是可持久、可校验、可恢复的：成功结论在同一步"
        "把结果字节存进内容寻址的 assets 仓，候选记录的 sha256 与重算值、服务端 X-Image-Sha256 "
        "响应头三方一致；刷新后预览来自本地字节、零新增取回请求且不重复保存；取回失败一次不产生"
        "半份记录、批次提示给出原因与下一步，停止新增提交后按提示手动保存成功；IndexedDB 配额"
        "异常在协议层注入（产品代码无测试钩子），保存被挡住时批次立即停而不空转、失败不留半份记录"
        "并给出「清出空间后重试」指引；整套批次只提交剩余图一次、全部成功且候选全部"
        "入库，进度不再显示待保存候选。本批不做审核、单图返工与导出（Phase 5）；0 次真实模型调用、"
        "0 次外部网络；图像 provider 是注入的假替身（按 Prompt 标记决定取回场景），只证明候选"
        "持久化语义，不证明真实出图质量。启动诊断只证明观测能力（首个失败的 URL/阶段/分支与同窗"
        "host/浏览器事件被保留并判红），不证明 RC19 根因；诊断红不是因果修复，RC19 仍需现象—机制对应。"
    )
    report = {
        "task": "V2.4.4",
        "suite_id": "v2.4.4-candidate-blob",
        "status": status,
        "finished_at": finished_at,
        "model_calls": 0,
        "external_network_calls": 0,
        "checks": checks,
        "suites": suites,
        "ui_flow": ui,
        "console_errors": console_errors,
        "page_errors": page_errors,
        "screenshots": screenshots,
        "boundary": boundary,
    }
    label = f"-{args.label}" if args.label else ""
    json_path = EVIDENCE_DIR / f"v2.4.4-candidate-blob-{stamp}{label}.json"
    txt_path = EVIDENCE_DIR / f"v2.4.4-candidate-blob-{stamp}{label}.txt"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "amz-listing-kit Product V2 V2.4.4 候选字节流、Blob 持久化与容量管理",
        "NOT-AUTHORITY: point-in-time verification evidence only",
        f"observed_at: {finished_at}",
        f"status: {status}",
        "model_calls: 0 · external_network_calls: 0 (fake image provider + 本机服务)",
        f"json: {json_path.relative_to(ROOT).as_posix()}",
        "",
        "CHECKS",
    ]
    for item in checks:
        mark = "PASS" if item["ok"] else "FAIL"
        lines.append(f"- [{mark}] {item['id']} {item['title']}")
    lines += ["", "BOUNDARY", boundary]
    failed = [item for item in checks if not item["ok"]]
    if failed:
        # 失败时把判据实测值打进日志与文本证据（同 4_3 的 FAILED DETAILS）。
        lines += ["", "FAILED DETAILS"]
        lines += [f"- {item['id']} " + json.dumps(item["detail"], ensure_ascii=False, default=str)[:4000]
                  for item in failed]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    for line in lines:
        print(line)
    print("")
    print("证据文件：")
    print(" -", json_path.relative_to(ROOT).as_posix())
    print(" -", txt_path.relative_to(ROOT).as_posix())
    for shot in screenshots:
        print(" -", shot)
    return 0 if status == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
