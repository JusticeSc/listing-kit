/**
 * 当前项目包载荷版本边界：解析完整后、写入事务前拒绝不支持的 schema。
 * 已支持历史 payload 原样读；未知版本/缺真实来源在写入事务前拒绝。
 * PAYLOAD_SCHEMA_VERSIONS 镜像 domain 常量；这里只消费纯校验，不调业务执行。
 */

import { STORAGE_ERROR_CODES, StorageError } from "./errors.js";
import { checkStyleSpec, checkShotSpec } from "../domain/specs.js";
import { checkPromptRecord, canonicalJson } from "../domain/prompt.js";
import { checkConfirmationRecord } from "../domain/confirm.js";
import { checkAttemptRecord } from "../domain/attempt.js";


/** 文档种类 → 当前 payload schema_version。 */
/** @typedef {Record<string, number>} PayloadSchemaVersionMap */


/** @type {PayloadSchemaVersionMap} */
export const PAYLOAD_SCHEMA_VERSIONS = Object.freeze({
  product_input: 1,
  semantic_analysis: 1,
  fact_slot: 1,
  product_brief: 1,
  suite_plan: 1,
  style_spec: 2,
  shot_spec: 2,
  prompt_version: 2,
  generation_confirm: 2,
  generation_attempt: 3,
  candidate: 1,
  review_report: 1,
  selection: 1,
  suite_review: 1,
  export_record: 1,
  review_acknowledgement: 1,
});

/**
 * 需要明确历史分支的 payload 不猜缺省版本；Attempt 仍至少 schema 2，
 * 不给缺冻结执行身份的 schema 1 记录补造 legacy 映射。
 */
/** @type {PayloadSchemaVersionMap} */
export const MIN_PAYLOAD_SCHEMA_VERSIONS = Object.freeze({
  style_spec: 1,
  shot_spec: 1,
  prompt_version: 1,
  generation_confirm: 1,
  generation_attempt: 2,
});

/**
 * @param {{kind:unknown, document_id:unknown, version:unknown}} record
 * @returns {string}
 */
export function entryLabel(record) {
  return String(record.kind) + "/" + String(record.document_id) + "/v" + String(record.version);
}

/** 拒绝不支持的载荷版本；Attempt 必须显式声明当前身份 schema。 */
/**
 * @param {{kind:string, document_id:string, version:number, payload:unknown}} record
 * @returns {void}
 */
export function assertPayloadSchemaSupported(record) {
  const max = PAYLOAD_SCHEMA_VERSIONS[record.kind];
  if (max === undefined) return;
  const min = MIN_PAYLOAD_SCHEMA_VERSIONS[record.kind];
  const fields = record.payload && typeof record.payload === "object"
    ? /** @type {Record<string, unknown>} */ (record.payload) : {};
  const declared = fields.schema_version;
  if (typeof declared !== "number" || !Number.isInteger(declared)) {
    if (min !== undefined) {
      throw new StorageError(STORAGE_ERROR_CODES.PACKAGE_UNSUPPORTED_VERSION,
        "无法导入：文档 " + entryLabel(record) + " 缺少明确 payload schema_version；不猜历史版本或补造身份。");
    }
    return;
  }
  if (declared > max) {
    throw new StorageError(
      STORAGE_ERROR_CODES.PACKAGE_UNSUPPORTED_VERSION,
      "无法导入：文档 " + entryLabel(record) + " 声明的 payload schema_version=" + declared
        + " 高于当前支持的 " + max + "；请用较新版本打开或先导出该记录。",
    );
  }
  if (min !== undefined && declared < min) {
    throw new StorageError(
      STORAGE_ERROR_CODES.PACKAGE_UNSUPPORTED_VERSION,
      "无法导入：文档 " + entryLabel(record) + " 声明的 payload schema_version=" + declared
        + " 低于当前要求的 " + min + "（该记录缺少冻结执行身份，不做 legacy 映射、"
        + "不部分写入）；按计划 §2.3 整包拒绝。",
    );
  }
  const problems = record.kind === "style_spec" ? checkStyleSpec(record.payload)
    : record.kind === "shot_spec" ? checkShotSpec(record.payload)
    : record.kind === "prompt_version" ? checkPromptRecord(record.payload)
    : record.kind === "generation_confirm" ? checkConfirmationRecord(record.payload)
    : record.kind === "generation_attempt" ? checkAttemptRecord(record.payload)
    : [];
  if (problems.length) {
    throw new StorageError(STORAGE_ERROR_CODES.PACKAGE_INVALID,
      "无法导入：文档 " + entryLabel(record) + " 的历史/当前载荷不合法：" + problems[0].message);
  }
}


/**
 * 新冻结引用必须在完整项目包中有真实文档/资产；只检查历史来源，不要求“现在仍当前”。
 * 调用前每条已通过 assertPayloadSchemaSupported，校验不写入或修补原记录。
 * @param {{kind:string,document_id:string,version:number,payload:unknown}[]} documents
 * @param {{sha256:string}[]} assets
 * @returns {void}
 */
export function assertPackageSourceGraph(documents, assets) {
  /** @type {Map<string, {kind:string,document_id:string,version:number,payload:unknown}>} */
  const records = new Map();
  for (const record of documents) {
    records.set(record.kind + "/" + record.document_id + "/" + record.version, record);
  }
  const assetHashes = new Set();
  for (const asset of assets) assetHashes.add(asset.sha256);
  /** @param {string} label @param {string} reason @returns {never} */
  function reject(label, reason) {
    throw new StorageError(STORAGE_ERROR_CODES.PACKAGE_INVALID,
      "无法导入：文档 " + label + " 的冻结来源不完整：" + reason);
  }
  /** @param {{payload:unknown}} record @param {string} label @returns {Record<string, unknown>} */
  function sourcePayload(record, label) {
    if (!record.payload || typeof record.payload !== "object" || Array.isArray(record.payload)) {
      reject(label, "原来源不是可读取的对象。");
    }
    return /** @type {Record<string, unknown>} */ (record.payload);
  }
  for (const record of documents) {
    if (!record.payload || typeof record.payload !== "object" || Array.isArray(record.payload)) continue;
    const payload = /** @type {Record<string, unknown>} */ (record.payload);
    const label = entryLabel(record);
    if (record.kind === "shot_spec" && payload.schema_version === 2 && Array.isArray(payload.on_image_texts)) {
      for (const item of /** @type {import("../domain/type-contracts.js").OnImageText[]} */ (payload.on_image_texts)) {
        const source = item.source;
        const fact = records.get("fact_slot/" + source.document_id + "/" + source.version);
        if (!fact) reject(label, "上图文案缺少原事实版本。");
        if (item.status === "confirmed" && sourcePayload(fact, label).status !== "confirmed") {
          reject(label, "已确认上图文案的来源不是已确认事实。");
        }
      }
    }
    if (record.kind === "prompt_version" && payload.schema_version === 2) {
      const compiled = payload.compiled && typeof payload.compiled === "object"
        ? /** @type {Record<string,unknown>} */ (payload.compiled) : null;
      const rework = compiled?.rework && typeof compiled.rework === "object"
        ? /** @type {Record<string,unknown>} */ (compiled.rework) : null;
      if (rework) {
        const problem = /** @type {import("../domain/type-contracts.js").ReworkProblemCandidate} */ (rework.problem_candidate);
        const original = records.get("candidate/" + problem.document_id + "/" + problem.version);
        if (!original) reject(label, "问题候选的精确文档版本缺失。");
        const candidate = sourcePayload(original, label);
        if (problem.document_id !== payload.shot_id || candidate.shot_id !== payload.shot_id
          || candidate.candidate_id !== problem.candidate_id || candidate.asset_sha256 !== problem.asset_sha256) {
          reject(label, "问题候选身份与原文档不一致。");
        }
        if (!assetHashes.has(problem.asset_sha256)) reject(label, "问题候选原资产缺失。");
      }
    }
    const snapshot = payload.request_snapshot && typeof payload.request_snapshot === "object"
      ? /** @type {Record<string, unknown>} */ (payload.request_snapshot) : null;
    const references = record.kind === "prompt_version" && payload.schema_version === 2
      ? snapshot?.references
      : record.kind === "generation_attempt" && payload.schema_version === 3 ? payload.references : null;
    if (references === null) continue;
    if (!Array.isArray(references)) reject(label, "缺少实际图像列表。");
    for (const reference of /** @type {import("../domain/type-contracts.js").FrozenPromptReferenceSelection[]} */ (references)) {
      if (!assetHashes.has(reference.sha256)) reject(label, "冻结图像缺少原资产。");
      if (!Array.isArray(reference.sources) || !reference.sources.length) reject(label, "图像没有精确文档来源。");
      for (const source of reference.sources) {
        if (source.asset_sha256 !== reference.sha256) reject(label, "图像来源hash与实际图像不一致。");
        const original = records.get(source.kind + "/" + source.document_id + "/" + source.version);
        if (!original) reject(label, "缺少原来源文档版本。");
        const originalPayload = sourcePayload(original, label);
        if (source.kind === "candidate") {
          if (originalPayload.asset_sha256 !== reference.sha256) reject(label, "候选源未持有该原图。");
        } else if (source.kind === "product_input") {
          if (!Array.isArray(originalPayload.references)
            || !originalPayload.references.some((input) => input && typeof input === "object"
              && input.asset_sha256 === reference.sha256)) {
            reject(label, "商品源版本未绑定该原图。");
          }
        } else {
          reject(label, "不支持的冻结来源种类。");
        }
      }
    }
    if (record.kind === "generation_attempt") {
      const prompt = payload.prompt;
      if (!prompt || typeof prompt !== "object") reject(label, "缺少原Prompt身份。");
      const promptFields = /** @type {Record<string, unknown>} */ (prompt);
      const originalPrompt = records.get("prompt_version/" + payload.shot_id + "/" + promptFields.version);
      if (!originalPrompt) reject(label, "原Prompt版本不存在。");
      const promptPayload = sourcePayload(originalPrompt, label);
      if (promptPayload.hash !== promptFields.hash) reject(label, "原Prompt hash不一致。");
      if (promptPayload.schema_version !== 2) reject(label, "新动作没有消费新冻结请求合同。");
      const request = promptPayload.request_snapshot;
      if (!request || typeof request !== "object" || Array.isArray(request)
        || canonicalJson(/** @type {Record<string, unknown>} */ (request).references) !== canonicalJson(references)) {
        reject(label, "动作图序/用途/来源与原Prompt冻结请求不一致。");
      }
    }
  }
}
