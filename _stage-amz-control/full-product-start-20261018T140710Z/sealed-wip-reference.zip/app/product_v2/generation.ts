/**
 * V2.R5.1 生成执行 Module：单张提交、按 task 核对、候选保存
 * 与整套批次轮询的唯一执行权威。
 *
 * 职责（计划 §V2.R5.1）：
 *  - 先登记后外发：pending_submit 身份先落 IndexedDB，再发网关请求；
 *  - 冻结动作归属：所有状态写按 session.beginAction() 冻结的 projectId 落库；
 *  - 核对只按已保存 task id + 冻结执行身份查询，绝不重提、不偷用当前配置；
 *  - 下载/容量处理：候选字节 hash 校验、大小护栏、配额失败不产生半份记录。
 *
 * 本模块不持有 DOM、不持有编辑状态：套图/确认/Prompt/参考图等只读输入经 deps
 * 读取；单图 AI 复核与确定性报告归 selection-adoption（本模块只保全候选并通知投影变化），
 * 渲染/状态/错误文案由视图读 notice() + 订阅 subscribe() 自取，不注入 DOM 回调。
 * workspace 只调用这里的接口并投影结果。
 *
 * TypeScript 迁移（计划 §9 V2.R7.5）：本文件是唯一手工维护实现；同名 `generation.js`
 * 由 `npm run build:frontend` 从本文件生成，浏览器只消费生成的 `.js`（import 说明符保持 `.js`）。
 */

import {
  ATTEMPT_DOCUMENT_KIND,
  ATTEMPT_RECONCILE_MODES,
  ATTEMPT_STATES,
  MAX_ATTEMPT_REFERENCES,
  attemptCurrentEnvironmentIdentity,
  attemptExecutionIdentityFromEnvironment,
  attemptReconcileBlockedMessage,
  attemptReconcileEnvironment,
  attemptReconcileRequestOf,
  currentAttempt,
  buildAttemptRecord,
  buildReworkDirective,
  checkAttemptRecord,
  checkReworkDirective,
  newActionId,
  nextFromStatusEnvelope,
  nextFromSubmitEnvelope,
  selectReferences,
  CANDIDATE_DOCUMENT_KIND,
  CONFIRM_DOCUMENT_ID,
  MAX_CANDIDATE_BYTES,
  buildCandidateRecord,
  candidateForAttempt,
  candidateStoreDecision,
  checkCandidateRecord,
  parsePngDimensions,
 imagePromptProfile,
 canonicalJson,
 checkPromptRecord,
  checkConfirmationRecord,
  buildConfirmationRecord,
  confirmationSnapshot,
  confirmationPricingCurrent,
  stripReferenceMetadata,
  mergeReferenceProvenance,
  REWORK_MODES,
  DOMAIN_DOCUMENT_KINDS,
  promptStaleness,
  promptHash,
  batchProgressText,
  batchSubmitHalts,
  deriveBatchState,
  isNonEmptyString,
} from "./domain/index.js";
import { sha256Hex } from "./storage/db.js";
import { isPlainObject } from "./domain/shared.js";
import type { CompiledPromptResult, ConfirmationSheet, PromptCompileOptions } from "./prompts.js";
import type { AttemptReconcileResult } from "./domain/attempt.js";
import type { ConsumptionFence, ProjectRepository } from "./storage/validate.js";
import type {
  AttemptCurrentEnvironmentIdentity,
  AttemptError,
  AttemptRecord,
  AttemptState,
  BatchState,
  CandidateRecord,
  CompiledPrompt,
  ConfirmationRecord,
  ConfirmationSnapshot,
  ConfirmationSubmissionMode,
  FrozenPromptReferenceSelection,
  ImagePromptProfile,
  PlanShot,
  PromptRecord,
  PromptReferenceSelection,
  ReviewReport,
  ReworkDirective,
  ReworkDirectiveV2,
  ReworkMode,
  Sha256Hex,
  SuitePlan,
  SuitePlanSummary,
} from "./domain/type-contracts.js";

const IMAGE_SUBMIT_PATH = "/api/v2/images/submit";
const IMAGE_STATUS_PATH = "/api/v2/images/status";
 const IMAGE_RESULT_PATH = "/api/v2/images/result";

const BATCH_POLL_INTERVAL_MS = 4000;
const BATCH_POLL_MAX_ROUNDS = 300;

/* --------------------------------------------------------------- 依赖与状态类型 */

/** session.beginAction() 冻结的动作归属：generation 代次 + projectId；alive() 同时判两者。 */
export type ActionSnapshot = {
  readonly generation: number;
  readonly projectId: string | null;
  alive(): boolean;
};

/** 版本链条目：记录本体 + IndexedDB 版本号（渲染/幂等判据）。 */
export type AttemptEntry = { record: AttemptRecord; version: number };
export type CandidateEntry = { record: CandidateRecord; version: number };

/** 确认队列（documentId + 落库后的确认记录 + 版本）；pendingConfirmedShots 的输入。 */
export type ConfirmationQueue = {
  documentId: string;
  payload: ConfirmationRecord;
  version: number;
};

/** 参考图来源投影（intake.references → role/sha256）。 */
export type ReferenceSource = { role: string; sha256: string };

/** Prompt 版本条目（workspace 的 promptVersionAt / promptRecordOf 投影）。 */
export type PromptEntry = { version: number; record: PromptRecord };

/** 参考图出站载荷（本地仓库读出的字节转 base64）。 */
export type ReferencePayloadItem = {
  role: string;
  media_type: string;
  sha256: string;
  data_base64: string;
};

/** postImageJson 只返回「信封」；分类一律交给 domain。 */
type PostImageResponse = { envelope: unknown; status: number; transport: boolean };

/** 结果字节来源：同步内存面或 result 路由。 */
export type FetchedBytes =
  | { ok: true; buffer: ArrayBuffer; sha256?: string; media_type?: string;
      provider_id?: string; model_id?: string; task_id?: string | null }
  | { ok: false; reason: string; message: string; status?: number };

/** 同步协议提交信封暂存：action_id → 字节 + 信封声明哈希；取走即删、不落盘。 */
type SyncBytesEntry = { buffer: ArrayBuffer; expectSha: string | null };

/** 存储层最小契约（workspace 的 ProjectRepository 提供；此处只声明本 Module 用到的面）。 */
type StoredAsset = { sha256: Sha256Hex; byte_size: number };
type StoredAssetView = { blob: Blob | null; media_type?: string | null };
type AssetWriteInput = {
  bytes: ArrayBuffer; mediaType: string; originalName: string;
  role: string; width: number; height: number;
};
type DocumentSaveInput = { kind: string; documentId: string; payload: unknown; expectedVersion?: number };
type DocumentSaved = { version: number; payload?: unknown };
 /** restore 的 listLatest/listVersions 读出形状（确认/尝试/候选的头 + 版本链条目）。 */
 type DocumentRead = { document_id: string; payload: unknown; version: number };

export type GenerationRepository = {
  documents: {
    save(projectId: string, input: DocumentSaveInput): Promise<DocumentSaved>;
    get(projectId: string, kind: string, documentId: string, version: number): Promise<DocumentRead | null>;
    listLatest(projectId: string, kind: string): Promise<DocumentRead[]>;
    listVersions(projectId: string, kind: string, documentId: string): Promise<DocumentRead[]>;
  };
  assets: {
    get(projectId: string, sha256: string): Promise<StoredAssetView | null | undefined>;
    put(projectId: string, input: AssetWriteInput): Promise<StoredAsset>;
  };
} & Pick<ProjectRepository, "reserveGenerationAttempt" | "appendAttemptObservation" | "saveCandidate">;

/** generation 向 prompts 借用的窄能力：只编译/只落版，不拥有 Prompt 版本语义。
 *  选项形状与 prompts 的生产入口同一类型，不建第二份 rework/references/promptChoice 声明。
 *  返工时显式交出已冻结的参考图序列（有序 role/sha256/uses/sources），由 prompts 严格校验后冻结。 */
export type GenerationPromptAbility = {
  compile(shotId: string, options?: PromptCompileOptions): Promise<CompiledPromptResult>;
  compileAndSave(shotId: string, options?: PromptCompileOptions & { action?: ActionSnapshot | null }): Promise<{ saved: { version: number } }>;
};

/** workspace 注入的只读输入读者与投影回调；持久化顺序全部由本 Module 决定。 */
export type GenerationDependencies = {
  repository: GenerationRepository;
  beginAction(): ActionSnapshot;
  projectIdReader(): string | null;
  environmentReader(saved: unknown): unknown;
  requestHeaders(purpose: string, providerId?: string, source?: string): Record<string, string>;
  suitePlanReader(): SuitePlan | null;
  suiteSummaryReader(): SuitePlanSummary | null;
  promptEntryReader(shotId: string, version?: number | null): PromptEntry | null;
  confirmationReader(shotId: string): ConfirmationQueue | null;
  promptBasisReader(shotId: string, provider: ImagePromptProfile): unknown;
  /** 消费围栏：传出本次实际要发送的参考图时按“实际 scoped 依据”判据（无关 intake 备注/新候选不影响）。 */
  fenceReader(shotId: string, references?: readonly PromptReferenceSelection[]): ConsumptionFence;
  referenceSourceReader(): ReferenceSource[];
  /** 已保存的商品资料文档身份（documentId + 版本）；未保存/无资料返回 null，不伪造版本。 */
  productSourceIdentity(): { documentId: string; version: number } | null;
  promptsSheet(shotIds?: string[] | null): ConfirmationSheet | null;
  imageEnvironment(saved?: unknown): unknown;
  /** 返工编译/落版的唯一 Prompt 入口（workspace 注入 prompts 的窄能力）。 */
  promptAbility?: GenerationPromptAbility | null;
};

/** 批次运行状态（Module 内存面；不做第二份状态）。 */
export type BatchRunPhase = "submit" | "poll" | "fetch";
export type BatchRunState = {
  active: boolean; stopped: boolean; halted: boolean; haltReason: string;
  fetchBlocked: string; fetchNotice: string; currentShotId: string | null; phase: BatchRunPhase;
};

/** 单张提交结果（扁平可选判别式：skipped / thrown / 已受理）。 */
export type SubmitAttemptResult = {
  skipped?: true; thrown?: true; submitted?: true;
  reason?: string; message?: string;
  blocking?: AttemptRecord;
  state?: AttemptState | null; error?: AttemptError | null;
  task_id?: string | null; request_id?: string | null;
  provider_id?: string | null; model_id?: string | null; note?: string;
  record?: AttemptRecord;
  candidate?: StoreCandidateResult | null;
};

/** 单张核对结果。 */
export type ReconcileAttemptResult = {
  skipped?: true; failed?: true; advanced?: boolean;
  reason?: string; message?: string;
  gate?: AttemptReconcileResult;
  task_id?: string | null; state?: AttemptState | null; note?: string;
  candidate?: StoreCandidateResult | null;
};

/** 候选保存结果。 */
export type StoreCandidateResult = {
  stored?: true; skipped?: true; failed?: true;
  reason?: string; message?: string;
  candidate_id?: string; sha256?: Sha256Hex;
  width?: number; height?: number; byte_size?: number;
};

export type SubmitAttemptOptions = {
  action?: ActionSnapshot;
  confirmation?: ConfirmationQueue;
  requestHeaders?: Record<string, string>;
  explicitNew?: boolean;
  note?: string;
};
export type ReconcileAttemptOptions = { action?: ActionSnapshot };
export type EnsureCandidateOptions = {
  action?: ActionSnapshot;
  flights?: Set<string>;
  candidates?: CandidateEntry[];
  record?: AttemptRecord;
  bytes?: ArrayBuffer;
  syncBytes?: Map<string, SyncBytesEntry>;
  quiet?: boolean;
};
export type PollActiveAttemptsOptions = {
  action?: ActionSnapshot; intervalMs?: number; maxRounds?: number; once?: boolean;
};
export type RunBatchInput = { confirmation?: ConfirmationQueue; action?: ActionSnapshot };

/**
 * 所见摘要：owner 在自己内部准备，携带项目/会话归属、模式、冻结 scope、授权文档与所见版本、
 * 被排除的图与原因，以及用户看到的那份 snapshot。视图只保存并原样交回本对象，不重算摘要、
 * 不猜版本。
 */
export type GenerationIntent = {
  readonly projectId: string;
  readonly generation: number;
  readonly mode: ConfirmationSubmissionMode;
  readonly scope: readonly string[];
  readonly documentId: string;
  readonly seenVersion: number;
  /** 请求范围里被排除的图及原因（阻断/不在当前方案），供视图说明“为什么没提交这张”。 */
  readonly exclusions: readonly { readonly shot_id: string; readonly reason: string }[];
  all: ConfirmationSheet | null;
  sheet: ConfirmationSheet | null;
  identity: AttemptCurrentEnvironmentIdentity | null;
  snapshot: ConfirmationSnapshot | null;
};
export type AuthorizationQueueView = {
  queue: ConfirmationQueue; pending: string[]; current: string[]; targetMatched: boolean;
};
export type PrepareSummaryInput = {
  /** 视图显式选择的范围；缺席时用 owner 内部的失败重试/显式另发 scope。 */
  scope?: readonly string[] | null;
  mode?: ConfirmationSubmissionMode | null;
};
export type ConfirmAndRunInput = { intent: GenerationIntent };
/** 命令结果：窄判别联合（started 已开始执行 / blocked 未外发 / stale 所见已过期）。 */
export type ConfirmAndRunResult = {
  kind: "started" | "blocked" | "stale";
  reason?: string; message?: string;
  /** stale 时返回 owner 重新算出的新摘要（供视图重新呈现），不自动确认。 */
  intent?: GenerationIntent | null;
  confirmation?: ConfirmationQueue;
};

/** 返工路径的人工全文选择（设计 §13.6）：系统返工稿或保留人工全文并核对。 */
export type ReworkPromptChoice = "system_rework" | "keep_and_review";

/** 超容量时列给用户勾选的本图必要参考依据（普通复选框，非专业配置）。 */
export type ReworkReferenceChoice = { readonly role: string; readonly sha256: string; readonly required: boolean };

/** 单图返工的领域输入：只接受既有 domain 数据，不接受 DOM/状态回调/任意队列。 */
export type PrepareReworkInput = {
  readonly shotId: string;
  readonly candidateId: string;
  readonly mode: ReworkMode;
  readonly problems: readonly string[];
  readonly direction: string;
  readonly report?: ReviewReport | null;
  /** 人工全文时用户显式选择；缺席表示尚未选择（准备返回 blocked）。 */
  readonly promptChoice?: ReworkPromptChoice | null;
  /** 超容量时用户显式勾选的本图商品原参考依据（sha256 子集）；缺席=使用该图请求的全部依据。 */
  readonly selectedProductSha256?: readonly string[] | null;
  readonly directiveId?: string;
  readonly at?: string;
};

/** 返工意图：只读，所见来源/输入/Prompt/配置与编译预览全部冻结在 owner 内部。 */
export type ReworkIntent = {
  readonly projectId: string;
  readonly generation: number;
  readonly shotId: string;
  readonly mode: ReworkMode;
  readonly promptChoice: ReworkPromptChoice;
  readonly source: { readonly candidateId: string; readonly assetSha256: string; readonly version: number };
  readonly directive: ReworkDirectiveV2;
  /** 实际冻结的模型输入图序（有序 role/sha256/uses/sources）。 */
  readonly references: readonly FrozenPromptReferenceSelection[];
  readonly seenPromptVersion: number | null;
  readonly seenPromptHash: string | null;
  /** 当前这张图挂着人工全文（确认前必须显式选择保留或改用系统稿）。 */
  readonly manualPrompt: boolean;
  readonly seenFence: ConsumptionFence;
  readonly seenProvider: ImagePromptProfile | null;
  readonly preview: {
    readonly text: string; readonly references: number; readonly hash: string;
    /** 实际模型来源标注：编辑候选 / 商品原照 / 人工全文。 */
    readonly sourceLabel: string;
  };
};
/** 返工准备结果：ready 带只读意图；blocked 说明缺什么（缺源/超容量/人工稿未选/来源不完整）。 */
export type PrepareReworkResult =
  | { readonly kind: "ready"; readonly intent: ReworkIntent }
  | {
      readonly kind: "blocked"; readonly reason: string; readonly message: string;
      /** 超容量/勾选不合法时给出本图请求的原参考依据，供用户显式勾选必要图。 */
      readonly selection?: readonly ReworkReferenceChoice[];
      readonly capacity?: number;
    };
export type PrepareReworkBlocked = Extract<PrepareReworkResult, { kind: "blocked" }>;
export type ConfirmReworkInput = { intent: ReworkIntent };
export type ConfirmReworkResult = {
  kind: "started" | "blocked" | "stale";
  reason?: string; message?: string;
  promptVersion?: number;
  confirmation?: ConfirmationQueue;
};

/** owner 只读状态投影：旁路动作的用户可见文案，不参与任何业务判定。 */
export type GenerationNotice = { readonly status: string; readonly error: string };

/** 公开接口（workspace 与测试只调用这些方法）。 */
export type GenerationModule = {
  attemptChainOf(shotId: string): AttemptEntry[];
  latestAttemptOf(shotId: string): AttemptEntry | null;
  allAttemptRecords(): AttemptRecord[];
  candidateChainOf(shotId: string): CandidateEntry[];
  latestStoredCandidateOf(shotId: string): CandidateEntry | null;
  candidateForAttemptOf(shotId: string, actionId: string | null): CandidateEntry | null;
  submitAttempt(shotId: string, options?: SubmitAttemptOptions): Promise<SubmitAttemptResult>;
  reconcileAttempt(shotId: string, options?: ReconcileAttemptOptions): Promise<ReconcileAttemptResult>;
  storeCandidate(shotId: string, options?: EnsureCandidateOptions): Promise<StoreCandidateResult>;
  buildReferencePayload(references: PromptReferenceSelection[], pid: string): Promise<ReferencePayloadItem[]>;
  deriveBatch(): BatchState;
  batchStateReader(): BatchRunState | null;
  runBatch(input?: RunBatchInput): Promise<void>;
  reconcileOnce(): Promise<void>;
  confirmAndRun(input: ConfirmAndRunInput): Promise<ConfirmAndRunResult>;
  stopBatch(): void;
  isConfirmedShotCurrent(confirmation: ConfirmationQueue | null | undefined, shotId: string): boolean;
  restore(action: ActionSnapshot): Promise<void>;
  enterFailedRetry(shotIds: string[]): void;
  enterExplicitNew(shotId: string): void;
  hasCurrent(): boolean;
  shotHasCurrent(shotId: string | null): boolean;
  confirmationFor(shotId: string): ConfirmationQueue | null;
  queues(): AuthorizationQueueView[];
  /** 所见摘要（整套/失败重试/显式另发）：可显式交出视图选择的 scope/mode，否则用 owner 内部 scope。 */
  prepareSummary(input?: PrepareSummaryInput): GenerationIntent | null;
  /** 单图返工：准备只读意图（编译预览）；缺源/超容量/人工稿未选返回 blocked；预览/取消零持久化零外发。 */
  prepareRework(input: PrepareReworkInput): Promise<PrepareReworkResult>;
  confirmRework(input: ConfirmReworkInput): Promise<ConfirmReworkResult>;
  isAttemptInFlight(shotId: string): boolean;
  isCandidateInFlight(shotId: string): boolean;
  attemptChainsNow(): [string, AttemptEntry[]][];
  /** 旁路动作的只读文案投影（忙碌/进度仍读上面的飞行标识与批次投影）。 */
  notice(): GenerationNotice;
  /** owner 投影变化通知：视图订阅读只读投影，不执行任何业务变更。 */
  subscribe(listener: () => void): () => void;
  reset(): void;
};

/* --------------------------------------------------------------- 运行时窄化助手 */

/** 抛出值的可读信息（原实现按 error.message 取值；此处 in/typeof 收窄，与旧行为一致）。 */
function messageOf(error: unknown): string {
  if (error === null || typeof error !== "object" || !("message" in error)) return "";
  const message = error.message;
  return typeof message === "string" ? message : "";
}

/** 同步提交信封里的结果字节字段（服务端契约；in/typeof 收窄，缺失即 null，绝不伪造字节）。 */
function readSyncEnvelope(envelope: unknown): { imageBase64: string; imageSha256: string | null } | null {
  if (envelope === null || typeof envelope !== "object" || !("image_base64" in envelope)) return null;
  const base64 = envelope.image_base64;
  if (typeof base64 !== "string") return null;
  const rawSha = "image_sha256" in envelope ? envelope.image_sha256 : null;
  return {
    imageBase64: base64,
    imageSha256: typeof rawSha === "string" ? rawSha.toLowerCase() : null,
  };
}

/** 出站请求体里的目标 provider id（服务端契约；未知即 undefined，不伪造）。 */
function providerIdFromBody(body: unknown): string | undefined {
  if (body === null || typeof body !== "object" || !("target" in body)) return undefined;
  const target = body.target;
  if (target === null || typeof target !== "object" || !("provider_id" in target)) return undefined;
  return typeof target.provider_id === "string" ? target.provider_id : undefined;
}

/**
 * type-contracts.d.ts 是确认契约的权威；domain/confirm.js 仍是未迁移 JS，其推断签名把
 * executionIdentity 收成 null|undefined（`= null` 默认值），并把确认目标里的
 * protocol/capability_version/credential_source 从 unknown 收窄丢失，导致合法入参/结果都对不上
 * ConfirmationSnapshot / ConfirmationRecord。这里只按声明收口调用面：运行时仍是同一个函数、
 * 同一批实参，不做值转换、不新增校验，也不改公开面。
 */
type ConfirmationExecutionInput = {
  executionIdentity?: AttemptCurrentEnvironmentIdentity | null;
  submissionMode?: ConfirmationSubmissionMode;
  referencesByShot?: Record<string, PromptReferenceSelection[]>;
};
type ConfirmationBuildInput = ConfirmationExecutionInput & {
  sheet: unknown;
  hash: unknown;
  confirmedAt: unknown;
};
const snapshotOfSheet = confirmationSnapshot as
  (sheet: unknown, options?: ConfirmationExecutionInput) => ConfirmationSnapshot;
const recordOfConfirmation = buildConfirmationRecord as
  (input: ConfirmationBuildInput) => ConfirmationRecord;

/* --------------------------------------------------------------- Module */

export function createGenerationModule(deps: GenerationDependencies): GenerationModule {
  const functionDeps = ["beginAction", "projectIdReader", "environmentReader", "requestHeaders",
    "suitePlanReader", "suiteSummaryReader", "promptEntryReader",
    "confirmationReader", "promptBasisReader", "fenceReader", "referenceSourceReader",
    "promptsSheet", "imageEnvironment"] as const;
  for (const name of functionDeps) {
    if (typeof deps[name] !== "function") {
      throw new Error("生成执行 Module 缺少依赖：" + name + "。");
    }
  }
  if (!deps.repository) {
    throw new Error("生成执行 Module 缺少依赖：repository。");
  }
  if (deps.promptAbility !== undefined && deps.promptAbility !== null
    && (typeof deps.promptAbility.compile !== "function" || typeof deps.promptAbility.compileAndSave !== "function")) {
    throw new Error("生成执行 Module 缺少依赖：promptAbility。");
  }

  const repository = deps.repository;
  let attemptChains = new Map<string, AttemptEntry[]>();
  let attemptInFlight = new Set<string>();
  let candidateChains = new Map<string, CandidateEntry[]>();
  let candidateInFlight = new Set<string>();
  let authorizationInFlight = new Set<string>();
  let batchState: BatchRunState | null = null;
  // 授权队列/scope/mode 的唯一所有者（设计§2.1：generation 拥有显示摘要→明确提交→登记→执行的完整动作）。
  // 独立 authorization.ts 按包02删除，不留兼容别名。
  let confirmedQueues = new Map<string, ConfirmationQueue>();
  let confirmed: ConfirmationQueue | null = null;
  let reworkQueues = new Map<string, ConfirmationQueue>();
  let authorizationScope: string[] | null = null;
  let authorizationMode: ConfirmationSubmissionMode = "initial";
  // V2.R5.2 同步协议：提交信封里的结果字节暂存（action_id → {buffer, expectSha}）。
  // 明确不落盘：页面刷新/关闭即失效，候选保存走显式补救路径。取走即删。
  let pendingSyncBytes = new Map<string, SyncBytesEntry>();
  // owner 只读文案投影 + 唯一投影变化通知出口：视图订阅读投影，不注入 DOM 回调。
  // 文案只是旁路动作的呈现结果，不参与任何业务判定（设计 §11.5.2）。
  let noticeStatus = "";
  let noticeError = "";
  const listeners = new Set<() => void>();

  function notify(): void {
    for (const listener of [...listeners]) listener();
  }
  function setStatus(text: string): void {
    noticeStatus = text;
    notify();
  }
  function setNoticeError(text: string): void {
    noticeError = text;
    notify();
  }
  function clearNoticeError(): void {
    if (!noticeError) return;
    noticeError = "";
    notify();
  }

  /* ------------------------------------------------------------ 链与身份 */

  function attemptChainOf(shotId: string): AttemptEntry[] {
    return attemptChains.get(shotId) || [];
  }

  function latestAttemptOf(shotId: string): AttemptEntry | null {
    return currentAttempt(attemptChainOf(shotId));
  }

  function allAttemptRecords(): AttemptRecord[] {
    const list: AttemptRecord[] = [];
    for (const chain of attemptChains.values()) {
      for (const entry of chain) list.push(entry.record);
    }
    return list;
  }

  function rememberAttempt(shotId: string, entry: AttemptEntry): void {
    const chain = attemptChainOf(shotId).filter((item) => item.version !== entry.version);
    chain.push(entry);
    chain.sort((left, right) => left.version - right.version);
    attemptChains.set(shotId, chain);
  }

  function candidateChainOf(shotId: string): CandidateEntry[] {
    return candidateChains.get(shotId) || [];
  }

  function rememberCandidate(shotId: string, entry: CandidateEntry): void {
    const chain = candidateChainOf(shotId).filter((item) => item.version !== entry.version);
    chain.push(entry);
    chain.sort((left, right) => left.version - right.version);
    candidateChains.set(shotId, chain);
  }

  /** 最新 Attempt 若是「已成功且有候选」，返回该候选；其它情况返回 null。 */
  function latestStoredCandidateOf(shotId: string): CandidateEntry | null {
    const latest = latestAttemptOf(shotId);
    if (!latest || latest.record.state !== ATTEMPT_STATES.succeeded) return null;
    return candidateForAttemptOf(shotId, latest.record.action_id);
  }

  function attemptProviderIdentity(record: AttemptRecord): AttemptCurrentEnvironmentIdentity | null {
    // A saved task resolves its frozen target, independently of the model selected for new actions.
    return attemptCurrentEnvironmentIdentity(deps.environmentReader(record));
  }

  /** 渲染投影：某次 Attempt 之前保存的候选（存在即幂等保存已冻结的事实）。 */
  function candidateForAttemptOf(shotId: string, actionId: string | null): CandidateEntry | null {
    // Unchecked cast: 候选链条目恒为 {record, version}；domain 只回链中的元素（既有不变量）。
    const found = candidateForAttempt(candidateChainOf(shotId), actionId) as CandidateEntry | null;
    return found;
  }
  function reset(): void {
    attemptChains = new Map<string, AttemptEntry[]>();
    attemptInFlight = new Set<string>();
    candidateChains = new Map<string, CandidateEntry[]>();
    candidateInFlight = new Set<string>();
    authorizationInFlight = new Set<string>();
    confirmedQueues = new Map<string, ConfirmationQueue>();
    confirmed = null;
    reworkQueues = new Map<string, ConfirmationQueue>();
    authorizationScope = null;
    authorizationMode = "initial";
    pendingSyncBytes = new Map<string, SyncBytesEntry>();
    batchState = null;
    // 换项目只清旁路文案；订阅者（视图）生命周期归 workspace 装配，不在 reset 里退订。
    noticeStatus = "";
    noticeError = "";
  }
  // 授权面：confirmedQueues/confirmed/reworkQueues/authorizationScope/authorizationMode 的
  // 唯一所有者（设计§2.1：显示摘要→明确提交→登记→执行的完整动作归 generation）。
  // rememberConfirmation 复用旧 authorization.ts:109-117 语义：整套确认更新 scope/mode，
  // 返工确认按 shot 登记；版本相等时后到覆盖（旧 JS 用 >=，与 TS 的 <= 同义）。
  const REWORK_CONFIRM_PREFIX = "rework:";
  function rememberConfirmation(queue: ConfirmationQueue): void {
    confirmedQueues.set(queue.documentId + ":" + queue.version, queue);
    if (queue.documentId === CONFIRM_DOCUMENT_ID && (!confirmed || confirmed.version <= queue.version)) {
      confirmed = queue;
      authorizationScope = null;
      authorizationMode = "initial";
    } else if (queue.documentId.startsWith(REWORK_CONFIRM_PREFIX)) {
      const id = queue.documentId.slice(REWORK_CONFIRM_PREFIX.length);
      if ((reworkQueues.get(id)?.version || 0) <= queue.version) reworkQueues.set(id, queue);
    }
  }
  // restore 复用旧 authorization.ts:157-170：按 generation_confirm 列头+版本链恢复，
  // 每条经 checkConfirmationRecord 校验后登记（validation boundary，不伪造形状）。
  // restore 前调用方先 reset()（workspace loadWorkspace 已做），这里不二次清空。
  async function restore(action: ActionSnapshot): Promise<void> {
    if (!action.projectId) return;
    const latest = await repository.documents.listLatest(action.projectId, DOMAIN_DOCUMENT_KINDS.generation_confirm);
    for (const head of latest) {
      if (!action.alive()) return;
      const versions = await repository.documents.listVersions(
        action.projectId, DOMAIN_DOCUMENT_KINDS.generation_confirm, head.document_id);
      if (!action.alive()) return;
      for (const stored of versions) {
        const problems = checkConfirmationRecord(stored.payload);
        if (problems.length) throw new Error("已保存的生成授权无法恢复：" + problems[0].message);
        rememberConfirmation({
          documentId: stored.document_id,
          payload: stored.payload as ConfirmationQueue["payload"],
          version: stored.version,
        });
      }
    }
    const plan = deps.suitePlanReader();
    const shots = plan && Array.isArray(plan.shots)
      ? plan.shots.map((shot) => shot && shot.shot_id).filter((id): id is string => typeof id === "string")
      : [];
    for (const shotId of shots) {
      if (!action.alive()) return;
      const attemptDocs = await repository.documents.listVersions(
        action.projectId, ATTEMPT_DOCUMENT_KIND, shotId);
      if (!action.alive()) return;
      const attempts: AttemptEntry[] = [];
      for (const stored of attemptDocs.slice().reverse()) {
        if (checkAttemptRecord(stored.payload).length) {
          throw new Error("已保存的尝试链无法恢复：shot " + shotId);
        }
        attempts.push({ record: stored.payload as AttemptRecord, version: stored.version });
      }
      attemptChains.set(shotId, attempts);
    }
    for (const shotId of shots) {
      if (!action.alive()) return;
      const candidateDocs = await repository.documents.listVersions(
        action.projectId, CANDIDATE_DOCUMENT_KIND, shotId);
      if (!action.alive()) return;
      const candidates: CandidateEntry[] = [];
      for (const stored of candidateDocs.slice().reverse()) {
        if (checkCandidateRecord(stored.payload).length) {
          throw new Error("已保存的候选链无法恢复：shot " + shotId);
        }
        candidates.push({ record: stored.payload as CandidateRecord, version: stored.version });
      }
      candidateChains.set(shotId, candidates);
    }
  }
  // 按优先级排列的候选队列：返工（按登记倒序）在前，全部确认（含历史版本倒序）在后。
  // confirmationFor/queues 共用同一顺序，不重建原授权。
  function orderedQueues(): ConfirmationQueue[] {
    return [...reworkQueues.values()].reverse().concat(
      [...confirmedQueues.values()].reverse().filter(
        (queue) => !queue.documentId.startsWith(REWORK_CONFIRM_PREFIX)));
  }
  // 进入失败重试/显式另发：登记 scope + mode（旧 authorization.ts:175-176 语义，不改业务）。
  function hasCurrentQueue(): boolean {
    return Boolean(confirmed?.payload.shots.some((shot) => isConfirmedShotCurrent(confirmed, shot.shot_id)));
  }
  function shotHasCurrentQueue(shotId: string | null): boolean {
    return Boolean(shotId && orderedQueues().some((queue) => isConfirmedShotCurrent(queue, shotId)));
  }
  // confirmationFor 复用旧 authorization.ts:179 语义：ordered 顺序 + pendingAuthorizationShots，
  // 不依赖外部 attemptChain，复用内部 pendingConfirmedShots（同一判据）。
  function confirmationForOf(shotId: string): ConfirmationQueue | null {
    return orderedQueues().find((queue) => pendingConfirmedShots(queue).includes(shotId)) || null;
  }
  // queues 复用内部 pendingConfirmedShots/isConfirmedShotCurrent/confirmationTargetMatched，
  // 返回 {queue,pending,current,targetMatched} 投影；环境经 imageEnvironment(queue) 取同快照身份。
  function queuesView(): AuthorizationQueueView[] {
    return orderedQueues().map((queue) => {
      const pending = pendingConfirmedShots(queue);
      return {
        queue,
        pending,
        current: pending.filter((id) => isConfirmedShotCurrent(queue, id)),
        targetMatched: confirmationTargetMatched(queue),
      };
    });
  }
  // 实际冻结参考图身份（有序 role + 完整 sha256）：从每图当前 Prompt 的 request_snapshot 读取，
  // 写进确认快照 v2，使授权指纹绑定“这一批真正发送的图序”。
  function frozenReferencesByShot(sheet: ConfirmationSheet | null): Record<string, PromptReferenceSelection[]> {
    const byShot: Record<string, PromptReferenceSelection[]> = {};
    for (const shot of sheet?.shots || []) {
      const version = shot.prompt.version;
      const entry = typeof version === "number" ? deps.promptEntryReader(shot.shot_id, version) : null;
      const refs = entry ? entry.record.request_snapshot.references : null;
      byShot[shot.shot_id] = Array.isArray(refs)
        ? refs.map((ref) => ({ role: ref.role, sha256: ref.sha256 }))
        : [];
    }
    return byShot;
  }
  function snapshotForSheet(sheet: ConfirmationSheet | null, identity: AttemptCurrentEnvironmentIdentity | null,
    mode: ConfirmationSubmissionMode): ConfirmationSnapshot | null {
    if (!sheet || !identity) return null;
    return snapshotOfSheet(sheet, {
      executionIdentity: identity, submissionMode: mode, referencesByShot: frozenReferencesByShot(sheet),
    });
  }
  // intent 复用旧 authorization.ts:136-147：prompts.sheet + scope/mode + confirmationSnapshot。
  // 冻结的 scope/mode 与授权文档/所见版本随 intent 一起交给视图；外发前 owner 重算同 scope
  // 摘要比对（见 confirmAndRun），视图不再传 readIntent/documentId/expectedVersion。
  function intentForScope(scope: readonly string[], mode: ConfirmationSubmissionMode,
    all: ConfirmationSheet): GenerationIntent {
    const requested = [...new Set(scope.filter((id) => isNonEmptyString(id)))];
    const eligible = new Set(requested);
    const byId = new Map(all.shots.map((shot) => [shot.shot_id, shot]));
    const ids = all.shots.filter((shot) => eligible.has(shot.shot_id) && !shot.blockers.length)
      .map((shot) => shot.shot_id);
    const exclusions = requested.flatMap((id) => {
      const shot = byId.get(id);
      if (!shot) return [{ shot_id: id, reason: "not_in_plan" }];
      if (shot.blockers.length) return [{ shot_id: id, reason: shot.blockers.map((item) => item.code).join("+") }];
      return [];
    });
    const sheet = ids.length ? deps.promptsSheet(ids) : null;
    const identity = attemptCurrentEnvironmentIdentity(deps.imageEnvironment());
    const snapshot = snapshotForSheet(sheet, identity, mode);
    const action = deps.beginAction();
    const reworkShotId = mode === "rework" && scope.length === 1 ? scope[0] : null;
    const documentId = reworkShotId ? REWORK_CONFIRM_PREFIX + reworkShotId : CONFIRM_DOCUMENT_ID;
    const seenVersion = reworkShotId
      ? (reworkQueues.get(reworkShotId)?.version || 0)
      : (confirmed?.version || 0);
    return {
      projectId: action.projectId || "", generation: action.generation, mode,
      scope: [...scope], documentId, seenVersion, exclusions, all, sheet, identity, snapshot,
    };
  }
  function intentOf(batch: { queue: string[]; retry_queue: string[] },
    override: { scope?: readonly string[] | null; mode?: ConfirmationSubmissionMode | null } = {}): GenerationIntent | null {
    const all = deps.promptsSheet(null);
    if (!all) return null;
    const mode = override.mode || authorizationMode;
    const scope = (override.scope && override.scope.length ? override.scope : null)
      || authorizationScope
      || (mode === "failed_retry" ? batch.retry_queue : batch.queue);
    return intentForScope(scope, mode, all);
  }
  /** 所见摘要命令：可显式交出视图选择的 scope/mode；缺席时用 owner 内部的失败重试/显式另发 scope。 */
  function prepareSummary(input: PrepareSummaryInput = {}): GenerationIntent | null {
    const batch = deriveBatch();
    return intentOf({ queue: batch.queue, retry_queue: batch.retry_queue },
      { scope: input.scope, mode: input.mode });
  }

  /** 冻结参考图单张容量上限（设计 §13.6.2）：超过即阻断，不悄悄裁图/换模型。 */
  const MAX_REFERENCE_IMAGE_BYTES = 10 * 1024 * 1024;

  /** 参考图身份键：只比 role + 完整 sha256（uses/sources 由 Prompt 冻结链表达，不进这里）。 */
  function referenceIdentityOf(list: readonly PromptReferenceSelection[]): string {
    return canonicalJson(stripReferenceMetadata(list));
  }

  /** 同 sha 只保留一次（首现顺序），用于把“候选 + 商品依据”折叠成实际模型输入图序。 */
  function dedupeReferenceIdentity(list: readonly PromptReferenceSelection[]): PromptReferenceSelection[] {
    const seen = new Set<string>();
    const out: PromptReferenceSelection[] = [];
    for (const ref of list) {
      const sha = String(ref.sha256 || "");
      if (!sha || seen.has(sha)) continue;
      seen.add(sha);
      out.push({ role: ref.role, sha256: ref.sha256 });
    }
    return out;
  }

  /**
   * 新动作实际图序当前性：返工稿按冻结来源逐条核对（问题候选仍在且居首 + 商品依据仍在且角色不变，
   * 仅新候选晚到不算依据变化），初始稿按本图当前选择重算图序。返回 false 即“已变化/不可用”，零外发。
   */
  function referencesStillCurrent(shotId: string, shot: PlanShot, profile: ImagePromptProfile,
    prompt: PromptRecord): boolean {
    const refs = prompt.request_snapshot.references;
    if (!Array.isArray(refs) || refs.length === 0) return false;
    const rework = prompt.compiled.rework;
    const mode = rework && (rework.mode === "edit_candidate" || rework.mode === "regenerate_original")
      ? rework.mode : null;
    // 历史/旧形态（参考项没有严格 uses）保持原精确重算，不做 V2 投影过滤。
    const strict = refs.every((ref) => Array.isArray(ref.uses) && ref.uses.length > 0);
    if (!strict) {
      if (mode === "edit_candidate") {
        const entry = candidateChainOf(shotId).find((item) => item.record.candidate_id === rework!.candidate_id) || null;
        if (!entry || refs[0].sha256 !== entry.record.asset_sha256) return false;
      }
      if (rework && mode) {
        const currentIntake = new Map(deps.referenceSourceReader().map((ref) => [String(ref.sha256), ref.role]));
        for (const ref of refs) {
          if (Array.isArray(ref.uses) && ref.uses.includes("edit_source")) continue;
          if (currentIntake.get(String(ref.sha256)) !== ref.role) return false;
        }
        return true;
      }
      const expected = dedupeReferenceIdentity(selectReferences(shot, deps.referenceSourceReader(),
        { maxReferences: profile.max_reference_images }));
      return expected.length > 0 && referenceIdentityOf(expected) === referenceIdentityOf(refs);
    }
    // V2 实际图序：只核对当前本图商品投影（无截断）过滤到冻结的 product_input SHAs 后是否同序同角色，
    // 与编辑模式的问题候选是否仍居首且未变。仅新候选/无关图/其它图晚到不算依据变化。
    // 纯候选编辑源 = 带 edit_source 且无 product_truth（uses 词表无 product_input，它是来源 kind）；
    // 同 sha 合并 candidate + product_input 时有效，仍算商品依据。
    const frozenProduct = refs.filter((ref) => !(Array.isArray(ref.uses)
      && ref.uses.includes("edit_source") && !ref.uses.includes("product_truth")))
      .map((ref) => ({ role: ref.role, sha256: ref.sha256 }));
    if (mode === "edit_candidate") {
      const entry = candidateChainOf(shotId).find((item) => item.record.candidate_id === rework!.candidate_id) || null;
      if (!entry || refs[0].sha256 !== entry.record.asset_sha256) return false;
    }
    const frozenSet = new Set(frozenProduct.map((ref) => ref.sha256));
    const currentProduct = selectReferences(shot, deps.referenceSourceReader(),
      { maxReferences: Number.MAX_SAFE_INTEGER })
      .filter((ref) => !(Array.isArray(ref.uses)
        && ref.uses.includes("edit_source") && !ref.uses.includes("product_truth")))
      .filter((ref) => frozenSet.has(String(ref.sha256)))
      .map((ref) => ({ role: ref.role, sha256: ref.sha256 }));
    return sameReferenceOrder(currentProduct, frozenProduct);
  }

  /**
   * 返工实际输入图序：编辑模式先放固定问题候选的原 Blob，再按现有本图绑定顺序放商品依据；
   * 重生成只用商品原参考依据。先取该图请求的**全部**依据（不截断），再由用户显式勾选或默认全选，
   * 最后按有效 profile 容量上限（编辑源占一位）判定；超容量即阻断并给出勾选清单，绝不悄悄裁图、丢依据或换模型。
   */
  async function buildReworkReferences(action: ActionSnapshot, shotId: string, source: CandidateEntry,
    mode: ReworkMode, profile: ImagePromptProfile, selectedSha: readonly string[] | null | undefined): Promise<
      | { ok: true; references: FrozenPromptReferenceSelection[] }
      | { ok: false; reason: string; message: string; selection?: ReworkReferenceChoice[]; capacity?: number }> {
    const pid = action.projectId;
    if (!pid) return { ok: false, reason: "stale_session", message: "缺少项目上下文，没有外发。" };
    const shot = deps.suitePlanReader()?.shots?.find((item) => item.shot_id === shotId) || null;
    if (!shot) return { ok: false, reason: "shot_missing", message: "这张图已不在方案里，没有外发。" };
    const cap = Math.min(MAX_ATTEMPT_REFERENCES, profile.max_reference_images);
    // 不截断地取该图声明的全部原参考依据（selectReferences 在 maxReferences 处提前返回）。
    const allProduct = selectReferences(shot, deps.referenceSourceReader(),
      { maxReferences: Number.MAX_SAFE_INTEGER });
    const requiredRoles = new Set((Array.isArray(shot.dependencies) ? shot.dependencies : [])
      .filter((dep) => dep && dep.kind === "asset_role" && isNonEmptyString(dep.role))
      .map((dep) => dep.role));
    const choices: ReworkReferenceChoice[] = allProduct.map((ref) => ({
      role: ref.role, sha256: ref.sha256, required: requiredRoles.has(ref.role),
    }));
    let chosen = allProduct;
    if (Array.isArray(selectedSha)) {
      const wanted = new Set(selectedSha);
      for (const sha of wanted) {
        if (!allProduct.some((ref) => ref.sha256 === sha)) {
          return { ok: false, reason: "selection_invalid",
            message: "勾选的参考图不属于这张图实际请求的依据；请重新勾选。", selection: choices, capacity: cap };
        }
      }
      for (const ref of allProduct) {
        if (requiredRoles.has(ref.role) && !wanted.has(ref.sha256)) {
          return { ok: false, reason: "selection_missing_required",
            message: "这张图必需的参考依据不能被排除；请保留必需项。", selection: choices, capacity: cap };
        }
      }
      chosen = allProduct.filter((ref) => wanted.has(ref.sha256));
    }
    const wantsCandidate = mode === "edit_candidate";
    // 候选与商品依据同字节时合并双用途/双来源，只占一个实际输入位。
    const addsCandidate = wantsCandidate && !chosen.some(ref => ref.sha256 === source.record.asset_sha256);
    if (chosen.length + (addsCandidate ? 1 : 0) > cap) {
      return { ok: false, reason: "over_capacity",
        message: "这张图要发送的图超过 " + cap + " 张上限；请勾选本图必要的商品原参考依据后再返工。",
        selection: choices, capacity: cap };
    }
    const productSource = deps.productSourceIdentity();
    if (chosen.length > 0 && !productSource) {
      return { ok: false, reason: "no_product_source",
        message: "商品资料还没有保存版本；先保存商品资料再返工，没有外发。" };
    }
    const seed: FrozenPromptReferenceSelection[] = [];
    if (wantsCandidate) {
      seed.push({
        role: "other", sha256: source.record.asset_sha256, uses: ["edit_source"],
        sources: [{ kind: "candidate", document_id: shotId,
          version: source.version, asset_sha256: source.record.asset_sha256 }],
      });
    }
    for (const ref of chosen) {
      // 上方守卫已保证本循环进入时 productSource 非空；防御性复核，不静默伪造版本。
      if (!productSource) {
        return { ok: false, reason: "no_product_source",
          message: "商品资料还没有保存版本；先保存商品资料再返工，没有外发。" };
      }
      seed.push({
        role: ref.role, sha256: ref.sha256, uses: ["product_truth"],
        sources: [{ kind: "product_input", document_id: productSource.documentId,
          version: productSource.version, asset_sha256: ref.sha256 }],
      });
    }
    const merged = mergeReferenceProvenance(seed) as FrozenPromptReferenceSelection[];
    if (merged.length === 0) return { ok: false, reason: "no_references", message: "这张图没有可发送的参考图。" };
    for (const ref of merged) {
      const asset = await repository.assets.get(pid, ref.sha256);
      if (!asset || !asset.blob) {
        return { ok: false, reason: "reference_missing",
          message: "参考图资产缺失（sha256 " + String(ref.sha256).slice(0, 12) + "…），请重新上传。" };
      }
      const media = asset.media_type || "";
      if (!["image/png", "image/jpeg"].includes(media)) {
        return { ok: false, reason: "reference_media", message: "返工只支持 PNG/JPEG 参考图，请换用受支持格式。" };
      }
      if (asset.blob.size > MAX_REFERENCE_IMAGE_BYTES) {
        return { ok: false, reason: "reference_too_large", message: "单张参考图超过 10MiB；请压缩后再返工。" };
      }
      if (await sha256Hex(await asset.blob.arrayBuffer()) !== ref.sha256) {
        return { ok: false, reason: "reference_hash_mismatch", message: "参考图字节与本地哈希不一致，没有外发。" };
      }
    }
    return { ok: true, references: merged };
  }

  /** 顺序敏感的参考图比较：role + 完整 sha256 有序列表（不比较 uses/sources 元数据）。 */
  function sameReferenceOrder(a: readonly PromptReferenceSelection[] | null | undefined,
    b: readonly PromptReferenceSelection[] | null | undefined): boolean {
    const left = Array.isArray(a) ? a : [];
    const right = Array.isArray(b) ? b : [];
    if (left.length !== right.length) return false;
    return left.every((item, index) => item.role === right[index].role && item.sha256 === right[index].sha256);
  }

  function fenceJsonOf(fence: ConsumptionFence): string {
    return canonicalJson({ sources: fence.sources, projection: fence.projectionJson, assets: [...fence.assetSha256].sort() });
  }

  /**
   * 返工意图准备：只读当前候选/输入/Prompt/配置并编译预览，不持久化、不外发。
   * 缺源/超容量/来源不完整/人工稿未选一律返回 blocked（零外发、不自动降级、不换别图）。
   * 报告是调用方显式传入的既有 domain 数据（可空），owner 不读库、不触发补建。
   */
  async function prepareRework(input: PrepareReworkInput): Promise<PrepareReworkResult> {
    const action = deps.beginAction();
    if (!action.projectId || !action.alive()) {
      return { kind: "blocked", reason: "stale_session", message: "缺少项目上下文，返工预览没有生成。" };
    }
    const ability = deps.promptAbility || null;
    if (!ability) return { kind: "blocked", reason: "no_prompt_ability", message: "返工编译能力缺失，预览没有生成。" };
    if (REWORK_MODES.indexOf(input.mode) === -1) {
      return { kind: "blocked", reason: "mode_unknown", message: "返工模式不认识，请重新选择。" };
    }
    const source = candidateChainOf(input.shotId).find((item) => item.record.candidate_id === input.candidateId) || null;
    if (!source) {
      return { kind: "blocked", reason: "source_missing", message: "这条返工依据候选已经不在了，先重新选择候选。" };
    }
    const currentPrompt = deps.promptEntryReader(input.shotId);
    const manualPrompt = Boolean(currentPrompt && currentPrompt.record.origin === "manual_edit");
    const choiceProvided = input.promptChoice === "keep_and_review" || input.promptChoice === "system_rework";
    if (manualPrompt && !choiceProvided) {
      return { kind: "blocked", reason: "needs_manual_choice",
        message: "这张图当前是人工全文；请明确选择“保留人工全文并核对本次模式/图序”或"
          + "“使用系统返工稿，保留原人工历史”，没有外发。" };
    }
    const choice: ReworkPromptChoice = input.promptChoice === "keep_and_review" ? "keep_and_review" : "system_rework";
    const profile = (() => {
      try { return imagePromptProfile(deps.imageEnvironment()); } catch { return null; }
    })();
    if (!profile) return { kind: "blocked", reason: "config_missing", message: "图像能力档缺失，返工预览没有生成。" };
    const directive = buildReworkDirective({
      directiveId: input.directiveId || newActionId(),
      shotId: input.shotId,
      candidate: source.record,
      candidateVersion: source.version,
      mode: input.mode,
      report: input.report === undefined ? null : input.report,
      problems: [...input.problems],
      direction: input.direction,
      at: input.at || new Date().toISOString(),
    });
    const sourceRef = {
      candidateId: source.record.candidate_id, assetSha256: source.record.asset_sha256, version: source.version,
    };
    // §13.6：模式决定实际图序，与人工/系统稿选择无关；人工稿只保留正文，参考图仍按本次模式冻结。
    const built = await buildReworkReferences(action, input.shotId, source, input.mode, profile,
      input.selectedProductSha256);
    if (!built.ok) {
      return { kind: "blocked", reason: built.reason, message: built.message,
        selection: built.selection, capacity: built.capacity };
    }
    const fence = deps.fenceReader(input.shotId, built.references);
    const seenFence: ConsumptionFence = {
      sources: [...fence.sources], projectionJson: fence.projectionJson, assetSha256: [...fence.assetSha256],
    };
    const compiled = await ability.compile(input.shotId, {
      rework: directive, references: built.references, promptChoice: choice,
    });
    if (!action.alive()) {
      return { kind: "blocked", reason: "stale_session", message: "项目或会话已切换；这份预览不再有效，没有写入。" };
    }
    const prompt = deps.promptEntryReader(input.shotId);
    const keptManual = choice === "keep_and_review" && manualPrompt;
    return { kind: "ready", intent: {
      projectId: action.projectId, generation: action.generation, shotId: input.shotId,
      mode: input.mode, promptChoice: choice, directive, source: sourceRef,
      references: built.references,
      seenPromptVersion: prompt ? prompt.version : null, seenPromptHash: prompt ? prompt.record.hash : null,
      manualPrompt: keptManual, seenFence, seenProvider: profile,
      preview: { text: compiled.compiled.text, references: compiled.references.length,
        hash: compiled.payload.hash,
        sourceLabel: keptManual ? "人工全文（正文保留，图序按本次模式）"
          : (input.mode === "edit_candidate" ? "模型来源：当前候选图（编辑）" : "模型来源：商品原照（重新生成）") },
    } };
  }

  function reworkStaleReason(intent: ReworkIntent, options: { afterSaveVersion?: number | null } = {}): { reason: string; message: string } | null {
    const action = deps.beginAction();
    if (!action.projectId || intent.projectId !== action.projectId || intent.generation !== action.generation) {
      return { reason: "stale_session", message: "项目或会话已切换；这份返工意图不再有效，没有外发。" };
    }
    if (REWORK_MODES.indexOf(intent.mode) === -1) {
      return { reason: "mode_unknown", message: "返工模式不认识；请重新预览，没有外发。" };
    }
    // 仅新候选晚到不算依据变化：原候选仍在且 hash/版本不变即可继续（设计 §13.6.5）。
    const current = candidateChainOf(intent.shotId).find((item) => item.record.candidate_id === intent.source.candidateId) || null;
    if (!current || current.record.asset_sha256 !== intent.source.assetSha256 || current.version !== intent.source.version) {
      return { reason: "source_changed", message: "返工依据的候选已变化或不在；请重新选择候选，没有外发。" };
    }
    if (checkReworkDirective(intent.directive).length) {
      return { reason: "directive_invalid", message: "返工指令不合法；请重新预览，没有外发。" };
    }
    const prompt = deps.promptEntryReader(intent.shotId);
    const version = prompt ? prompt.version : null;
    const hash = prompt ? prompt.record.hash : null;
    const manualNow = Boolean(prompt && prompt.record.origin === "manual_edit");
    const savedVersion = options.afterSaveVersion === undefined ? null : options.afterSaveVersion;
    // 预览时已捕获该人工稿版本/哈希的显式选择（keep_and_review 或 system_rework）都允许继续：
    // system_rework 用系统稿替换并保留原人工历史，keep_and_review 保留正文。
    // 仅当预览后 Prompt 才变成/换过人工全文时要求重新预览，绝不静默替换人工正文。
    if (savedVersion === null && manualNow && !(version === intent.seenPromptVersion && hash === intent.seenPromptHash)) {
      return { reason: "manual_edit",
        message: "这张图的 Prompt 在预览后变化（人工全文）；请重新预览并明确“保留人工全文”或“使用系统返工稿”，没有外发。" };
    }
    const promptIsCurrent = savedVersion === null
      ? (version === intent.seenPromptVersion && hash === intent.seenPromptHash)
      : (version === savedVersion && Boolean(prompt?.record.compiled.rework)
        && prompt?.record.compiled.rework?.directive_id === intent.directive.directive_id);
    if (!promptIsCurrent) {
      return { reason: "prompt_changed", message: "这张图的 Prompt 已变化；请重新预览后再确认，没有外发。" };
    }
    if (fenceJsonOf(deps.fenceReader(intent.shotId, intent.references)) !== fenceJsonOf(intent.seenFence)) {
      return { reason: "inputs_changed", message: "这张图实际消费的输入已变化；请重新预览后再确认，没有外发。" };
    }
    const profileNow = (() => {
      try { return imagePromptProfile(deps.imageEnvironment()); } catch { return null; }
    })();
    if (canonicalJson(profileNow) !== canonicalJson(intent.seenProvider)) {
      return { reason: "config_changed", message: "图像配置已变化；请重新预览后再确认，没有外发。" };
    }
    return null;
  }

  /**
   * 返工确认：先核对所见意图的当前性，再沿既有 Prompt 落版/OCC 与确认/预约/提交路径执行。
   * 过期意图零持久化、零外发、不自动确认；保留人工全文落新版本，正文不改、历史不覆盖。
   */
  async function confirmRework({ intent }: ConfirmReworkInput): Promise<ConfirmReworkResult> {
    const action = deps.beginAction();
    const ability = deps.promptAbility || null;
    if (!ability) return { kind: "blocked", reason: "no_prompt_ability", message: "返工编译能力缺失，没有外发。" };
    // 提交飞行键必须与确认文档键区分：外层占住 rework:<shot> 会让内层 confirmAndRun
    // 见同键直接 in_flight，造成自己等自己、单次提交也永远 blocked。外层用独立键，
    // 双击仍被外层键挡住，内层键只挡确认/执行的并发。
    const flightKey = "rework-submit:" + intent.shotId;
    if (authorizationInFlight.has(flightKey) || authorizationInFlight.has(REWORK_CONFIRM_PREFIX + intent.shotId)
      || attemptInFlight.has(intent.shotId) || batchState?.active) {
      return { kind: "blocked", reason: "in_flight", message: "返工正在提交；不要重复提交。" };
    }
    const stale = reworkStaleReason(intent);
    if (stale) return { kind: "stale", reason: stale.reason, message: stale.message };
    authorizationInFlight.add(flightKey);
    try {
      if (!action.alive()) return { kind: "blocked", reason: "stale_session" };
      const latest = deps.promptEntryReader(intent.shotId);
      let promptVersion = latest ? latest.version : 0;
      // keep_and_review 也落新版本：正文保留人工稿，但参考图与返工元数据按本次模式重冻结，旧人工版本保留为历史。
      const samePreview = Boolean(latest && latest.record.compiled.rework
        && latest.record.compiled.rework.directive_id === intent.directive.directive_id
        && sameReferenceOrder(latest.record.request_snapshot.references, intent.references));
      if (!samePreview) {
        let savedVersion = 0;
        try {
          const saved = await ability.compileAndSave(intent.shotId, {
            rework: intent.directive, references: [...intent.references],
            promptChoice: intent.promptChoice, action,
          });
          savedVersion = saved.saved.version;
        } catch (error) {
          const staleError = reworkStaleReason(intent);
          if (staleError) return { kind: "stale", reason: staleError.reason, message: staleError.message };
          throw error;
        }
        promptVersion = savedVersion;
        const reread = deps.promptEntryReader(intent.shotId);
        const rereadRework = reread?.record?.compiled?.rework;
        const laned = reread?.version === savedVersion && rereadRework
          && rereadRework.directive_id === intent.directive.directive_id;
        if (!reread || !laned) {
          return { kind: "stale", reason: "prompt_lane_changed",
            message: "落版后 Prompt 不是本次预览；没有外发。", promptVersion };
        }
        if (!action.alive()) return { kind: "blocked", reason: "stale_session", promptVersion };
        const staleAfterSave = reworkStaleReason(intent, { afterSaveVersion: savedVersion });
        if (staleAfterSave) {
          return { kind: "stale", reason: staleAfterSave.reason, message: staleAfterSave.message, promptVersion };
        }
      }
      // 所见摘要与提交仍走冻结的确认/预约/执行路径；跨标签与 Unknown 语义保持不变。
      const all = deps.promptsSheet(null);
      const sheet = deps.promptsSheet([intent.shotId]);
      if (!all || !sheet?.can_submit) {
        return { kind: "stale", reason: "summary_not_ready", message: "这张图当前还有阻断，返工没有外发。", promptVersion };
      }
      const summary = intentForScope([intent.shotId], "rework", all);
      const result = await confirmAndRun({ intent: summary });
      if (result.kind === "stale") {
        return { kind: "stale", reason: result.reason || "summary_changed",
          message: result.message || "摘要已变化；请核对新摘要后再确认返工。", promptVersion };
      }
      if (result.kind === "blocked") {
        return { kind: "blocked", reason: result.reason || "not_ready",
          message: result.message || "返工没有提交；旧候选与已保存 Prompt 不受影响。", promptVersion,
          confirmation: result.confirmation };
      }
      return { kind: "started", confirmation: result.confirmation, promptVersion };
    } finally {
      authorizationInFlight.delete(flightKey);
    }
  }

  /* ------------------------------------------------------------ 传输层 */

  async function blobToBase64(blob: Blob): Promise<string> {
    const buffer = await blob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const chunk = 0x8000;
    for (let index = 0; index < bytes.length; index += chunk) {
      binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
    }
    return btoa(binary);
  }

  /** 提交信封里的同步结果字节：base64 → ArrayBuffer；失败返回 null（绝不伪造字节）。 */
  function base64ToBuffer(base64: string): ArrayBuffer | null {
    try {
      const binary = window.atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return bytes.buffer;
    } catch (error) {
      return null;
    }
  }

  /** 参考图字节从本地仓库读取并转 base64；读不到就不发请求（绝不发半份资料）。 */
  async function buildReferencePayload(references: PromptReferenceSelection[], pid: string): Promise<ReferencePayloadItem[]> {
    const payload: ReferencePayloadItem[] = [];
    for (const item of references) {
      const asset = await repository.assets.get(pid, item.sha256);
      if (!asset || !asset.blob) {
        throw new Error("参考图资产缺失（sha256 " + String(item.sha256).slice(0, 12) + "…），请重新上传。");
      }
      payload.push({
        role: item.role,
        media_type: asset.media_type || "image/png",
        sha256: item.sha256,
        data_base64: await blobToBase64(asset.blob),
      });
    }
    return payload;
  }

  /** 网关调用只返回「信封」；分类一律交给 domain（classifySubmitEnvelope / classifyStatusEnvelope）。 */
  async function postImageJson(path: string, body: unknown, record: AttemptRecord | null,
    requestHeaders?: Record<string, string>): Promise<PostImageResponse> {
    const headers = requestHeaders || deps.requestHeaders("image",
      record?.provider?.provider_id || providerIdFromBody(body),
      record?.execution_identity?.credential_reference?.source);
    let response: Response;
    try {
      response = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...headers },
        body: JSON.stringify(body),
      });
    } catch (error) {
      return { envelope: null, status: 0, transport: true };
    }
    let envelope: unknown = null;
    try {
      envelope = await response.json();
    } catch (error) {
      envelope = null;
    }
    if (!envelope || typeof envelope !== "object") {
      return {
        envelope: {
          ok: false,
          unknown: true,
          error: {
            family: "provider_unknown",
            code: "RESPONSE_UNREADABLE",
            message: "服务端返回 HTTP " + response.status + "，但响应不是约定的 JSON。",
            retry_policy: "requires_review",
          },
        },
        status: response.status,
        transport: false,
      };
    }
    return { envelope: envelope, status: response.status, transport: false };
  }

  /**
   * 取回候选字节：POST /api/v2/images/result。
   * 只接受 200 + image/png；服务端声明的 X-Image-Sha256 与本机重算的 sha256 必须一致，
   * 不一致就不保存（宁可没有候选，也不存不可信字节）。
   */
  async function fetchImageResultBytes(record: AttemptRecord): Promise<FetchedBytes> {
    const gate = attemptReconcileEnvironment(record, attemptProviderIdentity(record));
    if (gate.mode !== ATTEMPT_RECONCILE_MODES.by_task) {
      return {
        ok: false, reason: "environment_blocked",
        message: attemptReconcileBlockedMessage(record),
      };
    }
    let response: Response;
    try {
      response = await fetch(IMAGE_RESULT_PATH, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...deps.requestHeaders("image",
          record.provider.provider_id, record.execution_identity.credential_reference.source) },
        body: JSON.stringify(attemptReconcileRequestOf(record)),
      });
    } catch (error) {
      return {
        ok: false, reason: "transport",
        message: "取回候选时连接中断；记录保持原样，可以重试（不会重新生成）。",
      };
    }
    if (!response.ok) {
      let envelope: unknown = null;
      try {
        envelope = await response.json();
      } catch (error) {
        envelope = null;
      }
      let failureText: string | null = null;
      if (envelope && typeof envelope === "object" && "error" in envelope) {
        const failure = envelope.error;
        if (failure && typeof failure === "object") {
          const family = "family" in failure ? String(failure.family) : "";
          const code = "code" in failure ? String(failure.code) : "";
          const detail = "message" in failure ? String(failure.message) : "";
          failureText = "取回候选失败：" + family + " / " + code + "：" + detail;
        }
      }
      return {
        ok: false, reason: "http", status: response.status,
        message: failureText
          ?? "取回候选失败（HTTP " + response.status + "）；记录保持原样，可以重试。",
      };
    }
    const mediaType = String(response.headers.get("content-type") || "");
    if (!mediaType.includes("image/png")) {
      return {
        ok: false, reason: "bad_media",
        message: "结果不是 PNG（" + (mediaType || "无类型") + "），候选未保存。",
      };
    }
    const buffer = await response.arrayBuffer();
    const sha = await sha256Hex(buffer);
    const declared = String(response.headers.get("x-image-sha256") || "").toLowerCase();
    if (declared && declared !== sha) {
      return {
        ok: false, reason: "hash_mismatch",
        message: "下载字节的 sha256 与服务端声明不一致，候选未保存。",
      };
    }
    return {
      ok: true, buffer: buffer, sha256: sha, media_type: "image/png",
      provider_id: response.headers.get("x-provider-id") || "",
      model_id: response.headers.get("x-model-id") || "",
      task_id: response.headers.get("x-task-id") || record.task_id,
    };
  }


  /* ------------------------------------------------------------ 候选保存 */

  /**
   * 结果字节来源解析（V2.R5.2）：
   * - 同步记录（task_id 为空、冻结 sync === true）：字节只可能在提交信封到达过一次；
   *   模块内 pendingBytesMap 以 action_id 为键暂存（会话内存，不落盘），取走即删。
   *   刷新/关页后 map 必为空 → 明确失败并给出显式补救路径（显式新建 action 或人工核对），
   *   绝不伪造字节、绝不自动把「等待候选」伪装成完成。
   * - 异步记录（有 task_id）：照旧走 result 路由拉取。
   */
  async function pickSyncOrFetchResultBytes(record: AttemptRecord,
    syncBytes: Map<string, SyncBytesEntry> = pendingSyncBytes): Promise<FetchedBytes> {
    const isSync = !(record.task_id)
      && record.execution_identity && record.execution_identity.sync === true;
    if (!isSync) {
      if (!isNonEmptyString(record.task_id)) {
        return { ok: false, reason: "no_result_source", message: "记录既没有 task_id 也不是同步协议，没有可拉取的结果来源。" };
      }
      return fetchImageResultBytes(record);
    }
    const queued = syncBytes.get(record.action_id);
    if (queued) {
      syncBytes.delete(record.action_id);
      const sha = await sha256Hex(queued.buffer);
      if (queued.expectSha && queued.expectSha !== sha) {
        return {
          ok: false, reason: "sync_sha_mismatch",
          message: "同步结果字节哈希与提交信封不一致，候选未保存；请重新生成或人工核对。",
        };
      }
      return { ok: true, buffer: queued.buffer };
    }
    return {
      ok: false, reason: "sync_bytes_missing",
      message: "同步结果是一次性字节，页面刷新后不再可取；人工核对现有结论后，显式新建 action 重新生成。",
    };
  }

  /** 把提交信封里的同步结果字节登记进内存面（action_id 序；取走即删，不持久化）。 */
  function rememberSyncBytes(actionId: string, buffer: ArrayBuffer, expectSha: string | null,
    syncBytes: Map<string, SyncBytesEntry> = pendingSyncBytes): void {
    if (actionId && buffer) {
      syncBytes.set(actionId, { buffer: buffer, expectSha: expectSha || null });
    }
  }

  /**
   * 候选保存核心：把一次成功的生成变成 IndexedDB 里的字节 + 元数据记录。
   * 幂等：同一 action 已有候选则跳过；字节走内容寻址，同 hash 只存一份。
   * 配额不足不产生半份记录：asset 事务失败就没有记录，界面给出可恢复指引。
   */
  async function ensureCandidateStored(shotId: string, options: EnsureCandidateOptions = {}): Promise<StoreCandidateResult> {
    const action = options.action || deps.beginAction();
    if (!action.projectId) return { skipped: true, reason: "no_project" };
    const pid = action.projectId;
    const flights = options.flights || candidateInFlight;
    if (flights.has(shotId)) return { skipped: true, reason: "in_flight" };
    flights.add(shotId);
    const candidates = options.candidates || candidateChainOf(shotId);
    const record = options.record || latestAttemptOf(shotId)?.record;
    // 候选取回失败的原因必须能被界面说清（ui-contract §2.6「失败说明发生了什么、影响哪项、
    // 下一步在哪里」）：批次路径此前只对配额记录 fetchBlocked，其它取回失败原因被丢弃，
    // 用户只看到「候选还没保存」而不知道原因。空串表示当前没有未解决的取回失败。
    const note = (message: string): void => {
      if (batchState) batchState.fetchNotice = message;
    };
    try {
      if (!record) return { skipped: true, reason: "no_attempt" };
      const decision = candidateStoreDecision({
        attempt: record, candidates,
      });
      if (!decision.needed) {
        // 旧候选的确定性报告补建归 adoption（订阅候选变化 / restore），generation 只保全候选。
        return { skipped: true, reason: decision.reason };
      }
      const fetched: FetchedBytes = options.bytes
        ? { ok: true, buffer: options.bytes }
        : await pickSyncOrFetchResultBytes(record, options.syncBytes);
      if (!fetched.ok) {
        note(fetched.message);
        return { failed: true, reason: fetched.reason, message: fetched.message };
      }
      if (fetched.buffer.byteLength > MAX_CANDIDATE_BYTES) {
        note("结果字节超过护栏上限（" + MAX_CANDIDATE_BYTES + " 字节），候选未保存。");
        return {
          failed: true, reason: "too_large",
          message: "结果字节超过护栏上限（" + MAX_CANDIDATE_BYTES + " 字节），候选未保存。",
        };
      }
      let dimensions: { width: number; height: number };
      try {
        dimensions = parsePngDimensions(new Uint8Array(fetched.buffer));
      } catch (error) {
        note(messageOf(error) || "结果不是可解析的 PNG，候选未保存。");
        return {
          failed: true, reason: "bad_bytes",
          message: messageOf(error) || "结果不是可解析的 PNG，候选未保存。",
        };
      }
      try {
        // 候选保存是"上游已完成"的数据保全写：即使会话已切换，也按冻结项目落库。
        const asset = await repository.assets.put(pid, {
          bytes: fetched.buffer,
          mediaType: "image/png",
          originalName: shotId + "-" + record.action_id.slice(0, 8) + ".png",
          role: "candidate",
          width: dimensions.width,
          height: dimensions.height,
        });
        const candidate = buildCandidateRecord({
          shotId: shotId,
          attempt: record,
          assetSha256: asset.sha256,
          byteSize: asset.byte_size,
          width: dimensions.width,
          height: dimensions.height,
          at: new Date().toISOString(),
        });
        const saved = await repository.saveCandidate(pid, shotId, candidate);
        // 取回/保存成功即清掉上一次失败提示：提示必须反映当前是否仍有未保存的候选。
        note("");
        if (action.alive()) {
          rememberCandidate(shotId, { record: candidate, version: saved.version });
        }
        // 候选/资产保全成功即完成；确定性报告由 adoption 单向消费（订阅 + restore），
        // 报告补建失败不改变这里的保存成功结论，也不丢已存图片。
        return {
          stored: true, candidate_id: record.action_id, sha256: asset.sha256,
          width: dimensions.width, height: dimensions.height, byte_size: asset.byte_size,
        };
      } catch (error) {
        if (error !== null && typeof error === "object" && "code" in error && error.code === "QUOTA_EXCEEDED") {
          note("浏览器存储空间不足，候选未保存（记录保持原样）。"
            + "可以先导出项目或清理旧数据，再点「保存候选图片」重试。");
          return {
            failed: true, reason: "quota",
            message: "浏览器存储空间不足，候选未保存（记录保持原样）。"
              + "可以先导出项目或清理旧数据，再点「保存候选图片」重试。",
          };
        }
        note(messageOf(error) || "候选保存失败；记录保持原样，可以重试。");
        return {
          failed: true, reason: "storage",
          message: messageOf(error) || "候选保存失败；记录保持原样，可以重试。",
        };
      }
    } finally {
      flights.delete(shotId);
      if (!options.quiet && action.alive()) notify();
    }
  }

  /* ------------------------------------------------------------ 单张提交 */

  function authorizationUsed(confirmation: ConfirmationQueue, shotId: string): boolean {
    return attemptChainOf(shotId).some(({ record }) =>
      record.authorization?.document_id === confirmation.documentId
      && record.authorization?.version === confirmation.version);
  }

  /* 授权队列：已持久化授权绝不从新模型/最新 Prompt 推断（pending 按冻结链消费）。 */
  /** 队列恢复的同一环境匹配判据（执行与按钮投影共用）：冻结目标 6 键逐字一致 + 已配置。 */
  function confirmationTargetMatched(confirmation: ConfirmationQueue | null | undefined): boolean {
    const target = confirmation?.payload?.fingerprint?.snapshot?.execution_target;
    if (!target) return false;
    const identity = attemptCurrentEnvironmentIdentity(deps.environmentReader(confirmation));
    if (!identity || !identity.configured) return false;
    const keys = ["provider_id", "model_id", "protocol", "capability_version", "credential_source", "sync"] as const;
    return keys.every((key) => identity[key] === (target as unknown as Record<string, unknown>)[key]);
  }

  function confirmationPricingMatchesEnvironment(confirmation: ConfirmationQueue, environment: unknown): boolean {
    const provider = isPlainObject(environment) && isPlainObject(environment.provider) ? environment.provider : null;
    const pricing = provider && isPlainObject(provider.capabilities) ? provider.capabilities.pricing : null;
    return confirmationPricingCurrent(confirmation.payload, pricing);
  }

  /**
   * 队列可继续性：Prompt 版本/hash、当前依据和原请求费用依据仍有效。
   * 费用与实际提交共用 confirmationPricingMatchesEnvironment；价格变化只要求重新确认，
   * 不改写或重新编译原 Prompt。视图读取此投影，不另做费用比较。
   */
  function isConfirmedShotCurrent(confirmation: ConfirmationQueue | null | undefined, shotId: string): boolean {
    if (!confirmation || !shotId) return false;
    const target = confirmation.payload?.fingerprint?.snapshot?.execution_target;
    if (!target) return false;
    const saved = confirmation.payload.shots.find((shot) => shot.shot_id === shotId);
    if (!saved || typeof saved.prompt_version !== "number") return false;
    if (deps.promptEntryReader(shotId)?.version !== saved.prompt_version) return false;
    const entry = deps.promptEntryReader(shotId, saved.prompt_version);
    if (!entry || entry.record.hash !== saved.prompt_hash) return false;
    const shot = deps.suitePlanReader()?.shots?.find((item) => item.shot_id === shotId);
    if (!shot) return false;
    try {
      const environment = deps.environmentReader(confirmation);
      if (!confirmationPricingMatchesEnvironment(confirmation, environment)) return false;
      const profile = imagePromptProfile(environment);
      if (promptStaleness(entry.record, deps.promptBasisReader(shotId, profile)).stale) return false;
      return referencesStillCurrent(shotId, shot, profile, entry.record);
    } catch { return false; }
  }

  /** 原授权仍读精确版本；Prompt 头有意改变时先让用户决定，不改用新版内容。 */
  function pendingConfirmedShots(confirmation: ConfirmationQueue | null | undefined): string[] {
    const snapshot = confirmation?.payload?.fingerprint?.snapshot;
    if (!snapshot?.execution_target) return [];
    // snapshot 来自 confirmation.payload：这条 conf 守卫只收窄类型。
    if (!confirmation || checkConfirmationRecord(confirmation.payload).length) return [];
    const confirmed = confirmation;
    const mode = snapshot.submission_mode;
    const currentIds = new Set((deps.suitePlanReader()?.shots || []).map(shot => shot.shot_id));
    return confirmed.payload.shots.filter(shot => {
      const id = shot.shot_id;
      if (!currentIds.has(id) || authorizationUsed(confirmed, id)) return false;
      const latest = latestAttemptOf(id)?.record;
      if (!latest) return mode !== "failed_retry";
      if ([ATTEMPT_STATES.pending_submit, ATTEMPT_STATES.submitted, ATTEMPT_STATES.running].includes(latest.state)) {
        return mode === "explicit_new" && latest.state === ATTEMPT_STATES.pending_submit && !latest.task_id;
      }
      if (latest.state === ATTEMPT_STATES.unknown) return mode === "explicit_new";
      if (mode === "failed_retry") return latest.state === ATTEMPT_STATES.failed;
      if (mode === "initial") return false;
      return true;
    }).map(shot => shot.shot_id);
  }
  async function performSubmitAttempt(shotId: string, options: SubmitAttemptOptions = {}): Promise<SubmitAttemptResult> {
    // 批次循环传入自己的冻结动作（循环的会话/项目归属）；单张提交在这里冻结。
    const action = options.action || deps.beginAction();
    if (!action.alive() || !action.projectId || !deps.suitePlanReader()) {
      return { skipped: true, reason: "not_ready" };
    }
    const pid = action.projectId;
    const flights = attemptInFlight;
    if (flights.has(shotId)) return { skipped: true, reason: "in_flight" };
    flights.add(shotId);
    const candidateFlights = candidateInFlight;
    const syncBytes = pendingSyncBytes;
    try {
      const confirmation = options.confirmation || deps.confirmationReader(shotId);
      if (!confirmation || !pendingConfirmedShots(confirmation).includes(shotId)) {
        return { skipped: true, reason: "no_confirmation", message: "没有这张图尚未消费的原授权；先核对摘要，不会按新设置猜一个动作。" };
      }
      const confirmSnapshot = confirmation.payload.fingerprint.snapshot;
      const frozenTarget = confirmSnapshot.execution_target;
      // pendingConfirmedShots 已确认该 conf 有冻结目标：这条守卫只收窄类型。
      if (!frozenTarget) return { skipped: true, reason: "no_confirmation" };
      const environment = deps.environmentReader(confirmation);
      const identity = attemptCurrentEnvironmentIdentity(environment);
      if (!identity || !identity.configured) {
        return { skipped: true, reason: "credential_missing", message: "原队列的凭据未就绪；给原目标补凭据，不会改用新动作模型。" };
      }
      const targetKeys = ["provider_id", "model_id", "protocol", "capability_version", "credential_source", "sync"] as const;
      if (targetKeys.some((key) => identity[key] !== frozenTarget[key])) {
        return { skipped: true, reason: "environment_changed", message: "原队列的目标、协议、能力版本或凭据来源不匹配；保持队列，不会切目标外发。" };
      }
      if (!confirmationPricingMatchesEnvironment(confirmation, environment)) {
        return {
          skipped: true, reason: "environment_changed",
          message: "原授权的费用上界缺失或已变化；请核对当前发送摘要并重新确认，原队列与历史保留，没有外发。",
        };
      }
      const requestHeaders = options.requestHeaders || deps.requestHeaders("image", identity.provider_id, identity.credential_source);
      const seenAction = latestAttemptOf(shotId);
      const blocking = seenAction && ["pending_submit", "submitted", "running"].includes(seenAction.record.state)
        ? seenAction.record : null;
      // 显式「放弃核对」只允许放弃没有任务编号、无法核对的 pending 记录；
      // 有 task id 的记录仍然只能先核对（防重复提交的语义不变）。
      const abandonStuck = confirmSnapshot.submission_mode === "explicit_new" && blocking !== null
        && blocking.state === ATTEMPT_STATES.pending_submit && !blocking.task_id;
      if (blocking && !abandonStuck) {
        return { skipped: true, reason: "blocked", blocking: blocking };
      }
      const authorizedPrompt = confirmation.payload.shots.find(shot => shot.shot_id === shotId);
      // pendingConfirmedShots 已确认该 shot 在授权内：这条守卫只收窄类型。
      if (!authorizedPrompt) return { skipped: true, reason: "no_confirmation" };
      const entry = deps.promptEntryReader(shotId, authorizedPrompt.prompt_version);
      if (!entry || entry.record.hash !== authorizedPrompt.prompt_hash) {
        return { skipped: true, reason: "no_prompt", message: "原授权绑定的 Prompt 版本或哈希缺失；不会替换为最新版。" };
      }
      const shot = deps.suitePlanReader()?.shots?.find((item) => item.shot_id === shotId);
      if (!shot) return { skipped: true, reason: "shot_missing" };
      const candidates = candidateChainOf(shotId);
      const profile = imagePromptProfile(environment);
      const snapshot = entry.record.request_snapshot;
      const problems = checkPromptRecord(entry.record);
      if (problems.length || canonicalJson(entry.record.compiled.provider) !== canonicalJson(profile)
          || promptStaleness(entry.record, deps.promptBasisReader(shotId, profile)).stale
          || await promptHash(snapshot, { digest: sha256Hex }) !== entry.record.hash) {
        return {
          skipped: true, reason: "prompt_stale",
          message: "Prompt 与有效图像能力或冻结请求不一致；请重新编译并确认，不会提交。",
        };
      }
      const source = await repository.documents.get(pid, DOMAIN_DOCUMENT_KINDS.generation_confirm,
        confirmation.documentId, confirmation.version) as { payload: ConfirmationRecord } | null;
      if (!source || canonicalJson(source.payload) !== canonicalJson(confirmation.payload)
          || await sha256Hex(new TextEncoder().encode(canonicalJson(source.payload.fingerprint.snapshot)))
            !== source.payload.fingerprint.hash) {
        return { skipped: true, reason: "authorization_missing", message: "IndexedDB 中的原授权版本或指纹不一致，没有外发。" };
      }
      // 实际图序以 Prompt 冻结的 request 为准（初始或返工模式都已在编译期定序）。
      const frozenReferences = snapshot.references;
      if (frozenReferences.length === 0) return { skipped: true, reason: "no_references" };
      if (!referencesStillCurrent(shotId, shot, profile, entry.record)) {
        return {
          skipped: true, reason: "references_changed",
          message: "参考图或返工依据图序已变化；请重新编译并确认，不会替换已确认的参考图后直接提交。",
        };
      }
      let referencePayload: ReferencePayloadItem[];
      try {
        referencePayload = await buildReferencePayload(frozenReferences, pid);
      } catch (error) {
        return {
          skipped: true, reason: "reference_read_failed",
          message: messageOf(error) || "参考图读取失败，没有提交。",
        };
      }
      if (referencePayload.some((item) => !profile.reference_media_types.includes(item.media_type))) {
        return {
          skipped: true, reason: "reference_media_unsupported",
          message: "参考图格式不在当前模型支持范围内；请使用受支持格式后重新确认。",
        };
      }
      const target = {
        provider_id: identity.provider_id, model_id: identity.model_id,
        protocol: identity.protocol, capability_version: identity.capability_version,
      };
      if (canonicalJson(target) !== canonicalJson(snapshot.target)) {
        return {
          skipped: true, reason: "environment_changed",
          message: "执行目标与已确认请求不一致；请按当前目标重新编译并确认。",
        };
      }
      if (!action.alive()) return { skipped: true, reason: "stale_session" };
      if (promptStaleness(entry.record, deps.promptBasisReader(shotId, profile)).stale) {
        return { skipped: true, reason: "prompt_stale", message: "本图实际消费的依据已变化；原 Prompt 保留，没有外发。" };
      }
      const parameters = {
        size: snapshot.size, n: snapshot.n,
        prompt_extend: snapshot.prompt_extend, watermark: snapshot.watermark,
      };
      const actionId = newActionId();
      const at = new Date().toISOString();
      const record = buildAttemptRecord({
        actionId: actionId,
        shotId: shotId,
        prompt: { version: entry.version, hash: entry.record.hash },
        references: frozenReferences,
        provider: { provider_id: identity.provider_id, model_id: identity.model_id },
        executionIdentity: attemptExecutionIdentityFromEnvironment(identity),
        authorization: { document_id: confirmation.documentId, version: confirmation.version,
          hash: confirmation.payload.fingerprint.hash },
        parameters: parameters,
        at: at,
        note: options.explicitNew ? "用户显式新建 action" : (options.note || "用户发起生成"),
      });
      // 事务核对当前来源、所见动作及授权消费；跨标签只有预约赢家可进入外发。
      // 围栏唯一实现是 project-inputs.consumptionFence（经 fenceReader 注入）；
      // 请求一致性（basis.references）仍由 repository.checkGenerationSources 核对。
      const fence = deps.fenceReader(shotId, frozenReferences);
      const saved = await repository.reserveGenerationAttempt({
        projectId: pid, shotId,
        confirmation: { kind: "generation_confirm", documentId: confirmation.documentId, version: confirmation.version },
        seenAction: seenAction ? { actionId: seenAction.record.action_id, version: seenAction.version } : null,
        prompt: { kind: "prompt_version", documentId: shotId, version: entry.version },
        pending: record,
        fence: {
          sources: [...fence.sources,
            { kind: DOMAIN_DOCUMENT_KINDS.prompt_version, documentId: shotId, version: entry.version }],
          projectionJson: fence.projectionJson,
          assetSha256: [...fence.assetSha256, ...frozenReferences.map(item => item.sha256)],
        },
      });
      if (!action.alive()) return { skipped: true, reason: "stale_session", record };
      if (action.alive()) {
        rememberAttempt(shotId, { record: record, version: saved.version });
        notify();
        setStatus("已登记 " + actionId + "（pending_submit），正在提交…");
      }
      const { envelope } = await postImageJson(IMAGE_SUBMIT_PATH, {
        action_id: actionId,
        prompt: snapshot.prompt,
        references: referencePayload,
        size: parameters.size,
        n: snapshot.n,
        prompt_extend: snapshot.prompt_extend,
        watermark: snapshot.watermark,
        output_format: snapshot.output_format,
        model_id: snapshot.model,
        target: { ...snapshot.target, credential_source: identity.credential_source },
      }, record, requestHeaders);
      const outcome = nextFromSubmitEnvelope(record, envelope, { at: new Date().toISOString() });
      // 旧 action 的响应按原预约保全；同 action 并发观察不得回退终态。
      const savedNext = await repository.appendAttemptObservation({
        projectId: pid, shotId, base: { actionId, version: saved.version }, via: "submit", envelope,
      });
      outcome.record = savedNext.payload;
      if (action.alive()) {
        rememberAttempt(shotId, { record: savedNext.payload, version: savedNext.version });
      }
      // 提交直接到终态（成功）时，同一步把候选字节存进 IndexedDB；失败不掩盖提交结论。
      // V2.R5.2 同步协议：信封自带结果字节；先登记进内存面（含信封声明哈希），候选保存
      // 取走时独立重算并核对；不一致则不保存。异步记录没有这个步骤。
      const syncEnvelope = readSyncEnvelope(envelope);
      if (outcome.record.state === ATTEMPT_STATES.succeeded && syncEnvelope) {
        const bytes = base64ToBuffer(syncEnvelope.imageBase64);
        if (!bytes) {
          return { ...outcome.outcome, record: outcome.record, submitted: true,
                   message: "同步结果字节解码失败，候选未保存；请人工核对或重新生成。", candidate: null };
        }
        rememberSyncBytes(actionId, bytes, syncEnvelope.imageSha256, syncBytes);
      }
      let candidate: StoreCandidateResult | null = null;
      if (outcome.record.state === ATTEMPT_STATES.succeeded) {
        candidate = await ensureCandidateStored(shotId, {
          quiet: true, action, record: outcome.record, candidates,
          flights: candidateFlights, syncBytes,
        });
      }
      return { ...outcome.outcome, record: outcome.record, submitted: true, candidate: candidate };
    } catch (error) {
      return {
        thrown: true, state: null, error: null,
        message: messageOf(error) || "提交没有完成；已登记的身份与历史仍然保留。",
      };
    } finally {
      flights.delete(shotId);
      if (action.alive()) notify();
    }
  }

  /* ------------------------------------------------------------ 单张核对 */

  async function performReconcileAttempt(shotId: string, options: ReconcileAttemptOptions = {}): Promise<ReconcileAttemptResult> {
    // 核对只查询上游并推进已有记录；pid 必须来自冻结动作（批次循环传入）。
    const action = options.action || deps.beginAction();
    if (!action.alive() || !action.projectId) return { skipped: true, reason: "in_flight" };
    const pid = action.projectId;
    const flights = attemptInFlight;
    if (flights.has(shotId)) return { skipped: true, reason: "in_flight" };
    flights.add(shotId);
    const candidateFlights = candidateInFlight;
    try {
      const latest = latestAttemptOf(shotId);
      if (!latest || !latest.record.task_id) return { skipped: true, reason: "no_task" };
      const candidates = candidateChainOf(shotId);
      // V2.R4.4：核对先过冻结身份判据——环境漂移或凭据来源失配时不发请求、不重提、不改记录。
      const current = attemptProviderIdentity(latest.record);
      const gate = attemptReconcileEnvironment(latest.record, current);
      if (gate.mode !== ATTEMPT_RECONCILE_MODES.by_task) {
        return {
          skipped: true,
          reason: gate.mode === ATTEMPT_RECONCILE_MODES.blocked_environment
            ? "environment_blocked" : "no_identity",
          message: attemptReconcileBlockedMessage(latest.record),
          gate: gate,
        };
      }
      // 按冻结身份发核对请求：服务端再按同一身份核对目标（EXECUTION_IDENTITY_MISMATCH 兜底）。
      const { envelope } = await postImageJson(IMAGE_STATUS_PATH,
        attemptReconcileRequestOf(latest.record), latest.record);
      const outcome = nextFromStatusEnvelope(latest.record, envelope,
        { at: new Date().toISOString() });
      if (outcome.outcome.advanced) {
        // 核对推进是数据保全写：按冻结项目落库；会话已切换时不回写内存缓存。
        const saved = await repository.appendAttemptObservation({
          projectId: pid, shotId, base: { actionId: latest.record.action_id, version: latest.version },
          via: "query", envelope,
        });
        outcome.record = saved.payload;
        if (action.alive()) {
          rememberAttempt(shotId, { record: saved.payload, version: saved.version });
        }
        // 核对推进到成功时，同一步把候选字节存进 IndexedDB；失败不掩盖核对结论。
        let candidate: StoreCandidateResult | null = null;
        if (outcome.record.state === ATTEMPT_STATES.succeeded) {
          candidate = await ensureCandidateStored(shotId, {
            quiet: true, action, record: outcome.record, candidates, flights: candidateFlights,
          });
        }
        return {
          advanced: true, task_id: latest.record.task_id, state: outcome.record.state,
          candidate: candidate,
        };
      }
      return {
        advanced: false, task_id: latest.record.task_id, state: latest.record.state,
        note: outcome.outcome.note || "记录保持原样",
      };
    } catch (error) {
      return {
        failed: true,
        message: messageOf(error) || "核对没有完成，记录保持原样。",
      };
    } finally {
      flights.delete(shotId);
      if (action.alive()) notify();
    }
  }

  /* ------------------------------------------------------------ 整套批次 */

  function batchStateReader(): BatchRunState | null {
    return batchState;
  }

  /** 批次状态 = 套图顺序 + 每张图最新 Attempt + Prompt 就绪状态的投影；没有第二份状态。 */
  function deriveBatch(): BatchState {
    const summary = deps.suiteSummaryReader();
    const shots = summary ? summary.shots : [];
    const latest: Record<string, AttemptRecord | null> = {};
    for (const item of shots) {
      const entry = latestAttemptOf(item.shot_id);
      latest[item.shot_id] = entry ? entry.record : null;
    }
    return deriveBatchState({
      shots: shots.map((item) => ({ shot_id: item.shot_id, label: item.label })),
      latestAttempts: latest,
      promptReady: (id) => Boolean(deps.promptEntryReader(id)),
      candidateStored: (id) => Boolean(latestStoredCandidateOf(id)),
    });
  }

  function stopBatch(): void {
    if (batchState && batchState.active) batchState.stopped = true;
    notify();
  }

  /**
   * 摘要授权、原确认落库及执行是一个动作；UI 只交出用户看过的那份摘要。
   * owner 内部重算同 scope 的摘要比对（当前性），stale 时返回新摘要且零外发、不自动确认。
   */
  async function confirmAndRun({ intent }: ConfirmAndRunInput): Promise<ConfirmAndRunResult> {
    const action = deps.beginAction();
    if (!action.projectId || !action.alive() || batchState?.active) return { kind: "blocked", reason: "not_ready" };
    if (!intent || intent.projectId !== action.projectId || intent.generation !== action.generation) {
      return { kind: "blocked", reason: "stale_session", message: "项目或会话已切换；这份摘要不再有效，没有外发。" };
    }
    const pid = action.projectId;
    const flights = authorizationInFlight;
    if (flights.has(intent.documentId)) return { kind: "blocked", reason: "in_flight" };
    flights.add(intent.documentId);
    try {
      // intent / sheet / identity 缺一即没有可比对的摘要：与下面 !snapshot 走同一条拒绝。
      if (!intent.sheet || !intent.identity || !intent.identity.configured) {
        throw new Error("摘要与实际发送内容不一致，没有外发。");
      }
      const snapshot = snapshotForSheet(intent.sheet, intent.identity, intent.mode);
      if (canonicalJson(snapshot) !== canonicalJson(intent.snapshot)) {
        throw new Error("摘要与实际发送内容不一致，没有外发。");
      }
      const hash = await promptHash(snapshot, { digest: sha256Hex });
      if (!action.alive()) return { kind: "blocked", reason: "stale_session" };
      // 异步 hash 之后重新核对同一 scope 的当前摘要：变了就返回新摘要，不把新内容当已确认。
      let fresh: GenerationIntent | null = null;
      try {
        const all = deps.promptsSheet(null);
        fresh = all ? intentForScope(intent.scope, intent.mode, all) : null;
      } catch (error) {
        fresh = null;
      }
      if (!fresh || !fresh.snapshot || canonicalJson(fresh.snapshot) !== canonicalJson(intent.snapshot)) {
        return { kind: "stale", reason: "summary_changed",
          message: "摘要已变化或当前未就绪；请核对新摘要后再确认，没有外发。", intent: fresh };
      }
      const payload: ConfirmationRecord = recordOfConfirmation({
        sheet: intent.sheet, hash, confirmedAt: new Date().toISOString(),
        executionIdentity: intent.identity, submissionMode: intent.mode,
        referencesByShot: frozenReferencesByShot(intent.sheet),
      });
      const saved = await repository.documents.save(pid, {
        kind: DOMAIN_DOCUMENT_KINDS.generation_confirm, documentId: intent.documentId,
        payload, expectedVersion: intent.seenVersion,
      });
      const confirmation: ConfirmationQueue = {
        documentId: intent.documentId, payload, version: saved.version,
      };
      if (!action.alive()) return { kind: "started", confirmation, reason: "stale_session" };
      rememberConfirmation(confirmation);
      if (!action.alive()) return { kind: "started", confirmation, reason: "stale_session" };
      notify();
      await runBatch({ confirmation, action });
      return { kind: "started", confirmation };
    } finally {
      flights.delete(intent.documentId);
    }
  }

  /**
   * 同一次授权的单张、整套与返工共用队列。停止只停新增提交，不取消上游。
   */
  async function runBatch({ confirmation, action = deps.beginAction() }: RunBatchInput = {}): Promise<void> {
    if (!action.alive() || !action.projectId || !deps.suitePlanReader() || batchState?.active) return;
    clearNoticeError();
    const queue = pendingConfirmedShots(confirmation);
    if (!queue.length) {
      setNoticeError("原队列没有可新增提交的图；Unknown 只核对或明确另发，不自动重提。");
      return;
    }
    // 队列非空即保证确认与冻结目标存在：这条守卫只收窄类型。
    if (!confirmation || !confirmation.payload.fingerprint.snapshot.execution_target) return;
    const frozenTarget = confirmation.payload.fingerprint.snapshot.execution_target;
    const requestHeaders = deps.requestHeaders("image", frozenTarget.provider_id, frozenTarget.credential_source);
    const running: BatchRunState = { active: true, stopped: false, halted: false, haltReason: "", fetchBlocked: "",
      fetchNotice: "", currentShotId: null, phase: "submit" };
    batchState = running;
    notify();
    let submitted = 0;
    const skipped: string[] = [];
    try {
      for (const shotId of queue) {
        if (!action.alive() || running.stopped || running.halted) break;
        running.currentShotId = shotId;
        notify();
        const outcome = await performSubmitAttempt(shotId, {
          action, confirmation, requestHeaders, note: "用户一次授权的原队列提交",
        });
        if (!action.alive()) return;
        if (outcome.skipped) {
          const reason = outcome.reason || "";
          skipped.push(shotId + "：" + (outcome.message || reason));
          if (["credential_missing", "environment_changed", "authorization_missing", "stale_session"].includes(reason)) {
            running.halted = true;
            running.haltReason = outcome.message || reason;
          }
          continue;
        }
        submitted += 1;
        if (outcome.thrown || batchSubmitHalts(outcome)) {
          running.halted = true;
          running.haltReason = outcome.message || outcome.error?.message || "提交没有可确认结论";
          break;
        }
        await pollActiveAttempts({ action });
      }
      if (action.alive()) {
        running.phase = "poll";
        running.currentShotId = null;
        await pollActiveAttempts({ action });
      }
    } catch (error) {
      if (action.alive()) {
        running.halted = true;
        running.haltReason = messageOf(error) || "批次执行出现异常";
      }
    } finally {
      if (action.alive()) {
        const finished = running;
        // 停止/暂停是合同要求可见的状态（ui-contract §3「已停止新增」）：
        // 保留一个 active=false 的快照，renderBatch 才能持续显示停止/暂停与「已提交的记录全部保留」；
        // 置 null 会让随后的 renderAttempts 通用文案立刻覆盖它（实测 #batch-progress 从未出现停止提示）。
        // 轮询判定改用 live 快照（见 pollActiveAttempts），所以这里不改变核对语义。
        batchState = { ...finished, active: false };
        notify();
        const result = deriveBatch();
        setStatus((finished?.stopped ? "已停止新增提交；" : finished?.halted ? "已暂停（" + finished.haltReason + "）；" : "本批结束；")
          + "已提交 " + submitted + " 张；" + batchProgressText(result)
          + (skipped.length ? "；未提交：" + skipped.join("；") : "")
          + "。原授权、未提交队列与所有历史记录保留。");
      }
    }
  }

  /** 轮询在途记录（只查询、不重提）。批次运行中循环到没有可核对的记录为止。 */
  async function pollActiveAttempts(options: PollActiveAttemptsOptions = {}): Promise<void> {
    const intervalMs = options.intervalMs || BATCH_POLL_INTERVAL_MS;
    const maxRounds = options.maxRounds || BATCH_POLL_MAX_ROUNDS;
    const once = options.once === true;
    // 动作归属：批次传入自己的冻结动作；独立核对在这里冻结。
    const action = options.action || deps.beginAction();
    // 只有运行中的批次快照才参与停止/暂停判定：批次结束后快照仍保留（供 UI 显示停止/暂停），
    // 但不得因此让后续独立核对（reconcileOnce）变成空操作。
    const live = batchState && batchState.active ? batchState : null;
    for (let round = 0; round < maxRounds; round += 1) {
      if (live && live.halted) return;
      if (!action.alive()) return;
      const state = deriveBatch();
      if (state.reconcile_queue.length === 0 && state.fetch_queue.length === 0) return;
      if (live) { live.phase = "poll"; notify(); }
      for (const shotId of state.reconcile_queue) {
        if (live && live.halted) return;
        if (!action.alive()) return;
        await performReconcileAttempt(shotId, { action });
      }
      if (!action.alive()) return;
      // 候选保存：配额受阻时记录原因并停本轮保存；核对路径不受影响。
      if (!(live && live.fetchBlocked)) {
        const fetchState = deriveBatch();
        for (const shotId of fetchState.fetch_queue) {
          if (!action.alive()) return;
          if (live) {
            live.currentShotId = shotId;
            live.phase = "fetch";
            notify();
          }
          const stored = await ensureCandidateStored(shotId, { action });
          if (!action.alive()) return;
          if (stored && stored.failed && stored.reason === "quota") {
            if (live) {
              live.fetchBlocked = stored.message || "";
              // 本地存储放不下候选时继续轮询没有意义：这一张会一直停在取回队列，
              // 界面却显示"正在按任务编号核对"（其实没有在途任务可核对），
              // 而提示区让用户点的手动按钮在批次结束前不可用。与其它无法继续的情形一致：
              // 保留记录，停批次，把原因与下一步交给提示区。
              live.halted = true;
              live.haltReason = stored.message || "候选保存受阻";
              return;
            }
            break;
          }
        }
      }
      if (!action.alive()) return;
      notify();
      if (once) return;
      // 停止只停新增提交：已提交的身份仍然各查一次，给出当前结论后不再轮询。
      if (live && live.stopped) return;
      const after = deriveBatch();
      if (after.reconcile_queue.length === 0 && after.fetch_queue.length === 0) return;
      if (round === maxRounds - 1 && live) {
        live.halted = true;
        live.haltReason = "上游长时间没有结论，已停止自动核对；记录仍在，可继续核对";
        return;
      }
      await new Promise<void>((resolve) => {
        window.setTimeout(() => { resolve(); }, intervalMs);
      });
    }
  }

  /** 批量的「核对进行中」：所有有任务编号的在途记录各查一次，不重提。 */
  async function reconcileOnce(): Promise<void> {
    clearNoticeError();
    const before = deriveBatch();
    if (before.reconcile_queue.length === 0) {
      setNoticeError("没有可按任务编号核对的记录。");
      return;
    }
    try {
      await pollActiveAttempts({ once: true });
    } catch (error) {
      setNoticeError(messageOf(error) || "核对没有完成，记录保持原样。");
      return;
    }
    const after = deriveBatch();
    setStatus("已核对 " + before.reconcile_queue.length + " 张："
      + batchProgressText(after));
  }

  return {
    // 链读取(渲染投影用)
    attemptChainOf, latestAttemptOf, allAttemptRecords,
    candidateChainOf, latestStoredCandidateOf,
    candidateForAttemptOf,
    // 执行接口(UI 只转发)
    submitAttempt: performSubmitAttempt,
    reconcileAttempt: performReconcileAttempt,
    storeCandidate: ensureCandidateStored,
    buildReferencePayload,
    // 批次
    deriveBatch, batchStateReader, runBatch, reconcileOnce,
    confirmAndRun, stopBatch,
    isConfirmedShotCurrent, restore,
    enterFailedRetry: (shotIds) => {
      authorizationScope = [...shotIds];
      authorizationMode = "failed_retry";
    },
    enterExplicitNew: (shotId) => {
      authorizationScope = [shotId];
      const state = latestAttemptOf(shotId)?.record.state;
      authorizationMode = state === ATTEMPT_STATES.succeeded ? "rework"
        : state === ATTEMPT_STATES.failed ? "failed_retry" : "explicit_new";
    },
    hasCurrent: hasCurrentQueue,
    shotHasCurrent: shotHasCurrentQueue,
    confirmationFor: confirmationForOf,
    queues: queuesView,
    prepareSummary,
    prepareRework, confirmRework,
    // 只读文案投影与投影变化通知（视图订阅；不注入 DOM 回调）
    notice: () => ({ status: noticeStatus, error: noticeError }),
    subscribe: (listener) => {
      listeners.add(listener);
      return () => { listeners.delete(listener); };
    },
    // 飞行标识（渲染投影用）
    isAttemptInFlight: (shotId) => attemptInFlight.has(shotId),
    isCandidateInFlight: (shotId) => candidateInFlight.has(shotId),
    attemptChainsNow: () => Array.from(attemptChains.entries()),
    reset,
  };
}
