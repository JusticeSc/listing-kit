/**
 * Product V2 生成前确认与外发资料摘要（V2.3.5，计划 §9.8）。
 *
 * 唯一权威：确认单形状、阻断码、外发资料摘要、风险传播、指纹与失效判定都在本文件。
 * 复用而不是重写：
 *  - 过期判定复用 prompt.js 的 promptStaleness；记录合法性复用 checkPromptRecord；
 *  - 依赖判定复用 suite-plan.js 的 evaluateShot；
 *  - 散列复用调用方注入的 sha256Hex（storage/db.js），本层不写第二种散列。
 * 本层是纯函数：不调用模型、不写存储、不发请求。
 */

import { DOMAIN_ERROR_CODES, invalid } from "./errors.js";
import {
  ATTEMPT_CREDENTIAL_SOURCES,
  ATTEMPT_PROTOCOL_PATTERN,
} from "./attempt.js";
import {
  isNonEmptyString,
  isPlainObject,
  isSha256Hex,
  pushProblem,
} from "./shared.js";
import {
  PLATFORM_PROFILES,
  canonicalJson,
  checkImagePromptProfile,
  checkPromptRecord,
  promptStaleness,
} from "./prompt.js";
import { evaluateShot, roleDefinition } from "./suite-plan.js";

export const CONFIRM_SCHEMA_VERSION = 2;
/** 历史合同的只读分支版本（快照可能缺冻结执行目标）。 */
export const CONFIRM_LEGACY_SCHEMA_VERSION = 1;
export const CONFIRM_DOCUMENT_ID = "generation";
const SUBMISSION_MODES = Object.freeze(["initial", "failed_retry", "rework", "explicit_new"]);

export const CONFIRM_BLOCKER_CODES = Object.freeze({
  PROMPT_MISSING: "PROMPT_MISSING",
  PROMPT_RECORD_INVALID: "PROMPT_RECORD_INVALID",
  PROMPT_TEXT_MISMATCH: "PROMPT_TEXT_MISMATCH",
  PROMPT_STALE: "PROMPT_STALE",
  DEPENDENCY_UNSATISFIED: "DEPENDENCY_UNSATISFIED",
  PLATFORM_MISMATCH: "PLATFORM_MISMATCH",
  PROVIDER_MISMATCH: "PROVIDER_MISMATCH",
  REFERENCE_COUNT_INVALID: "REFERENCE_COUNT_INVALID",
  PRICING_UNAVAILABLE: "PRICING_UNAVAILABLE",
});

/** 精确修改位置：阻断必须能指回一个可操作区域。 */
export const FIX_REGIONS = Object.freeze([
  "intake", "understanding", "suite", "style", "shot_spec", "prompt", "model_settings",
]);

const SUMMARY_FIELDS = Object.freeze([
  "model", "size", "n", "prompt_extend", "watermark", "output_format",
  "reference_count", "reference_roles", "prompt_chars",
]);

function fixTarget(region, shotId, label, action) {
  return { region, shot_id: shotId === undefined ? null : shotId, label, action };
}

function blockingText(blocking) {
  return (Array.isArray(blocking) ? blocking : [])
    .map((item) => (item && (item.reason || item.message)) || "依据未满足")
    .join("；");
}

/** 过期原因字段 → 用户该去改哪里；不允许只说“过期了”。 */
function fixForStaleReason(reason, shotId, label) {
  const field = String((reason && reason.field) || "");
  if (field.indexOf("brief.") === 0) {
    return fixTarget("understanding", shotId, label,
      "到「商品理解」确认或修改槽位 " + field.slice("brief.".length) + "，再重新编译这张图的 Prompt。");
  }
  if (field === "style_version") {
    return fixTarget("style", shotId, label, "到「风格与单图规格」复核公共风格，再重新编译这张图的 Prompt。");
  }
  if (field === "shot_spec_version") {
    return fixTarget("shot_spec", shotId, label, "到「风格与单图规格」复核这张图的单图规格，再重新编译。");
  }
  if (field === "suite_version") {
    return fixTarget("suite", shotId, label, "到「套图规划」复核这张图，再重新编译。");
  }
  if (field === "platform") {
    return fixTarget("prompt", shotId, label, "平台档已更新，重新编译这张图的 Prompt。");
  }
  if (field === "provider") {
    return fixTarget("prompt", shotId, label, "有效 Provider 档或请求参数已更新，重新编译这张图的 Prompt。");
  }
  return fixTarget("prompt", shotId, label, "到「Prompt 预览与版本」重新编译这张图（原因：" + (field || "未知") + "）。");
}


function isSafeNonNegativeInteger(value) {
  return Number.isInteger(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER;
}

function isPricingAmountValid(value, { requiredInteger = false } = {}) {
  if (value === null || value === undefined) return false;
  return requiredInteger ? isSafeNonNegativeInteger(value)
    : (Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER);
}

/** 价格元数据校验：provider/model 身份必须等于当前有效档；真假分支各有形状门。 */
function checkCostQuoteMetadata(pricing, provider) {
  const problems = [];
  if (!isPlainObject(pricing)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing", "缺少官方价格信息：不能确认发送。");
    return problems;
  }
  if (pricing.currency !== "CNY") {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.currency", "价格币种必须是 CNY。");
  }
  if (pricing.provider_id !== provider.provider_id || pricing.model_id !== provider.model_id) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.model_id",
      "价格信息不属于当前有效模型（" + provider.provider_id + "/" + provider.model_id + "）：不能确认发送。");
  }
  const amountsOk = isPricingAmountValid(pricing.input_image_fen, { requiredInteger: true })
    && isPricingAmountValid(pricing.output_image_fen, { requiredInteger: true });
  if (!amountsOk) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.input_image_fen",
      "官方价格金额必须是安全非负整数（分）：不能确认发送。");
  }
  if (pricing.test_double === true) {
    if (pricing.source_url !== null || pricing.verified_at !== null) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.source_url",
        "测试替身价格不能冒充官方价格依据。");
    }
    if (!(pricing.input_image_fen === 0 && pricing.output_image_fen === 0)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.output_image_fen",
        "测试替身价格只能是零费用演练。");
    }
  } else if (pricing.test_double === false) {
    if (!(typeof pricing.source_url === "string" && pricing.source_url.indexOf("https://") === 0)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.source_url",
        "真实价格必须带官方 HTTPS 价格依据。");
    }
    const verifiedAt = pricing.verified_at;
    if (typeof verifiedAt !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(verifiedAt)
        || !Number.isFinite(Date.parse(verifiedAt))
        || new Date(verifiedAt).toISOString().slice(0, 10) !== verifiedAt) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.verified_at",
        "真实价格必须带有效的 ISO 核对日期。");
    }
  } else {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.pricing.test_double",
      "价格信息必须明确是否测试替身。");
  }
  return problems;
}

function pricingUnavailableReason(pricing, provider) {
  if (pricing === null || pricing === undefined) {
    return "当前模型目标没有已核实的价格信息，不能计算费用上界，也不能确认发送。";
  }
  if (!isPlainObject(pricing)) return "价格信息形状不合法，不能确认发送。";
  const first = checkCostQuoteMetadata(pricing, provider)[0];
  if (first) return first.message;
  return "价格信息不合法，不能确认发送。";
}

/** 报价算术：只计冻结请求快照的去重参考图与快照 n；整数分运算溢出即拒绝。 */
function checkCostQuoteArithmetic(quote, pricing, { path = "$.external_summary.cost_quote" } = {}) {
  const problems = [];
  if (!isPlainObject(quote)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "费用上界报价形状不合法。");
    return problems;
  }
  let expectedInput = 0;
  let expectedOutput = 0;
  let expectedBound = 0;
  const shots = Array.isArray(quote.shots) ? quote.shots : null;
  if (!shots || shots.length === 0) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + ".shots",
      "费用上界必须逐图列出每张图的输入/输出数量。");
    return problems;
  }
  for (let index = 0; index < shots.length; index += 1) {
    const item = shots[index];
    const itemPath = path + ".shots[" + index + "]";
    if (!isPlainObject(item) || !isNonEmptyString(item.shot_id)
        || !isSafeNonNegativeInteger(item.input_images) || !isSafeNonNegativeInteger(item.output_images)
        || !isSafeNonNegativeInteger(item.upper_bound_fen)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath,
        "逐图费用必须带 shot_id 与非负整数的输入/输出数量与上界（分）。");
      return problems;
    }
    const expected = item.input_images * pricing.input_image_fen + item.output_images * pricing.output_image_fen;
    if (!Number.isSafeInteger(expected) || expected !== item.upper_bound_fen) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".upper_bound_fen",
        "逐图费用上界必须等于输入数×输入单价＋输出数×输出单价（分）。");
      return problems;
    }
    expectedInput = addChecked(expectedInput, item.input_images);
    expectedOutput = addChecked(expectedOutput, item.output_images);
    expectedBound = addChecked(expectedBound, item.upper_bound_fen);
    if (expectedInput === null || expectedOutput === null || expectedBound === null) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + ".upper_bound_fen",
        "费用上界合计超出安全整数范围，不能确认发送。");
      return problems;
    }
  }
  if (quote.input_images !== expectedInput || quote.output_images !== expectedOutput
      || quote.upper_bound_fen !== expectedBound) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + ".upper_bound_fen",
      "费用上界合计必须等于逐图上界的精确求和。");
  }
  return problems;
}

function addChecked(left, right) {
  const sum = left + right;
  return Number.isSafeInteger(sum) ? sum : null;
}

/** 确认单报价一致性：新单必须显式写 cost_quote 字段；有值即验算术与逐图计费口径。 */
function checkSheetCostQuote(sheet, shots) {
  const problems = [];
  const summary = isPlainObject(sheet) ? sheet.external_summary : null;
  if (!isPlainObject(summary)) return problems;
  if (!("cost_quote" in summary)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.cost_quote",
      "新确认单必须显式写费用上界（cost_quote）；缺失需要重新生成确认单。");
    return problems;
  }
  const quote = summary.cost_quote;
  if (quote === null) {
    if (sheet.can_submit === true) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.cost_quote",
        "费用上界缺失时不能确认发送。");
    }
    return problems;
  }
  if (!isPlainObject(quote)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.cost_quote",
      "费用上界报价形状不合法。");
    return problems;
  }
  const provider = isPlainObject(sheet.provider) ? sheet.provider : {};
  problems.push(...checkCostQuoteMetadata(quote, provider));
  problems.push(...checkCostQuoteArithmetic(quote, quote));
  if (problems.length > 0) return problems;
  const byShot = new Map();
  for (const item of Array.isArray(quote.shots) ? quote.shots : []) {
    if (isPlainObject(item) && isNonEmptyString(item.shot_id)) byShot.set(item.shot_id, item);
  }
  if (byShot.size !== shots.length) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.cost_quote.shots",
      "费用上界必须逐图覆盖本次确认的每张图。");
    return problems;
  }
  for (const [index, item] of shots.entries()) {
    if (!isPlainObject(item) || !isNonEmptyString(item.shot_id)) continue;
    const row = byShot.get(item.shot_id);
    const rowPath = "$.external_summary.cost_quote.shots[" + index + "]";
    if (!row) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, rowPath,
        "费用上界缺少 " + item.shot_id + " 的逐图报价。");
      return problems;
    }
    const billing = isPlainObject(item.billing) ? item.billing : null;
    const expectedInput = billing && isSafeNonNegativeInteger(billing.input_images) ? billing.input_images
      : (Array.isArray(item.references) ? item.references.length : null);
    const expectedOutput = billing && isSafeNonNegativeInteger(billing.output_images) ? billing.output_images
      : (Number.isInteger(provider.n) ? provider.n : null);
    if (row.input_images !== expectedInput || row.output_images !== expectedOutput) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, rowPath,
        "逐图费用数量必须等于该图冻结请求的实际输入/输出数量。");
      return problems;
    }
  }
  return problems;
}

const PRICING_METADATA_FIELDS = Object.freeze([
  "currency", "provider_id", "model_id", "input_image_fen", "output_image_fen",
  "source_url", "verified_at", "test_double",
]);

/**
 * 原队列费用依据是否仍有效：读确认记录保存的报价元数据，与当前原目标价格逐字段比对。
 * 纯函数：旧记录缺报价可读但返回 false；当前价格非法或任一元数据字段变化也返回 false。
 * 不比较费用合计与剩余张数：原队列用原始固定报价范围，算术由记录校验器负责。
 * @param {unknown} confirmation 确认记录（含 external_summary.cost_quote）
 * @param {unknown} pricing 原目标当前价格（capabilities.pricing）
 * @returns {boolean}
 */
export function confirmationPricingCurrent(confirmation, pricing) {
  const quote = isPlainObject(confirmation) && isPlainObject(confirmation.external_summary)
    ? confirmation.external_summary.cost_quote : undefined;
  if (!isPlainObject(quote)) return false;
  if (!isPlainObject(pricing)) return false;
  const saved = {};
  for (const field of PRICING_METADATA_FIELDS) saved[field] = quote[field];
  const providerOf = (value) => (isPlainObject(value)
    ? { provider_id: value.provider_id, model_id: value.model_id } : {});
  if (checkRecordCostQuote(quote, "$.cost_quote").length > 0) return false;
  if (checkCostQuoteMetadata(pricing, providerOf(pricing)).length > 0) return false;
  if (checkCostQuoteMetadata(saved, providerOf(pricing)).length > 0) return false;
  return PRICING_METADATA_FIELDS.every((field) => pricing[field] === quote[field]);
}

/** 历史记录报价门：缺字段可读（旧确认），有值即验元数据与算术，不编造旧报价。 */
function checkRecordCostQuote(quote, path) {
  const problems = [];
  if (quote === undefined || quote === null) return problems;
  if (!isPlainObject(quote) || !Array.isArray(quote.shots) || quote.shots.length === 0) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "费用上界报价形状不合法。");
    return problems;
  }
  if (quote.currency !== "CNY" || !isNonEmptyString(quote.provider_id) || !isNonEmptyString(quote.model_id)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "费用上界必须带币种与模型身份。");
    return problems;
  }
  if (quote.test_double === true) {
    if (quote.source_url !== null || quote.verified_at !== null
        || !(quote.input_image_fen === 0 && quote.output_image_fen === 0)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
        "测试替身报价不能冒充官方价格依据。");
      return problems;
    }
  } else if (quote.test_double === false) {
    const sourceOk = typeof quote.source_url === "string" && quote.source_url.indexOf("https://") === 0;
    const quoteDateOk = typeof quote.verified_at === "string" && /^\d{4}-\d{2}-\d{2}$/.test(quote.verified_at)
      && !Number.isNaN(Date.parse(quote.verified_at))
      && new Date(quote.verified_at).toISOString().slice(0, 10) === quote.verified_at;
    if (!sourceOk || !quoteDateOk) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
        "真实报价必须带官方 HTTPS 价格依据与有效 ISO 核对日期。");
    }
  } else {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "报价必须明确是否测试替身。");
    return problems;
  }
  if (!isPricingAmountValid(quote.input_image_fen, { requiredInteger: true })
      || !isPricingAmountValid(quote.output_image_fen, { requiredInteger: true })) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "报价金额必须是安全非负整数（分）。");
    return problems;
  }
  if (!isSafeNonNegativeInteger(quote.input_images) || !isSafeNonNegativeInteger(quote.output_images)
      || !isSafeNonNegativeInteger(quote.upper_bound_fen)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "报价合计必须是安全非负整数（分）。");
    return problems;
  }
  problems.push(...checkCostQuoteArithmetic(quote, quote, { path: path }));
  return problems;
}

/**
 * 生成前确认单：这是“将要提交给外部模型的东西”的唯一投影。
 * 输出是确定性的：相同输入必然产生逐字相同的对象（键序由本函数决定）。
 */
export function buildConfirmationSheet(input = {}) {
  if (!isPlainObject(input)) invalid("生成前确认需要输入对象。");
  const plan = input.suitePlan;
  if (!isPlainObject(plan) || !Array.isArray(plan.shots)) {
    invalid("生成前确认需要合法的套图计划（shots 数组）。");
  }
  const platform = PLATFORM_PROFILES[input.platformId || "amazon_us"];
  if (!platform) invalid("平台档不存在：" + String(input.platformId));
  const provider = input.providerProfile;
  const profileProblems = checkImagePromptProfile(provider);
  if (profileProblems.length > 0) {
    invalid("生成前确认缺少有效 Provider 档：" + profileProblems[0].message,
      { problems: profileProblems.slice(0, 3) });
  }
  const context = isPlainObject(input.context) ? input.context : {};
  const currentBasisByShot = isPlainObject(input.currentBasisByShot) ? input.currentBasisByShot : {};
  const pricing = input.pricing === undefined ? null : input.pricing;
  const pricingProblems = checkCostQuoteMetadata(pricing, provider);
  const pricingUsable = pricingProblems.length === 0;
  const pricingReason = pricingUsable ? "" : pricingUnavailableReason(pricing, provider);
  // 可选作用域（V2.5.4 单图返工）：只确认要重跑的那张图，不触及其它图片的确认状态。
  const scopeShotIds = Array.isArray(input.shotIds) && input.shotIds.length > 0
    ? [...new Set(input.shotIds.filter((item) => isNonEmptyString(item)))] : null;
  const entries = new Map();
  for (const item of Array.isArray(input.promptEntries) ? input.promptEntries : []) {
    if (isPlainObject(item) && isNonEmptyString(item.shot_id)) entries.set(item.shot_id, item);
  }

  const shots = [];
  for (const [index, shot] of plan.shots.entries()) {
    if (!isPlainObject(shot)) continue;
    if (scopeShotIds && !scopeShotIds.includes(shot.shot_id)) continue;
    const shotId = shot.shot_id;
    const label = isNonEmptyString(shot.label) ? shot.label : String(shotId);
    const role = roleDefinition(shot.role_id);
    const blockers = [];
    const risks = [];
    const dependency = evaluateShot(shot, context);
    if (!dependency.satisfied) {
      blockers.push({
        code: CONFIRM_BLOCKER_CODES.DEPENDENCY_UNSATISFIED,
        message: "依据未满足：" + blockingText(dependency.blocking),
        fix: fixTarget("suite", shotId, label,
          "到「套图规划」补齐依据（上传缺失素材或确认缺失事实），或删除、替换这张图。"),
      });
    }
    const prompt = { version: null, hash: null, chars: null };
    const billing = { input_images: null, output_images: null };
    let references = [];
    const entry = entries.get(shotId) || null;
    if (!entry) {
      blockers.push({
        code: CONFIRM_BLOCKER_CODES.PROMPT_MISSING,
        message: "还没有 Prompt 版本，无法生成。",
        fix: fixTarget("prompt", shotId, label, "到「Prompt 预览与版本」为这张图编译并保存版本。"),
      });
    } else {
      const record = entry.record;
      const problems = checkPromptRecord(record);
      if (problems.length > 0) {
        blockers.push({
          code: CONFIRM_BLOCKER_CODES.PROMPT_RECORD_INVALID,
          message: problems[0].message,
          details: problems.slice(0, 3),
          fix: fixTarget("prompt", shotId, label, "重新编译这张图的 Prompt（旧版本已保留）。"),
        });
      } else {
        prompt.version = typeof entry.version === "number" ? entry.version : null;
        prompt.hash = record.hash;
        prompt.chars = record.compiled.text.length;
        const snapshot = record.request_snapshot;
        if (snapshot.prompt !== record.compiled.text) {
          blockers.push({
            code: CONFIRM_BLOCKER_CODES.PROMPT_TEXT_MISMATCH,
            message: "请求快照的 prompt 与编译文本不一致。",
            fix: fixTarget("prompt", shotId, label, "重新编译这张图的 Prompt。"),
          });
        }
        const compiledPlatform = record.compiled.platform || {};
        if (compiledPlatform.platform_id !== platform.platform_id
            || compiledPlatform.version !== platform.version) {
          blockers.push({
            code: CONFIRM_BLOCKER_CODES.PLATFORM_MISMATCH,
            message: "这张图的 Prompt 用的是 " + String(compiledPlatform.platform_id)
              + "@" + String(compiledPlatform.version) + "，当前平台档是 "
              + platform.platform_id + "@" + platform.version + "。",
            fix: fixTarget("prompt", shotId, label, "按当前平台档重新编译这张图的 Prompt。"),
          });
        }
        const compiledProvider = record.compiled.provider || {};
        // 比对完整冻结档（目标 / 协议 / 版本 / 请求参数），而非只比 model+version。
        if (canonicalJson(compiledProvider) !== canonicalJson(provider)) {
          blockers.push({
            code: CONFIRM_BLOCKER_CODES.PROVIDER_MISMATCH,
            message: "这张图的 Prompt 冻结的是 " + String(compiledProvider.model_id)
              + "@" + String(compiledProvider.version) + "（协议 " + String(compiledProvider.protocol)
              + "），当前有效 Provider 档是 " + provider.model_id + "@" + provider.version
              + "（协议 " + provider.protocol + "）。",
            fix: fixTarget("prompt", shotId, label, "按当前有效 Provider 档重新编译这张图的 Prompt。"),
          });
        }
        const snapshotRefs = Array.isArray(snapshot.references) ? snapshot.references : [];
        if (snapshotRefs.length < 1 || snapshotRefs.length > provider.max_reference_images) {
          blockers.push({
            code: CONFIRM_BLOCKER_CODES.REFERENCE_COUNT_INVALID,
            message: "参考图数量 " + snapshotRefs.length + " 不在 1.." + provider.max_reference_images + " 之间。",
            fix: fixTarget("intake", shotId, label, "到「商品资料」补齐参考图（至少一张主图）。"),
          });
        } else {
          billing.input_images = new Set(snapshotRefs.map((item) => String(item.sha256 || ""))).size;
          billing.output_images = snapshot.n;
        }
        references = snapshotRefs.map((item) => ({
          role: item.role,
          sha256_prefix: String(item.sha256 || "").slice(0, 12),
        }));
        const basis = currentBasisByShot[shotId];
        if (!isPlainObject(basis)) {
          blockers.push({
            code: CONFIRM_BLOCKER_CODES.PROMPT_STALE,
            message: "无法核对这张图的当前编译依据，不能提交。",
            fix: fixTarget("prompt", shotId, label, "重新编译这张图的 Prompt 以建立可核对的依据。"),
          });
        } else {
          const staleness = promptStaleness(record, basis);
          if (staleness.stale) {
            blockers.push({
              code: CONFIRM_BLOCKER_CODES.PROMPT_STALE,
              message: "Prompt 已过期：" + staleness.reasons.map((item) => item.field).join("、"),
              details: staleness.reasons,
              fix: fixForStaleReason(staleness.reasons[0], shotId, label),
            });
          }
        }
        for (const warning of Array.isArray(record.compiled.warnings) ? record.compiled.warnings : []) {
          risks.push({
            code: warning.code,
            message: warning.message,
            shot_id: shotId,
            label: label,
          });
        }
      }
    }
    if (!pricingUsable) {
      blockers.push({
        code: CONFIRM_BLOCKER_CODES.PRICING_UNAVAILABLE,
        message: pricingReason,
        fix: fixTarget("model_settings", shotId, label,
          "打开「模型设置」核对图像模型目标与官方计费信息；价格未核实前不能确认发送。"),
      });
    }

    shots.push({
      shot_id: shotId,
      order: index + 1,
      label: label,
      role_id: shot.role_id === undefined ? null : shot.role_id,
      role_label: role ? role.label : null,
      intent: isNonEmptyString(shot.intent) ? shot.intent : null,
      template_id: shot.template_id === undefined ? null : shot.template_id,
      required: shot.required === true,
      satisfied: dependency.satisfied,
      prompt: prompt,
      references: references,
      billing: billing,
      risks: risks,
      blockers: blockers,
    });
  }

  const blockedShots = shots.filter((item) => item.blockers.length > 0);
  const referenceRoles = [...new Set(shots.flatMap((item) => item.references.map((ref) => ref.role)))];
  const referenceCount = shots.reduce((total, item) => total + item.references.length, 0);
  const promptChars = shots.reduce((total, item) => total + (item.prompt.chars || 0), 0);
  // 费用上界：只在“价格可用且每图都有确切计费口径”时给出；少任一条件即 null 并逐图阻断。
  const everyBillingKnown = shots.length > 0 && shots.every((item) => isSafeNonNegativeInteger(item.billing.input_images)
    && isSafeNonNegativeInteger(item.billing.output_images));
  let costQuote = null;
  if (pricingUsable && everyBillingKnown) {
    const rows = [];
    let inputTotal = 0;
    let outputTotal = 0;
    let boundTotal = 0;
    let overflow = false;
    for (const item of shots) {
      const rowBound = item.billing.input_images * pricing.input_image_fen
        + item.billing.output_images * pricing.output_image_fen;
      if (!Number.isSafeInteger(rowBound)) { overflow = true; break; }
      inputTotal = addChecked(inputTotal, item.billing.input_images);
      outputTotal = addChecked(outputTotal, item.billing.output_images);
      boundTotal = addChecked(boundTotal, rowBound);
      if (inputTotal === null || outputTotal === null || boundTotal === null) { overflow = true; break; }
      rows.push({ shot_id: item.shot_id, input_images: item.billing.input_images,
        output_images: item.billing.output_images, upper_bound_fen: rowBound });
    }
    if (!overflow && rows.length === shots.length) {
      costQuote = {
        currency: pricing.currency, provider_id: pricing.provider_id, model_id: pricing.model_id,
        input_image_fen: pricing.input_image_fen, output_image_fen: pricing.output_image_fen,
        source_url: pricing.source_url, verified_at: pricing.verified_at, test_double: pricing.test_double,
        input_images: inputTotal, output_images: outputTotal, upper_bound_fen: boundTotal, shots: rows,
      };
    }
  }
  if (costQuote === null && pricingUsable && shots.length > 0 && blockedShots.length === 0) {
    invalid("费用上界无法计算：每张图都必须有确切的冻结参考图与输出数量。");
  }
  const externalSummary = {
    model: provider.model_id,
    size: provider.size,
    n: provider.n,
    prompt_extend: provider.prompt_extend,
    watermark: provider.watermark,
    output_format: provider.output_format,
    reference_count: referenceCount,
    reference_roles: referenceRoles,
    prompt_chars: promptChars,
    on_image_text_language: platform.on_image_text_language,
    statement: "生成时将向 " + provider.model_id + " 发送 " + shots.length + " 条提示词（合计 "
      + promptChars + " 字）与 " + referenceCount + " 张参考图（角色："
      + (referenceRoles.length > 0 ? referenceRoles.join("、") : "无") + "）；参数 "
      + provider.size + " / n=" + provider.n + " / prompt_extend=" + String(provider.prompt_extend)
      + " / watermark=" + String(provider.watermark) + " / 输出格式 " + provider.output_format
      + "；图中文字语言 " + platform.on_image_text_language + "。",
    cost_quote: costQuote,
  };

  return {
    schema_version: CONFIRM_SCHEMA_VERSION,
    platform: { platform_id: platform.platform_id, version: platform.version, label: platform.label },
    provider: {
      provider_id: provider.provider_id,
      model_id: provider.model_id,
      version: provider.version,
      protocol: provider.protocol,
      size: provider.size,
      n: provider.n,
      prompt_extend: provider.prompt_extend,
      watermark: provider.watermark,
      output_format: provider.output_format,
    },
    total: shots.length,
    ready: shots.length - blockedShots.length,
    blocked: blockedShots.length,
    can_submit: shots.length > 0 && blockedShots.length === 0,
    shots: shots,
    external_summary: externalSummary,
    ...(scopeShotIds ? { scope_shot_ids: scopeShotIds } : {}),
    blockers: shots.flatMap((item) => item.blockers.map((blocker) => ({
      shot_id: item.shot_id,
      label: item.label,
      order: item.order,
      code: blocker.code,
      message: blocker.message,
      fix: blocker.fix,
    }))),
    risks: shots.flatMap((item) => item.risks),
  };
}

/** 确认单自检：计数、聚合与外发摘要必须彼此一致。 */
export function checkConfirmationSheet(sheet) {
  const problems = [];
  if (!isPlainObject(sheet)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "确认单必须是对象。");
    return problems;
  }
  if (sheet.schema_version !== CONFIRM_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "确认单版本不认识：" + String(sheet.schema_version));
  }
  if (!isPlainObject(sheet.platform) || !isNonEmptyString(sheet.platform.platform_id)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.platform", "确认单缺少平台档。");
  }
  if (!isPlainObject(sheet.provider) || !isNonEmptyString(sheet.provider.model_id)
      || !isNonEmptyString(sheet.provider.provider_id)
      || !isNonEmptyString(sheet.provider.protocol)
      || !isNonEmptyString(sheet.provider.output_format)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.provider",
      "确认单缺少完整 Provider 档（目标 / 协议 / 输出格式）。");
  }
  if (sheet.scope_shot_ids !== undefined) {
    if (!Array.isArray(sheet.scope_shot_ids) || sheet.scope_shot_ids.length === 0
        || sheet.scope_shot_ids.some((item) => !isNonEmptyString(item))) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.scope_shot_ids",
        "作用域必须是至少一张图的 shot_id 数组。");
    }
  }
  const shots = Array.isArray(sheet.shots) ? sheet.shots : null;
  if (!shots) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.shots", "确认单缺少 shots 数组。");
    return problems;
  }
  const blockedCount = shots.filter((item) => Array.isArray(item.blockers) && item.blockers.length > 0).length;
  if (sheet.total !== shots.length || sheet.blocked !== blockedCount || sheet.ready !== shots.length - blockedCount) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.total",
      "确认单计数与实际图片不一致。");
  }
  if (sheet.can_submit !== (shots.length > 0 && blockedCount === 0)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.can_submit",
      "can_submit 必须等于「至少一张图且没有阻断」。");
  }
  let referenceCount = 0;
  let promptChars = 0;
  shots.forEach((item, index) => {
    const itemPath = "$.shots[" + index + "]";
    if (!isPlainObject(item) || !isNonEmptyString(item.shot_id)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath, "确认单图片缺少 shot_id。");
      return;
    }
    if (!Array.isArray(item.blockers) || !Array.isArray(item.risks)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".blockers", "blockers/risks 必须是数组。");
      return;
    }
    item.blockers.forEach((blocker, blockerIndex) => {
      const blockerPath = itemPath + ".blockers[" + blockerIndex + "]";
      if (!isPlainObject(blocker) || !isNonEmptyString(blocker.code)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, blockerPath, "阻断缺少 code。");
        return;
      }
      if (!isPlainObject(blocker.fix) || !FIX_REGIONS.includes(blocker.fix.region)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, blockerPath + ".fix",
          "阻断必须带可操作的 fix 位置。");
      }
    });
    if (isPlainObject(item.prompt) && item.prompt.version !== null
        && !isSha256Hex(item.prompt.hash)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".prompt.hash",
        "有版本的 Prompt 必须带 sha256 hash。");
    }
    if (Array.isArray(item.references)) {
      referenceCount += item.references.length;
    }
    if (isPlainObject(item.prompt) && typeof item.prompt.chars === "number") {
      promptChars += item.prompt.chars;
    }
  });
  const summary = sheet.external_summary;
  if (!isPlainObject(summary)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary", "确认单缺少外发摘要。");
  } else {
    if (summary.model !== (sheet.provider || {}).model_id || summary.size !== (sheet.provider || {}).size
        || summary.output_format !== (sheet.provider || {}).output_format) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.model",
        "外发摘要的参数必须来自 Provider 档。");
    }
    if (summary.reference_count !== referenceCount || summary.prompt_chars !== promptChars) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.reference_count",
        "外发摘要必须等于各图参考图与提示词字符的合计。");
    }
    problems.push(...checkSheetCostQuote(sheet, shots));
  }
  return problems;
}

export function assertConfirmationSheet(sheet) {
  const problems = checkConfirmationSheet(sheet);
  if (problems.length > 0) {
    invalid("生成前确认单不合法：" + problems[0].message, { problems: problems.slice(0, 5) });
  }
  return sheet;
}

function confirmationExecutionTarget(identity, provider) {
  if (!isPlainObject(identity) || !isNonEmptyString(identity.provider_id)
      || !isNonEmptyString(identity.model_id)
      || !ATTEMPT_PROTOCOL_PATTERN.test(identity.protocol)
      || !Number.isInteger(identity.capability_version) || identity.capability_version < 1
      || !ATTEMPT_CREDENTIAL_SOURCES.includes(identity.credential_source)
      || typeof identity.sync !== "boolean") {
    invalid("生成授权缺少可核对的原目标、协议、能力版本或凭据来源。");
  }
  if (!isPlainObject(provider) || provider.model_id !== identity.model_id
      || provider.version !== identity.capability_version
      || (provider.provider_id !== undefined && provider.provider_id !== identity.provider_id)
      || (provider.protocol !== undefined && provider.protocol !== identity.protocol)) {
    invalid("生成授权目标与已显示的 Prompt 有效档不一致。");
  }
  return {
    provider_id: identity.provider_id, model_id: identity.model_id,
    protocol: identity.protocol, capability_version: identity.capability_version,
    credential_source: identity.credential_source, sync: identity.sync,
  };
}

/**
 * 指纹输入：覆盖“这一批将要提交的东西”，不包含展示文案。
 * v2：每图带实际冻结参考图身份（有序 role + 完整 sha256），把“这一批真正发送的图序”也纳入指纹；
 * execution_target/submission_mode 只在给出 executionIdentity 时写入，历史记录可缺。
 * @param {unknown} sheet
 * @param {{executionIdentity?: unknown, submissionMode?: unknown,
 *          referencesByShot?: Record<string, import("./type-contracts.js").PromptReferenceSelection[]>}} [options]
 * @returns {import("./type-contracts.js").ConfirmationSnapshot}
 */
export function confirmationSnapshot(sheet, { executionIdentity = null, submissionMode = "initial",
                                             referencesByShot = null } = {}) {
  assertConfirmationSheet(sheet);
  if (executionIdentity && !SUBMISSION_MODES.includes(submissionMode)) invalid("生成授权缺少明确的动作类型。");
  const byShot = isPlainObject(referencesByShot) ? referencesByShot : null;
  return {
    schema_version: CONFIRM_SCHEMA_VERSION,
    ...(executionIdentity ? {
      execution_target: confirmationExecutionTarget(executionIdentity, sheet.provider),
      submission_mode: submissionMode,
    } : {}),
    ...(Array.isArray(sheet.scope_shot_ids) && sheet.scope_shot_ids.length > 0
      ? { scope_shot_ids: [...sheet.scope_shot_ids] } : {}),
    platform: { platform_id: sheet.platform.platform_id, version: sheet.platform.version },
    provider: { model_id: sheet.provider.model_id, version: sheet.provider.version },
    can_submit: sheet.can_submit === true,
    shots: sheet.shots.map((item) => {
      const frozen = byShot && Array.isArray(byShot[item.shot_id]) ? byShot[item.shot_id] : [];
      return {
        shot_id: item.shot_id,
        prompt_version: item.prompt.version,
        prompt_hash: item.prompt.hash,
        prompt_chars: item.prompt.chars,
        reference_roles: item.references.map((ref) => ref.role),
        references: frozen.map((ref) => ({ role: ref.role, sha256: ref.sha256 })),
        blocked: item.blockers.map((blocker) => blocker.code),
      };
    }),
    external_summary: {
      model: sheet.external_summary.model,
      size: sheet.external_summary.size,
      n: sheet.external_summary.n,
      prompt_extend: sheet.external_summary.prompt_extend,
      watermark: sheet.external_summary.watermark,
      output_format: sheet.external_summary.output_format,
      reference_count: sheet.external_summary.reference_count,
      reference_roles: [...sheet.external_summary.reference_roles],
      prompt_chars: sheet.external_summary.prompt_chars,
      cost_quote: sheet.external_summary.cost_quote === null ? null
        : JSON.parse(JSON.stringify(sheet.external_summary.cost_quote)),
    },
  };
}

export function confirmationSnapshotJson(sheet) {
  return canonicalJson(confirmationSnapshot(sheet));
}

/**
 * 确认失效判定：与当前确认单快照逐字段比较，给出可读原因。
 * 与 promptStaleness 同形（{stale, reasons[]}），界面可以共用一套渲染。
 */
export function confirmationStaleness(record, currentSnapshot) {
  const stored = isPlainObject(record) && isPlainObject(record.fingerprint)
    ? record.fingerprint.snapshot : null;
  if (!stored) {
    return { stale: true, reasons: [{ field: "fingerprint", stored: null, current: null, reason: "确认记录缺少指纹。" }] };
  }
  const now = isPlainObject(currentSnapshot) ? currentSnapshot : null;
  if (!now) {
    return { stale: true, reasons: [{ field: "fingerprint", stored: null, current: null, reason: "没有可比较的当前确认单。" }] };
  }
  if (canonicalJson(stored) === canonicalJson(now)) return { stale: false, reasons: [] };
  const reasons = [];
  if (((stored.platform || {}).version) !== ((now.platform || {}).version)) {
    reasons.push({ field: "platform", stored: (stored.platform || {}).version ?? null,
                   current: (now.platform || {}).version ?? null, reason: "平台档版本前进" });
  }
  if (((stored.provider || {}).version) !== ((now.provider || {}).version)) {
    reasons.push({ field: "provider", stored: (stored.provider || {}).version ?? null,
                   current: (now.provider || {}).version ?? null, reason: "Provider 档版本前进" });
  }
  const storedShots = new Map((Array.isArray(stored.shots) ? stored.shots : []).map((item) => [item.shot_id, item]));
  const nowShots = new Map((Array.isArray(now.shots) ? now.shots : []).map((item) => [item.shot_id, item]));
  for (const [shotId, item] of nowShots) {
    const before = storedShots.get(shotId);
    if (!before) {
      reasons.push({ field: "shots." + shotId, stored: null, current: item.prompt_version, reason: "新增图片" });
      continue;
    }
    if (before.prompt_hash !== item.prompt_hash || before.prompt_version !== item.prompt_version) {
      reasons.push({ field: "shots." + shotId, stored: before.prompt_version, current: item.prompt_version,
                     reason: "该图 Prompt 已变化" });
    }
    if (canonicalJson(before.blocked || []) !== canonicalJson(item.blocked || [])) {
      reasons.push({ field: "shots." + shotId, stored: before.blocked || [], current: item.blocked || [],
                     reason: "该图阻断状态变化" });
    }
    if (canonicalJson(before.references || []) !== canonicalJson(item.references || [])) {
      reasons.push({ field: "shots." + shotId + ".references",
                     stored: (before.references || []).map((ref) => ref.sha256 || null),
                     current: (item.references || []).map((ref) => ref.sha256 || null),
                     reason: "该图实际冻结参考图变化" });
    }
  }
  for (const [shotId] of storedShots) {
    if (!nowShots.has(shotId)) {
      reasons.push({ field: "shots." + shotId, stored: shotId, current: null, reason: "图片已删除" });
    }
  }
  const beforeSummary = stored.external_summary || {};
  const nowSummary = now.external_summary || {};
  for (const key of SUMMARY_FIELDS) {
    const before = key === "reference_roles" ? canonicalJson(beforeSummary[key] || []) : beforeSummary[key];
    const after = key === "reference_roles" ? canonicalJson(nowSummary[key] || []) : nowSummary[key];
    if (before !== after) {
      reasons.push({ field: "external_summary." + key, stored: before, current: after, reason: "外发摘要变化" });
    }
  }
  if (canonicalJson(beforeSummary.cost_quote === undefined ? null : beforeSummary.cost_quote)
      !== canonicalJson(nowSummary.cost_quote === undefined ? null : nowSummary.cost_quote)) {
    const quoteReasonOf = (quote) => {
      if (quote === undefined || quote === null) return "缺失";
      return "上界 " + String(quote.upper_bound_fen) + " 分（"
        + String(quote.input_images) + " 输入/" + String(quote.output_images) + " 输出）";
    };
    reasons.push({ field: "external_summary.cost_quote",
      stored: quoteReasonOf(beforeSummary.cost_quote), current: quoteReasonOf(nowSummary.cost_quote),
      reason: "费用上界变化（价格/来源/计费数量）" });
  }
  if (Boolean(stored.can_submit) !== Boolean(now.can_submit)) {
    reasons.push({ field: "can_submit", stored: Boolean(stored.can_submit), current: Boolean(now.can_submit),
                   reason: "提交条件变化" });
  }
  if (reasons.length === 0) {
    reasons.push({ field: "fingerprint", stored: "stored", current: "current", reason: "确认单内容变化" });
  }
  return { stale: true, reasons: reasons };
}

/**
 * 确认记录：确认是“用户对某一具体输入的显式确认”，所以它绑定指纹而不是绑定时间。
 * @param {{sheet?: unknown, hash?: unknown, confirmedAt?: unknown, executionIdentity?: unknown,
 *          submissionMode?: unknown, referencesByShot?: Record<string, import("./type-contracts.js").PromptReferenceSelection[]>}} [args]
 * @returns {import("./type-contracts.js").ConfirmationRecord}
 */
export function buildConfirmationRecord({ sheet, hash, confirmedAt, executionIdentity = null,
                                          submissionMode = "initial", referencesByShot = null } = {}) {
  assertConfirmationSheet(sheet);
  if (sheet.can_submit !== true) {
    invalid("还有 " + sheet.blocked + " 张图未就绪，不能确认生成。");
  }
  if (!isPlainObject(sheet.external_summary) || !isPlainObject(sheet.external_summary.cost_quote)) {
    invalid("费用上界缺失：没有已核实的报价不能确认发送。");
  }
  if (!isSha256Hex(hash)) invalid("确认记录缺少有效 fingerprint hash。");
  if (typeof confirmedAt !== "string" || confirmedAt.length < 20 || Number.isNaN(Date.parse(confirmedAt))) {
    invalid("确认记录需要 ISO 时间戳。");
  }
  return {
    schema_version: CONFIRM_SCHEMA_VERSION,
    confirmed_at: confirmedAt,
    fingerprint: { snapshot: confirmationSnapshot(sheet, { executionIdentity, submissionMode, referencesByShot }), hash: hash },
    platform: { platform_id: sheet.platform.platform_id, version: sheet.platform.version },
    provider: { model_id: sheet.provider.model_id, version: sheet.provider.version },
    total: sheet.total,
    external_summary: sheet.external_summary,
    shots: sheet.shots.map((item) => ({
      shot_id: item.shot_id,
      label: item.label,
      prompt_version: item.prompt.version,
      prompt_hash: item.prompt.hash,
      references: item.references,
      risks: item.risks.map((risk) => risk.code),
    })),
    risks: sheet.risks.map((risk) => ({ shot_id: risk.shot_id, code: risk.code })),
  };
}

export function checkConfirmationRecord(record) {
  const problems = [];
  if (!isPlainObject(record)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "确认记录必须是对象。");
    return problems;
  }
  const version = record.schema_version;
  if (version !== CONFIRM_SCHEMA_VERSION && version !== CONFIRM_LEGACY_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "确认记录版本不认识：" + String(version));
  }
  // v2：每图必须带有序的实际冻结参考图身份（role + 完整 sha256）；历史 v1 无此块，按原分支校验。
  const requireFrozenRefs = version >= CONFIRM_SCHEMA_VERSION;
  if (typeof record.confirmed_at !== "string" || Number.isNaN(Date.parse(record.confirmed_at))) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.confirmed_at", "确认记录缺少 ISO 时间戳。");
  }
  if (!isPlainObject(record.fingerprint) || !isSha256Hex(record.fingerprint.hash)
      || !isPlainObject(record.fingerprint.snapshot)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.fingerprint",
      "确认记录必须带 {snapshot, hash} 指纹。");
  } else {
    const expected = canonicalJson(record.fingerprint.snapshot);
    if (!isNonEmptyString(expected)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.fingerprint.snapshot", "指纹快照不可序列化。");
    }
    if (record.fingerprint.snapshot.can_submit !== true) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.fingerprint.snapshot.can_submit",
        "只有可提交的确认单才能写确认记录。");
    }
    if (record.fingerprint.snapshot.execution_target !== undefined) {
      try {
        if (!SUBMISSION_MODES.includes(record.fingerprint.snapshot.submission_mode)) invalid("生成授权缺少动作类型。");
        confirmationExecutionTarget(record.fingerprint.snapshot.execution_target, record.fingerprint.snapshot.provider);
      } catch (error) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.fingerprint.snapshot.execution_target",
          error.message);
      }
    }
    if (requireFrozenRefs) {
      const snapshotShots = record.fingerprint.snapshot.shots;
      if (!Array.isArray(snapshotShots) || snapshotShots.length === 0) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.fingerprint.snapshot.shots",
          "v2 确认快照必须包含逐图冻结参考图身份。");
      } else {
        snapshotShots.forEach((item, index) => {
          const path = "$.fingerprint.snapshot.shots[" + index + "].references";
          const refs = isPlainObject(item) ? item.references : null;
          if (!Array.isArray(refs) || refs.length === 0) {
            pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
              "v2 每图必须带有序的实际冻结参考图（role + 完整 sha256）。");
            return;
          }
          refs.forEach((ref, refIndex) => {
            if (!isPlainObject(ref) || !isNonEmptyString(ref.role) || !isSha256Hex(ref.sha256)) {
              pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + "[" + refIndex + "]",
                "冻结参考图需要 role 与 64 位 sha256。");
            }
          });
        });
      }
    }
  }
  if (!Array.isArray(record.shots) || record.shots.length === 0) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.shots", "确认记录必须包含每图指纹。");
  } else {
    record.shots.forEach((item, index) => {
      if (!isPlainObject(item) || !isNonEmptyString(item.shot_id) || !isSha256Hex(item.prompt_hash)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.shots[" + index + "]",
          "每图指纹需要 shot_id 与 prompt_hash。");
      }
    });
  }
  if (record.total !== (Array.isArray(record.shots) ? record.shots.length : -1)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.total", "确认记录张数与逐图指纹不一致。");
  }
  if (!isPlainObject(record.external_summary)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary", "确认记录缺少外发摘要。");
  } else {
    problems.push(...checkRecordCostQuote(record.external_summary.cost_quote, "$.external_summary.cost_quote"));
    const snapshotSummary = isPlainObject(record.fingerprint) && isPlainObject(record.fingerprint.snapshot)
      ? record.fingerprint.snapshot.external_summary : null;
    if (isPlainObject(snapshotSummary) && "cost_quote" in snapshotSummary) {
      problems.push(...checkRecordCostQuote(snapshotSummary.cost_quote, "$.fingerprint.snapshot.external_summary.cost_quote"));
      const recordQuote = record.external_summary.cost_quote;
      if (recordQuote !== undefined && canonicalJson(recordQuote) !== canonicalJson(snapshotSummary.cost_quote)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.external_summary.cost_quote",
          "确认记录的费用上界必须与指纹快照逐字一致。");
      }
    }
  }
  return problems;
}
