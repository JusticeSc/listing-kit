/**
 * V2.5.5 返工：固定问题分类、改进方向与返工指令（唯一权威）。
 *
 * 返工不是「重新生成整张图」的自由文本，而是把「这次要改什么」固化成一条绑定
 * 候选字节 + 明确问题候选 + 用户方向的 ReworkDirective，再交给 Prompt 编译器作为独立段落。
 * 设计 §13.6 的双模式：edit_candidate（默认，把问题候选原 Blob 作为第 1 图交给模型编辑）
 * 与 regenerate_original（只发商品原参考依据，问题候选只是诊断记录）。模式不属于出站供应商
 * 字段，只进入项目内冻结/摘要/归因链。
 * 本模块不写存储、不调用模型、不改 ShotSpec；旧 Prompt 版本与旧候选一律保留。
 * 历史 v2.5.4 / schema 1 指令仍按原分支只读校验，不补造 mode，不原地改写。
 */
import { DOMAIN_ERROR_CODES, invalid } from "./errors.js";
import { REVIEW_CONTRACT_VERSION, topFinding } from "./review.js";
import { isIsoTimestamp, isNonEmptyString, isPlainObject, isSha256Hex,
         pushProblem } from "./shared.js";

export const REWORK_SCHEMA_VERSION = 2;
export const REWORK_CONTRACT_VERSION = "v2.5.5";
/** 历史合同的只读分支版本（schema 1）；新动作一律写当前合同。 */
export const REWORK_LEGACY_SCHEMA_VERSION = 1;
export const REWORK_LEGACY_CONTRACT_VERSION = "v2.5.4";
export const REWORK_DIRECTION_MIN = 4;
export const REWORK_DIRECTION_MAX = 300;

/** 双模式（设计 §13.6）；顺序即界面默认序，第一项为默认。 */
export const REWORK_MODES = Object.freeze(
  /** @type {import("./type-contracts.js").ReworkMode[]} */ (["edit_candidate", "regenerate_original"]));

export const REWORK_MODE_LABELS = Object.freeze({
  edit_candidate: "编辑当前候选",
  regenerate_original: "按商品原照重新生成",
});

/** 模式的中文标签；未声明/未知返回空串（历史记录不猜模式）。 @param {unknown} mode @returns {string} */
export function reworkModeLabel(mode) {
  return isNonEmptyString(mode) && Object.hasOwn(REWORK_MODE_LABELS, mode)
    ? REWORK_MODE_LABELS[mode] : "";
}

/** 指令声明的模式；历史 schema 1 或未知模式返回 null（显示「旧记录未声明模式」）。 @param {unknown} directive @returns {import("./type-contracts.js").ReworkMode | null} */
export function reworkModeOf(directive) {
  if (!isPlainObject(directive) || directive.schema_version !== REWORK_SCHEMA_VERSION) return null;
  return REWORK_MODES.indexOf(directive.mode) === -1 ? null : directive.mode;
}

/**
 * 固定问题分类（计划 §8.3）：问题是对现象的分类，改进方向是本次要改变什么。
 * @typedef {{id: import("./type-contracts.js").ReworkProblemId, label: string, hint: string}} ReworkProblem
 * @type {Readonly<ReworkProblem[]>}
 */
export const REWORK_PROBLEMS = Object.freeze([
  { id: "product_fidelity", label: "商品失真", hint: "颜色、材质、比例、标识或部件与参考图不一致" },
  { id: "part_error", label: "部件错误", hint: "多出、缺失、错位的部件或穿模" },
  { id: "scene", label: "场景", hint: "背景或使用场景不合适" },
  { id: "composition", label: "构图", hint: "主体大小、角度、留白或版式不合适" },
  { id: "selling_point", label: "卖点表达", hint: "卖点没表达清楚或表达错了" },
  { id: "text", label: "文字", hint: "图中文字乱码、错字或不符合平台语言" },
  { id: "style", label: "风格", hint: "与整套公共风格不一致" },
  { id: "platform_risk", label: "平台风险", hint: "尺寸、背景、水印、禁止内容等平台规则问题" },
  { id: "other", label: "其他", hint: "上面的分类都不合适，用方向写清楚" },
]);

export const REWORK_PROBLEM_IDS = Object.freeze(
  /** @type {import("./type-contracts.js").ReworkProblemId[]} */ (REWORK_PROBLEMS.map((item) => item.id)));

const PROBLEM_BY_ID = Object.freeze(REWORK_PROBLEMS.reduce((table, item) => {
  table[item.id] = item;
  return table;
}, /** @type {Record<string, ReworkProblem>} */ ({})));

/** 复核规则 → 问题分类：只用于预选，用户可以改。
 * @type {Readonly<Record<string, import("./type-contracts.js").ReworkProblemId>>}
 */
export const REWORK_RULE_PROBLEM = Object.freeze({
  "candidate.png_contract": "platform_risk",
  "platform.min_long_side": "platform_risk",
  "platform.recommended_long_side": "platform_risk",
  "platform.main_square": "platform_risk",
  "platform.alpha_channel": "platform_risk",
  "candidate.pixel_depth": "platform_risk",
  "vlm.product_fidelity": "product_fidelity",
  "vlm.part_anomaly": "part_error",
  "vlm.deformity": "product_fidelity",
  "vlm.clipping": "part_error",
  "vlm.garbled_text": "text",
  "vlm.goal_completion": "composition",
  "vlm.prohibited_content": "platform_risk",
});

/**
 * @param {string} id
 * @returns {string}
 */
export function reworkProblemLabel(id) {
  const entry = PROBLEM_BY_ID[id];
  return entry ? entry.label : String(id);
}

/**
 * @param {string} id
 * @returns {string}
 */
export function reworkProblemHint(id) {
  const entry = PROBLEM_BY_ID[id];
  return entry ? entry.hint : "";
}

/** 报告先看项建议的问题分类；没有发现时返回空数组（用户自己选）。
 * @param {unknown} report
 * @returns {import("./type-contracts.js").ReworkProblemId[]}
 */
export function suggestReworkProblems(report) {
  const top = topFinding(report);
  if (!top) return [];
  const mapped = REWORK_RULE_PROBLEM[top.rule_id];
  return mapped ? [mapped] : [];
}

/**
 * 建议方向：把先看项翻译成一句可编辑的默认文案。
 * 不用「」包住标题，避免与编译器「逐字引用」的括号约定互相干扰。
 * @param {unknown} report
 * @returns {string}
 */
export function suggestedReworkDirection(report) {
  const top = topFinding(report);
  if (!top) return "";
  const detail = String(top.detail || "").slice(0, 80);
  return "上一版被标记为（" + String(top.title || top.rule_id) + "）：" + detail
    + " 只修改这一点，其余部分保持与参考图一致。";
}

/** 方向文本归一：把引号字符换成括号，保证它作为逐字引用内容时括号不互相干扰。
 * @param {unknown} direction
 * @returns {string}
 */
export function normalizeReworkDirection(direction) {
  if (direction === null || direction === undefined) return "";
  return String(direction)
    .replace(/[「『]/g, "（")
    .replace(/[」』]/g, "）")
    .replace(/[\r\n\t]+/g, " ")
    .trim();
}

/**
 * 返工指令：绑定「哪一张图、哪一条候选（含原文档版本）、用哪种模式、因为什么、要改成什么」。
 * problems 与 direction 至少要有一个；两者都留空等于没有返工理由，直接拒绝。
 * mode 必须显式给出（新动作一律写 v2.5.5；不替用户猜模式）。
 * @param {{directiveId?: unknown, shotId?: unknown, candidate?: unknown, candidateVersion?: unknown,
 *          mode?: unknown, report?: unknown,
 *          problems?: unknown, direction?: unknown, at?: unknown}} [args]
 * @returns {import("./type-contracts.js").ReworkDirectiveV2}
 */
export function buildReworkDirective({ directiveId, shotId, candidate, candidateVersion, mode, report,
                                       problems, direction, at } = {}) {
  if (!isNonEmptyString(directiveId)) invalid("返工指令需要唯一 ID。");
  if (!isNonEmptyString(shotId)) invalid("返工指令需要 shot_id。");
  if (!isPlainObject(candidate) || !isNonEmptyString(candidate.candidate_id)
      || !isSha256Hex(candidate.asset_sha256)) {
    invalid("返工指令必须绑定一条候选（candidate_id + sha256）。");
  }
  if (candidate.shot_id !== shotId) invalid("这条候选不属于这张图，不能用它做返工依据。");
  if (!isNonEmptyString(mode) || REWORK_MODES.indexOf(mode) === -1) {
    invalid("返工指令必须声明明确模式：" + REWORK_MODES.join("/") + "。");
  }
  if (!Number.isInteger(candidateVersion) || candidateVersion < 1) {
    invalid("返工指令必须绑定候选的原文档版本（正整数）。");
  }
  const list = Array.isArray(problems)
    ? [...new Set(problems.filter((item) => isNonEmptyString(item)))] : [];
  const unknown = list.filter((id) => REWORK_PROBLEM_IDS.indexOf(id) === -1);
  if (unknown.length > 0) invalid("未知的问题分类：" + unknown.join("、"));
  const text = normalizeReworkDirection(direction);
  if (list.length === 0 && text.length === 0) {
    invalid("返工至少要选一个问题分类，或写一句改进方向。");
  }
  if (text.length > 0 && (text.length < REWORK_DIRECTION_MIN || text.length > REWORK_DIRECTION_MAX)) {
    invalid("改进方向需要在 " + REWORK_DIRECTION_MIN + "–" + REWORK_DIRECTION_MAX + " 字之间。");
  }
  if (!isIsoTimestamp(at)) invalid("返工指令需要 ISO 时间（at）。");
  const top = isPlainObject(report) ? topFinding(report) : null;
  return Object.freeze({
    schema_version: REWORK_SCHEMA_VERSION,
    contract_version: REWORK_CONTRACT_VERSION,
    directive_id: directiveId,
    shot_id: shotId,
    candidate_id: candidate.candidate_id,
    candidate_sha256: candidate.asset_sha256,
    mode: mode,
    problem_candidate: Object.freeze({
      candidate_id: candidate.candidate_id,
      document_id: shotId,
      version: candidateVersion,
      asset_sha256: candidate.asset_sha256,
    }),
    problems: Object.freeze(list),
    direction: text,
    source: Object.freeze({
      candidate_id: candidate.candidate_id,
      asset_sha256: candidate.asset_sha256,
      review_contract_version: isPlainObject(report) && isNonEmptyString(report.review_contract_version)
        ? report.review_contract_version : null,
      top_rule_id: top ? top.rule_id : null,
      top_severity: top ? top.severity : null,
    }),
    created_at: at,
  });
}

/** 返工指令形状检查；返回问题清单（空数组 = 合法）。
 * @param {unknown} directive
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkReworkDirective(directive) {
  /** @type {import("./type-contracts.js").DomainProblem[]} */
  const problems = [];
  if (!isPlainObject(directive)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "返工指令必须是对象。");
    return problems;
  }
  if (directive.schema_version !== REWORK_SCHEMA_VERSION
      && directive.schema_version !== REWORK_LEGACY_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "返工指令版本不认识：" + String(directive.schema_version));
  }
  const legacy = directive.schema_version === REWORK_LEGACY_SCHEMA_VERSION;
  const expectedContract = legacy ? REWORK_LEGACY_CONTRACT_VERSION : REWORK_CONTRACT_VERSION;
  if (directive.contract_version !== expectedContract) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.contract_version",
      legacy ? "历史返工指令合同版本不是 v2.5.4。" : "返工指令合同版本不是当前版本。");
  }
  if (!isNonEmptyString(directive.directive_id)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.directive_id", "缺少指令 ID。");
  }
  if (!isNonEmptyString(directive.shot_id)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.shot_id", "缺少 shot_id。");
  }
  if (!isNonEmptyString(directive.candidate_id) || !isSha256Hex(directive.candidate_sha256)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.candidate_id",
      "返工指令必须绑定候选身份。");
  }
  if (!legacy) {
    if (REWORK_MODES.indexOf(directive.mode) === -1) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.mode",
        "返工指令必须声明明确模式：" + REWORK_MODES.join("/") + "。");
    }
    const candidate = directive.problem_candidate;
    if (!isPlainObject(candidate)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problem_candidate",
        "返工指令必须绑定明确的问题候选。");
    } else {
      if (candidate.candidate_id !== directive.candidate_id
          || candidate.asset_sha256 !== directive.candidate_sha256) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problem_candidate",
          "问题候选身份必须与指令绑定的候选一致。");
      }
      if (candidate.document_id !== directive.shot_id) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problem_candidate.document_id",
          "问题候选的文档标识必须是该图 shot_id（候选文档按 shot 归档）。");
      }
      if (!Number.isInteger(candidate.version) || candidate.version < 1) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problem_candidate.version",
          "问题候选必须带正整数原文档版本。");
      }
    }
  }
  const list = Array.isArray(directive.problems) ? directive.problems : null;
  if (!list) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problems", "问题分类必须是数组。");
  } else {
    list.forEach((id, index) => {
      if (REWORK_PROBLEM_IDS.indexOf(id) === -1) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.problems[" + index + "]",
          "未知的问题分类：" + String(id));
      }
    });
  }
  const text = typeof directive.direction === "string" ? directive.direction : null;
  if (text === null) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.direction", "方向必须是字符串。");
  } else if (text.length > 0 && text.length > REWORK_DIRECTION_MAX) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.direction",
      "改进方向超过 " + REWORK_DIRECTION_MAX + " 字。");
  }
  if ((list ? list.length : 0) === 0 && !text) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$",
      "返工至少要有一个问题分类或一句方向。");
  }
  if (!isIsoTimestamp(directive.created_at)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.created_at", "缺少 ISO 时间。");
  }
  if (!isPlainObject(directive.source)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.source", "缺少来源绑定。");
  }
  return problems;
}

/** 校验通过则原样返回指令，否则抛 DomainError。
 * @param {unknown} directive
 * @returns {import("./type-contracts.js").ReworkDirective}
 */
export function assertReworkDirective(directive) {
  const problems = checkReworkDirective(directive);
  if (problems.length > 0) invalid("返工指令不合法：" + problems[0].message);
  return directive;
}

/** 指令是否仍对这条候选有效：候选换了、合同版本前进（含历史未声明模式）都必须重新发起返工。
 * 历史 schema 1 指令即使候选仍对，也不是当前合同，返回 false（界面显示「旧记录未声明模式」）。
 * @param {unknown} directive
 * @param {unknown} candidate
 * @returns {boolean}
 */
export function reworkIsCurrent(directive, candidate) {
  if (!isPlainObject(directive) || !isPlainObject(candidate)) return false;
  return directive.schema_version === REWORK_SCHEMA_VERSION
    && directive.contract_version === REWORK_CONTRACT_VERSION
    && REWORK_MODES.indexOf(directive.mode) !== -1
    && directive.candidate_id === candidate.candidate_id
    && directive.shot_id === candidate.shot_id
    && directive.candidate_sha256 === candidate.asset_sha256;
}

/** 界面一行摘要：模式 + 问题分类 + 方向；不含命令，也不暗示已经采纳。
 * @param {unknown} directive
 * @returns {string}
 */
export function reworkSummaryText(directive) {
  if (!isPlainObject(directive)) return "";
  const labels = (Array.isArray(directive.problems) ? directive.problems : [])
    .map(reworkProblemLabel);
  /** @type {string[]} */
  const parts = [];
  const mode = reworkModeOf(directive);
  if (mode) parts.push("模式：" + reworkModeLabel(mode));
  if (labels.length > 0) parts.push(labels.join("、"));
  if (isNonEmptyString(directive.direction)) parts.push("方向：" + directive.direction);
  return parts.join(" · ");
}

/** 复核合同版本（供界面提示：报告先看项来自哪个版本）。 */
export function reworkReviewContract() {
  return REVIEW_CONTRACT_VERSION;
}
