/**
 * Product V2 规格层（V2.3.3，计划 §9.6）：公共 StyleSpec 与单图 ShotSpec。
 *
 * 唯一权威：两个文档的形状、默认值派生、差异、失效投影与审核清单投影都在本文件；
 * 失效语义复用 invalidation.js 的 invalidationsFor，不在本文件复制一张表。
 *
 * 三条不可协商的规则：
 *  1) 风格改动影响全套，单图规格改动只影响目标 Shot（由失效投影统一说清）；
 *  2) 未保存的规格用角色默认值投影，并明确标注「默认」，不假装用户设置过；
 *  3) 校验失败抛 CONTRACT_INVALID：界面不会把半成品写进版本历史。
 */

import { DOMAIN_ERROR_CODES, invalid } from "./errors.js";
import { invalidationsFor } from "./invalidation.js";
import { SLOT_ID_PATTERN, isNonEmptyString, isPlainObject, pushProblem } from "./shared.js";

/** @type {2} */
export const STYLE_SPEC_SCHEMA_VERSION = 2;
/** @type {2} */
export const SHOT_SPEC_SCHEMA_VERSION = 2;
/** @type {1} */
export const LEGACY_STYLE_SPEC_SCHEMA_VERSION = 1;
/** @type {1} */
export const LEGACY_SHOT_SPEC_SCHEMA_VERSION = 1;
/** @type {"style"} */
export const STYLE_SPEC_DOCUMENT_ID = "style";
/** @type {number} */
export const MAX_STYLE_TEXT = 200;
/** @type {number} */
export const MAX_STYLE_AVOID = 10;
/** @type {number} */
export const MAX_SHOT_PURPOSE = 200;
/** @type {number} */
export const MAX_SHOT_ITEMS = 8;
/** @type {number} */
export const MAX_SHOT_ITEM_LENGTH = 60;
/** @type {number} */
export const MAX_ON_IMAGE_TEXTS = 12;
/** @type {number} */
export const MAX_ON_IMAGE_TEXT_LENGTH = 60;

/** 展示决定词表（设计 §13.4.2）：共用默认 + 单图明确覆盖都只取这些字面量。 */
/** @type {readonly import("./type-contracts.js").PresentationAppearance[]} */
export const PRESENTATION_APPEARANCE_STATES = Object.freeze(["as_shown", "clean_display", "undecided"]);
/** @type {readonly import("./type-contracts.js").PresentationContents[]} */
export const PRESENTATION_CONTENTS_STATES = Object.freeze([
  "as_shown", "empty", "not_applicable", "undecided",
]);
/** @type {readonly import("./type-contracts.js").PresentationViewpoint[]} */
export const PRESENTATION_VIEWPOINTS = Object.freeze([
  "reference_visible", "front", "side", "top",
]);
/** 未决定不是「已选清洁」：默认展示决定保持中性，不替用户默选清洁。 */
/** @type {Readonly<import("./type-contracts.js").PresentationDecision>} */
export const DEFAULT_PRESENTATION = Object.freeze({
  appearance_state: "undecided",
  contents_state: "undecided",
  viewpoint: "reference_visible",
});
/** 文本标识：稳定、可读、只允许 ASCII 标识字符（供稳定 text_id 生成与校验）。 */
export const TEXT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;
/** 会凸显商品主体的角色：展示状态（清洁/倒空）对这些图才可能改变请求。 */
/** @type {readonly string[]} */
export const PRACTICAL_DISPLAY_ROLES = Object.freeze(["main", "scene", "detail"]);

/** @type {readonly import("./type-contracts.js").StyleSpecField[]} */
export const STYLE_SPEC_FIELDS = Object.freeze([
  Object.freeze({ key: "background", label: "背景风格", kind: "text" }),
  Object.freeze({ key: "lighting", label: "光线", kind: "text" }),
  Object.freeze({ key: "color_tone", label: "色调", kind: "text" }),
  Object.freeze({ key: "composition", label: "构图约定", kind: "text" }),
  Object.freeze({ key: "avoid", label: "避免出现", kind: "list" }),
]);

/** @type {readonly string[]} */
const STYLE_KEYS = Object.freeze(["schema_version", ...STYLE_SPEC_FIELDS.map((item) => item.key),
  "presentation"]);
/** @type {readonly string[]} */
const SHOT_KEYS = Object.freeze(["schema_version", "purpose", "keep", "change_allowed", "notes",
  "presentation", "on_image_texts"]);

/** 失效目标的人读名字；投影文本与界面提示共用这一份。 @type {Readonly<Record<string, string>>} */
export const ARTIFACT_LABELS = Object.freeze({
  prompt_versions: "Prompt 版本",
  review_reports: "审核报告",
  selection: "人工选择",
  suite_consistency_report: "整套一致性报告",
  product_brief: "商品理解",
  suite_plan: "套图计划",
  source_assets: "参考图",
  project_history: "项目历史",
  candidate_blobs: "候选图片",
  shot_spec: "单图规格",
  other_shots: "其他图片",
  unreferenced_shots: "未受影响的图片",
  existing_shot_history: "既有图片历史",
  selection_completeness: "选择完整性",
  suite_plan_revision: "套图计划版本",
});

/* ------------------------------------------------------------------ 公共风格 */

/**
 * 生成一份空白公共风格规格（未配置状态）。
 * @returns {import("./type-contracts.js").StyleSpec}
 */
export function emptyStyleSpec() {
  return {
    schema_version: STYLE_SPEC_SCHEMA_VERSION,
    background: "",
    lighting: "",
    color_tone: "",
    composition: "",
    avoid: [],
    presentation: { ...DEFAULT_PRESENTATION },
  };
}

/**
 * 校验单个文本字段（长度上限由调用方给出 label 描述）。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {Record<string, unknown>} spec
 * @param {string} key
 * @param {string} label
 * @returns {void}
 */
function checkStyleText(problems, spec, key, label) {
  const value = spec[key];
  if (value === undefined || value === null) return;
  if (typeof value !== "string") {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
      label + "必须是文本。");
    return;
  }
  if (value.length > MAX_STYLE_TEXT) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
      label + "最长 " + MAX_STYLE_TEXT + " 字。");
  }
}

/**
 * 展示决定（共用默认）的形状与词表校验；空 = 合法。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {string} path
 * @param {unknown} value
 * @returns {void}
 */
function checkPresentationDecision(problems, path, value) {
  if (!isPlainObject(value)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "展示决定必须是对象。");
    return;
  }
  const keys = ["appearance_state", "contents_state", "viewpoint"];
  for (const key of Object.keys(value)) {
    if (!keys.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + "." + key,
        "字段 " + key + " 不在展示决定内。");
    }
  }
  /** @type {Array<[string, readonly string[], string]>} */
  const fields = [
    ["appearance_state", PRESENTATION_APPEARANCE_STATES, "外观状态"],
    ["contents_state", PRESENTATION_CONTENTS_STATES, "内容物状态"],
    ["viewpoint", PRESENTATION_VIEWPOINTS, "视角"],
  ];
  for (const [key, allowed, label] of fields) {
    const item = value[key];
    if (typeof item !== "string" || !allowed.includes(item)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + "." + key,
        label + "必须是 " + allowed.join(" / ") + " 之一。");
    }
  }
}

/**
 * 单图展示覆盖（只存明确覆盖，未覆盖即继承）：只校验出现的键。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {string} path
 * @param {unknown} value
 * @returns {void}
 */
function checkPresentationOverride(problems, path, value) {
  if (value === undefined) return;
  if (!isPlainObject(value)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "单图展示覆盖必须是对象。");
    return;
  }
  const keys = ["appearance_state", "contents_state", "viewpoint"];
  for (const key of Object.keys(value)) {
    if (!keys.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + "." + key,
        "字段 " + key + " 不在展示覆盖内。");
    }
  }
  /** @type {Array<[string, readonly string[], string]>} */
  const fields = [
    ["appearance_state", PRESENTATION_APPEARANCE_STATES, "外观状态"],
    ["contents_state", PRESENTATION_CONTENTS_STATES, "内容物状态"],
    ["viewpoint", PRESENTATION_VIEWPOINTS, "视角"],
  ];
  for (const [key, allowed, label] of fields) {
    if (value[key] === undefined) continue;
    if (typeof value[key] !== "string" || !allowed.includes(value[key])) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path + "." + key,
        label + "必须是 " + allowed.join(" / ") + " 之一。");
    }
  }
}

/**
 * 上图文案列表校验：稳定 text_id、原文、精确来源 FactSlot 引用、状态与来源。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {string} path
 * @param {unknown} value
 * @returns {void}
 */
function checkOnImageTexts(problems, path, value) {
  if (!Array.isArray(value)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "上图文案必须是列表。");
    return;
  }
  if (value.length > MAX_ON_IMAGE_TEXTS) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
      "上图文案最多 " + MAX_ON_IMAGE_TEXTS + " 条。");
  }
  const seen = new Set();
  value.forEach((item, index) => {
    const itemPath = path + "[" + index + "]";
    if (!isPlainObject(item)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath, "每条必须是对象。");
      return;
    }
    for (const key of Object.keys(item)) {
      if (!["text_id", "text", "source", "status", "origin"].includes(key)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + "." + key,
          "字段 " + key + " 不在上图文案内。");
      }
    }
    if (typeof item.text_id !== "string" || !TEXT_ID_PATTERN.test(item.text_id)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".text_id",
        "text_id 必须是稳定标识（字母/数字开头，仅字母数字下划线连字符）。");
    } else if (seen.has(item.text_id)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".text_id",
        "text_id 不允许重复。");
    } else {
      seen.add(item.text_id);
    }
    if (!isNonEmptyString(item.text) || item.text.length > MAX_ON_IMAGE_TEXT_LENGTH) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".text",
        "原文不能为空且最长 " + MAX_ON_IMAGE_TEXT_LENGTH + " 字。");
    }
    const source = item.source;
    if (!isPlainObject(source)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".source",
        "来源必须是对象。");
    } else {
      if (source.kind !== "fact_slot") {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".source.kind",
          "来源 kind 必须是 fact_slot。");
      }
      if (typeof source.document_id !== "string" || !SLOT_ID_PATTERN.test(source.document_id)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".source.document_id",
          "来源槽位标识不合法。");
      }
      if (!Number.isInteger(source.version) || source.version < 1) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".source.version",
          "来源版本必须是正整数。");
      }
      for (const key of Object.keys(source)) {
        if (!["kind", "document_id", "version"].includes(key)) {
          pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".source." + key,
            "字段 " + key + " 不在来源引用内。");
        }
      }
    }
    if (!["proposed", "confirmed"].includes(item.status)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".status",
        "status 必须是 proposed / confirmed。");
    }
    if (!["user", "model", "reuse"].includes(item.origin)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, itemPath + ".origin",
        "origin 必须是 user / model / reuse。");
    }
  });
}

/** @type {readonly string[]} */
const LEGACY_STYLE_KEYS = Object.freeze(["schema_version",
  ...STYLE_SPEC_FIELDS.map((item) => item.key)]);

/**
 * 公共风格（v1）形状与内容校验；只用于历史读取/导入的显式旧分支，不用于新写入。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkStyleSpecV1(spec) {
  /** @type {import("./type-contracts.js").DomainProblem[]} */
  const problems = [];
  if (!isPlainObject(spec)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "风格规格必须是对象。");
    return problems;
  }
  if (spec.schema_version !== LEGACY_STYLE_SPEC_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "风格规格版本必须是 " + LEGACY_STYLE_SPEC_SCHEMA_VERSION + "。");
  }
  for (const key of Object.keys(spec)) {
    if (!LEGACY_STYLE_KEYS.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
        "字段 " + key + " 不在风格规格内。");
    }
  }
  checkStyleTextFields(problems, spec);
  return problems;
}

/**
 * 公共风格（v2）严格校验：含中性展示决定；新写入必须通过本函数。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkStyleSpecV2(spec) {
  /** @type {import("./type-contracts.js").DomainProblem[]} */
  const problems = [];
  if (!isPlainObject(spec)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "风格规格必须是对象。");
    return problems;
  }
  if (spec.schema_version !== STYLE_SPEC_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "风格规格版本必须是 " + STYLE_SPEC_SCHEMA_VERSION + "。");
  }
  for (const key of Object.keys(spec)) {
    if (!STYLE_KEYS.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
        "字段 " + key + " 不在风格规格内。");
    }
  }
  checkStyleTextFields(problems, spec);
  checkPresentationDecision(problems, "$.presentation", spec.presentation);
  return problems;
}

/**
 * 公共风格版本分派：显式按 schema_version 走旧/新分支，未知版本按新分支拒绝。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkStyleSpec(spec) {
  if (isPlainObject(spec) && spec.schema_version === LEGACY_STYLE_SPEC_SCHEMA_VERSION) {
    return checkStyleSpecV1(spec);
  }
  return checkStyleSpecV2(spec);
}

/**
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {Record<string, unknown>} spec
 * @returns {void}
 */
function checkStyleTextFields(problems, spec) {
  for (const field of STYLE_SPEC_FIELDS) {
    if (field.kind === "text") {
      checkStyleText(problems, spec, field.key, field.label);
      continue;
    }
    const avoid = spec.avoid;
    if (avoid === undefined || avoid === null) continue;
    if (!Array.isArray(avoid)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.avoid",
        field.label + "必须是一行一条的列表。");
      continue;
    }
    if (avoid.length > MAX_STYLE_AVOID) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.avoid",
        field.label + "最多 " + MAX_STYLE_AVOID + " 条。");
    }
    const seen = new Set();
    avoid.forEach((item, index) => {
      const path = "$.avoid[" + index + "]";
      if (!isNonEmptyString(item) || item.length > MAX_SHOT_ITEM_LENGTH) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
          "每条最多 " + MAX_SHOT_ITEM_LENGTH + " 字且不能为空。");
      } else if (seen.has(item)) {
        pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "不允许重复。");
      } else {
        seen.add(item);
      }
    });
  }
}

/**
 * 判断公共风格是否完全未配置（或根本不是一个对象）。
 * @param {unknown} spec
 * @returns {boolean}
 */
export function styleSpecIsEmpty(spec) {
  if (!isPlainObject(spec)) return true;
  return styleSpecSummary(spec).length === 0 && presentationIsDefault(spec.presentation);
}

/**
 * 展示决定是否仍为中性默认（未决定即视为未配置，不默选清洁）。
 * @param {unknown} value
 * @returns {boolean}
 */
export function presentationIsDefault(value) {
  if (!isPlainObject(value)) return true;
  return (value.appearance_state === undefined || value.appearance_state === "undecided")
    && (value.contents_state === undefined || value.contents_state === "undecided")
    && (value.viewpoint === undefined || value.viewpoint === "reference_visible");
}

/**
 * 公共风格的界面摘要（每条一段人读文本）；未配置返回空数组。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").StyleSpecSummaryItem[]}
 */
export function styleSpecSummary(spec) {
  if (!isPlainObject(spec)) return [];
  /** @type {import("./type-contracts.js").StyleSpecSummaryItem[]} */
  const items = [];
  for (const field of STYLE_SPEC_FIELDS) {
    const value = spec[field.key];
    if (field.kind === "text") {
      if (!isNonEmptyString(value)) continue;
      const trimmed = value.trim();
      items.push({ key: field.key, label: field.label, kind: "text",
        value: trimmed, text: field.label + "：" + trimmed });
      continue;
    }
    const list = Array.isArray(value)
      ? value.filter((item) => isNonEmptyString(item)).map((item) => item.trim())
      : [];
    if (list.length === 0) continue;
    items.push({ key: field.key, label: field.label, kind: "list",
      value: list, text: field.label + "：" + list.join("、") });
  }
  return items;
}

/**
 * 字段值的规范化比较形态：text → trim；list → 过滤空项后逐条 trim。
 * @param {import("./type-contracts.js").StyleSpecField} field
 * @param {Record<string, unknown> | null | undefined} spec
 * @returns {string | string[]}
 */
function normalizedStyleValue(field, spec) {
  const value = spec ? spec[field.key] : undefined;
  if (field.kind === "text") return isNonEmptyString(value) ? value.trim() : "";
  return Array.isArray(value)
    ? value.filter((item) => isNonEmptyString(item)).map((item) => item.trim())
    : [];
}

/**
 * 公共风格的前后差异（逐字段 before/after）；无差异返回空数组。
 * @param {Record<string, unknown> | null | undefined} previous
 * @param {Record<string, unknown> | null | undefined} next
 * @returns {import("./type-contracts.js").SpecDiffItem[]}
 */
export function styleSpecDiff(previous, next) {
  const diffs = [];
  for (const field of STYLE_SPEC_FIELDS) {
    const before = normalizedStyleValue(field, previous);
    const after = normalizedStyleValue(field, next);
    if (JSON.stringify(before) !== JSON.stringify(after)) {
      diffs.push({ field: field.key, label: field.label, before, after });
    }
  }
  const presBefore = normalizedPresentation(previous);
  const presAfter = normalizedPresentation(next);
  if (JSON.stringify(presBefore) !== JSON.stringify(presAfter)) {
    diffs.push({
      field: "presentation", label: "展示决定",
      before: [presBefore.appearance_state, presBefore.contents_state, presBefore.viewpoint],
      after: [presAfter.appearance_state, presAfter.contents_state, presAfter.viewpoint],
    });
  }
  return diffs;
}

/**
 * 展示决定的规范化比较形态：缺省即中性默认。
 * @param {Record<string, unknown> | null | undefined} spec
 * @returns {import("./type-contracts.js").PresentationDecision}
 */
function normalizedPresentation(spec) {
  const value = spec && isPlainObject(spec.presentation) ? spec.presentation : {};
  const pick = (key, allowed, fallback) => {
    const item = value[key];
    return typeof item === "string" && allowed.includes(item) ? item : fallback;
  };
  return {
    appearance_state: pick("appearance_state", PRESENTATION_APPEARANCE_STATES, "undecided"),
    contents_state: pick("contents_state", PRESENTATION_CONTENTS_STATES, "undecided"),
    viewpoint: pick("viewpoint", PRESENTATION_VIEWPOINTS, "reference_visible"),
  };
}

/* ------------------------------------------------------------------ 单图规格 */

/** 每种角色的默认「必须保持」；未保存规格时用这份投影。 @type {Readonly<Record<string, string[]>>} */
const DEFAULT_KEEP_BY_ROLE = Object.freeze({
  main: ["商品外观、颜色与比例", "标识与文字"],
  infographic: ["已确认卖点文字"],
  scene: ["商品外观与颜色", "标识与文字"],
  detail: ["材质与工艺细节", "颜色"],
  size: ["尺寸数字与单位"],
  comparison: ["商品外观与标识"],
  ingredient: ["配料与成分列表"],
  packaging: ["包装形态与随附物"],
  custom: ["商品外观与标识"],
});

/** 每种角色的默认「允许变化」；与 keep 同一份口径。 @type {Readonly<Record<string, string[]>>} */
const DEFAULT_ALLOW_BY_ROLE = Object.freeze({
  main: ["背景"],
  infographic: ["标注排版与配色"],
  scene: ["环境、道具与光线"],
  detail: ["对焦、景别与光线"],
  size: ["标注样式与排版"],
  comparison: ["对比版式"],
  ingredient: ["摆盘与构图"],
  packaging: ["陈设与光线"],
  custom: ["构图、场景与光线"],
});

/**
 * 从 Shot 派生一份默认单图规格（目的取 intent/label，keep/change_allowed 按角色默认）。
 * @param {unknown} shot
 * @returns {import("./type-contracts.js").ShotSpec}
 */
export function emptyShotSpecFromShot(shot) {
  const roleId = isPlainObject(shot) && typeof shot.role_id === "string" ? shot.role_id : "custom";
  const purpose = isPlainObject(shot) && isNonEmptyString(shot.intent)
    ? shot.intent.trim()
    : (isPlainObject(shot) && isNonEmptyString(shot.label) ? shot.label.trim() : "这张图要达成什么");
  return {
    schema_version: SHOT_SPEC_SCHEMA_VERSION,
    purpose,
    keep: [...(DEFAULT_KEEP_BY_ROLE[roleId] || DEFAULT_KEEP_BY_ROLE.custom)],
    change_allowed: [...(DEFAULT_ALLOW_BY_ROLE[roleId] || DEFAULT_ALLOW_BY_ROLE.custom),
      "目的明确要求清洁展示时，去除临时污迹与使用残留后呈现商品；其他情况保持原状态，永久损伤、纹理、涂层与标识一律保留"],
    notes: "",
    presentation: {},
    on_image_texts: [],
  };
}

/**
 * 校验 keep / change_allowed 列表（元素类型、上限与去重）；可要求至少一项。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {Record<string, unknown>} spec
 * @param {string} key
 * @param {string} label
 * @param {{required: boolean}} options
 * @returns {void}
 */
function checkShotItems(problems, spec, key, label, { required }) {
  const value = spec[key];
  if (value === undefined || value === null) {
    if (required) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
        label + "至少要有一项。");
    }
    return;
  }
  if (!Array.isArray(value)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
      label + "必须是列表。");
    return;
  }
  if (required && value.length === 0) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
      label + "至少要有一项。");
  }
  if (value.length > MAX_SHOT_ITEMS) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
      label + "最多 " + MAX_SHOT_ITEMS + " 项。");
  }
  const seen = new Set();
  value.forEach((item, index) => {
    const path = "$." + key + "[" + index + "]";
    if (!isNonEmptyString(item) || item.length > MAX_SHOT_ITEM_LENGTH) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path,
        "每项最多 " + MAX_SHOT_ITEM_LENGTH + " 字且不能为空。");
    } else if (seen.has(item)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, path, "不允许重复。");
    } else {
      seen.add(item);
    }
  });
}

/** @type {readonly string[]} */
const LEGACY_SHOT_KEYS = Object.freeze(["schema_version", "purpose", "keep", "change_allowed", "notes"]);

/**
 * 单图规格（v1）形状与内容校验；只用于历史读取/导入的显式旧分支，不用于新写入。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkShotSpecV1(spec) {
  /** @type {import("./type-contracts.js").DomainProblem[]} */
  const problems = [];
  if (!isPlainObject(spec)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "单图规格必须是对象。");
    return problems;
  }
  if (spec.schema_version !== LEGACY_SHOT_SPEC_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "单图规格版本必须是 " + LEGACY_SHOT_SPEC_SCHEMA_VERSION + "。");
  }
  for (const key of Object.keys(spec)) {
    if (!LEGACY_SHOT_KEYS.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
        "字段 " + key + " 不在单图规格内。");
    }
  }
  checkShotSpecFields(problems, spec);
  return problems;
}

/**
 * 单图规格（v2）严格校验：含单图展示覆盖与上图文案；新写入必须通过本函数。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkShotSpecV2(spec) {
  /** @type {import("./type-contracts.js").DomainProblem[]} */
  const problems = [];
  if (!isPlainObject(spec)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$", "单图规格必须是对象。");
    return problems;
  }
  if (spec.schema_version !== SHOT_SPEC_SCHEMA_VERSION) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.schema_version",
      "单图规格版本必须是 " + SHOT_SPEC_SCHEMA_VERSION + "。");
  }
  for (const key of Object.keys(spec)) {
    if (!SHOT_KEYS.includes(key)) {
      pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$." + key,
        "字段 " + key + " 不在单图规格内。");
    }
  }
  checkShotSpecFields(problems, spec);
  checkPresentationOverride(problems, "$.presentation", spec.presentation);
  checkOnImageTexts(problems, "$.on_image_texts", spec.on_image_texts);
  return problems;
}

/**
 * 单图规格版本分派：显式按 schema_version 走旧/新分支，未知版本按新分支拒绝。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").DomainProblem[]}
 */
export function checkShotSpec(spec) {
  if (isPlainObject(spec) && spec.schema_version === LEGACY_SHOT_SPEC_SCHEMA_VERSION) {
    return checkShotSpecV1(spec);
  }
  return checkShotSpecV2(spec);
}

/**
 * 单图规格共有的目的/必须保持/允许变化/备注校验（新旧版本共用）。
 * @param {import("./type-contracts.js").DomainProblem[]} problems
 * @param {Record<string, unknown>} spec
 * @returns {void}
 */
function checkShotSpecFields(problems, spec) {
  if (!isNonEmptyString(spec.purpose)) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.purpose",
      "目的不能为空：这张图要达成什么必须先说清。");
  } else if (spec.purpose.length > MAX_SHOT_PURPOSE) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.purpose",
      "目的最长 " + MAX_SHOT_PURPOSE + " 字。");
  }
  checkShotItems(problems, spec, "keep", "必须保持", { required: true });
  checkShotItems(problems, spec, "change_allowed", "允许变化", { required: true });
  if (spec.notes !== undefined && spec.notes !== null && typeof spec.notes !== "string") {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.notes", "备注必须是文本。");
  } else if (typeof spec.notes === "string" && spec.notes.length > MAX_STYLE_TEXT) {
    pushProblem(problems, DOMAIN_ERROR_CODES.CONTRACT_INVALID, "$.notes",
      "备注最长 " + MAX_STYLE_TEXT + " 字。");
  }
}

/**
 * keep / change_allowed 的规范化比较形态；非数组一律视为空列表。
 * @param {unknown} value
 * @returns {string[]}
 */
function normalizedShotItems(value) {
  return Array.isArray(value)
    ? value.filter((item) => isNonEmptyString(item)).map((item) => item.trim())
    : [];
}

/**
 * 单图规格的前后差异（目的 + keep/change_allowed）；无差异返回空数组。
 * @param {Record<string, unknown> | null | undefined} previous
 * @param {Record<string, unknown> | null | undefined} next
 * @returns {import("./type-contracts.js").SpecDiffItem[]}
 */
export function shotSpecDiff(previous, next) {
  const diffs = [];
  const prevPurpose = previous && isNonEmptyString(previous.purpose) ? previous.purpose.trim() : "";
  const nextPurpose = next && isNonEmptyString(next.purpose) ? next.purpose.trim() : "";
  if (prevPurpose !== nextPurpose) {
    diffs.push({ field: "purpose", label: "目的", before: prevPurpose, after: nextPurpose });
  }
  for (const [key, label] of [["keep", "必须保持"], ["change_allowed", "允许变化"]]) {
    const before = normalizedShotItems(previous ? previous[key] : null);
    const after = normalizedShotItems(next ? next[key] : null);
    if (JSON.stringify(before) !== JSON.stringify(after)) {
      diffs.push({ field: key, label, before, after });
    }
  }
  return diffs;
}

/* -------------------------------------------------------- 失效投影与版本 */

/**
 * @param {readonly string[]} keys
 * @returns {string[]}
 */
function labelList(keys) {
  return keys.map((key) => ARTIFACT_LABELS[key] || key);
}

/**
 * 失效投影（人读版）：一次变化影响什么、失效什么、保留什么。
 * @param {import("./type-contracts.js").ChangeKind} changeKind
 * @param {import("./type-contracts.js").InvalidationContext & {shotCount?: number, shotLabel?: string}} [context]
 * @returns {{change_kind: string, scope: string, target_shot_id: string | null, affects: "suite" | "shot", affects_text: string, invalidates: string[], preserves: string[], invalidates_text: string, preserves_text: string}}
 */
export function specChangeProjection(changeKind, context = {}) {
  const result = invalidationsFor(changeKind, context);
  const shotCount = Number.isInteger(context.shotCount) ? context.shotCount : null;
  const shotLabel = isNonEmptyString(context.shotLabel) ? context.shotLabel.trim() : null;
  const affectsSuite = result.scope === "project";
  const affectsText = affectsSuite
    ? (shotCount === null ? "全部图片" : "全部 " + shotCount + " 张图")
    : (shotLabel ? "只有「" + shotLabel + "」这一张" : "只有目标这一张");
  return {
    change_kind: changeKind,
    scope: result.scope,
    target_shot_id: result.target_shot_id || null,
    affects: affectsSuite ? "suite" : "shot",
    affects_text: affectsText,
    invalidates: [...result.invalidates],
    preserves: [...result.preserves],
    invalidates_text: labelList(result.invalidates).join("、"),
    preserves_text: labelList(result.preserves).join("、"),
  };
}

/**
 * 取 versions 里 version < currentVersion 的最大者；要求 currentVersion 是正整数。
 * @param {unknown} versions
 * @param {number} currentVersion
 * @returns {{version: number} & Record<string, unknown> | null}
 */
export function previousVersionOf(versions, currentVersion) {
  if (!Number.isInteger(currentVersion) || currentVersion < 1) {
    invalid("当前版本必须是正整数。");
  }
  const list = (Array.isArray(versions) ? versions : [])
    .filter((item) => isPlainObject(item) && Number.isInteger(item.version))
    .filter((item) => item.version < currentVersion)
    .sort((left, right) => right.version - left.version);
  return list.length ? list[0] : null;
}

/* -------------------------------------------------------- 审核清单与聚合 */

/**
 * 单图的审核清单投影：目的/必须保持/允许变化/公共风格四段。
 * @param {unknown} shot
 * @param {{shotSpec?: import("./type-contracts.js").ShotSpec | null, styleSpec?: import("./type-contracts.js").StyleSpec | null}} [options]
 * @returns {{shot_id: string | null, label: string, role_id: string | null, required: boolean, custom: boolean, saved: boolean, purpose: string, must_keep: string[], may_change: string[], style_configured: boolean, style_lines: string[], sections: {key: string, label: string, items: string[]}[]}}
 */
export function reviewChecklist(shot, options = {}) {
  if (!isPlainObject(shot)) invalid("审核清单需要一张 Shot。");
  const savedSpec = isPlainObject(options.shotSpec) ? options.shotSpec : null;
  const spec = savedSpec || emptyShotSpecFromShot(shot);
  const style = options.styleSpec || emptyStyleSpec();
  const styleItems = styleSpecSummary(style).map((item) => item.text);
  return {
    shot_id: typeof shot.shot_id === "string" ? shot.shot_id : null,
    label: isNonEmptyString(shot.label) ? shot.label : "",
    role_id: typeof shot.role_id === "string" ? shot.role_id : null,
    required: shot.required === true,
    custom: shot.custom === true,
    saved: Boolean(savedSpec),
    purpose: spec.purpose,
    must_keep: [...spec.keep],
    may_change: [...spec.change_allowed],
    style_configured: styleItems.length > 0,
    style_lines: styleItems,
    presentation: effectivePresentationForShot(style, spec),
    on_image_texts: Array.isArray(spec.on_image_texts) ? spec.on_image_texts.map((item) => ({ ...item })) : [],
    sections: [
      { key: "purpose", label: "这张图的目的", items: [spec.purpose] },
      { key: "keep", label: "必须保持", items: [...spec.keep] },
      { key: "change", label: "允许变化", items: [...spec.change_allowed] },
      { key: "style", label: "公共风格", items: styleItems },
    ],
  };
}

/**
 * 整套图的规格聚合：每张图的保存状态、版本与完整审核清单。
 * @param {unknown} plan
 * @param {{shotSpecsById?: Record<string, {spec?: import("./type-contracts.js").ShotSpec | null, version: number} | null | undefined>, styleSpec?: import("./type-contracts.js").StyleSpec | null}} [options]
 * @returns {{total: number, saved: number, defaults: number, style_configured: boolean, shots: {shot_id: string | null, label: string, saved: boolean, version: number, checklist: {shot_id: string | null, label: string, role_id: string | null, required: boolean, custom: boolean, saved: boolean, purpose: string, must_keep: string[], may_change: string[], style_configured: boolean, style_lines: string[], sections: {key: string, label: string, items: string[]}[]}}[]}}
 */
export function suiteSpecDigest(plan, options = {}) {
  const shots = (isPlainObject(plan) && Array.isArray(plan.shots) ? plan.shots : [])
    .map((shot) => {
      const entry = options.shotSpecsById && shot && options.shotSpecsById[shot.shot_id]
        ? options.shotSpecsById[shot.shot_id]
        : null;
      return {
        shot_id: shot.shot_id,
        label: shot.label,
        saved: Boolean(entry && entry.spec),
        version: entry && Number.isInteger(entry.version) ? entry.version : 0,
        checklist: reviewChecklist(shot, {
          shotSpec: entry ? entry.spec : null,
          styleSpec: options.styleSpec || null,
        }),
      };
    });
  return {
    total: shots.length,
    saved: shots.filter((item) => item.saved).length,
    defaults: shots.filter((item) => !item.saved).length,
    style_configured: !styleSpecIsEmpty(options.styleSpec || null),
    shots,
  };
}

/**
 * 校验公共风格并原样返回；失败抛 CONTRACT_INVALID（绝不写半成品进版本历史）。
 * @param {import("./type-contracts.js").StyleSpec} spec
 * @returns {import("./type-contracts.js").StyleSpec}
 */
export function assertStyleSpec(spec) {
  const problems = checkStyleSpec(spec);
  if (problems.length > 0) invalid("风格规格不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return spec;
}

/**
 * 校验单图规格并原样返回；失败抛 CONTRACT_INVALID。
 * @param {import("./type-contracts.js").ShotSpec} spec
 * @returns {import("./type-contracts.js").ShotSpec}
 */
export function assertShotSpec(spec) {
  const problems = checkShotSpec(spec);
  if (problems.length > 0) invalid("单图规格不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return spec;
}

/**
 * 严格校验公共风格（v2）并原样返回；新写入唯一入口，旧 schema 一律拒绝。
 * @param {import("./type-contracts.js").StyleSpecV2} spec
 * @returns {import("./type-contracts.js").StyleSpecV2}
 */
export function assertStyleSpecV2(spec) {
  const problems = checkStyleSpecV2(spec);
  if (problems.length > 0) invalid("风格规格不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return spec;
}

/**
 * 严格校验单图规格（v2）并原样返回；新写入唯一入口，旧 schema 一律拒绝。
 * @param {import("./type-contracts.js").ShotSpecV2} spec
 * @returns {import("./type-contracts.js").ShotSpecV2}
 */
export function assertShotSpecV2(spec) {
  const problems = checkShotSpecV2(spec);
  if (problems.length > 0) invalid("单图规格不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return spec;
}

/**
 * 把任意已读风格规格升为 v2（保留既有文本字段与已保存展示决定）。
 * 只在「用户明确保存」时用于把旧记录转成新 schema；不是第二套写入者或别名。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").StyleSpecV2}
 */
export function upgradeStyleSpecV2(spec) {
  const source = isPlainObject(spec) ? spec : {};
  return {
    schema_version: STYLE_SPEC_SCHEMA_VERSION,
    background: typeof source.background === "string" ? source.background : "",
    lighting: typeof source.lighting === "string" ? source.lighting : "",
    color_tone: typeof source.color_tone === "string" ? source.color_tone : "",
    composition: typeof source.composition === "string" ? source.composition : "",
    avoid: Array.isArray(source.avoid)
      ? source.avoid.filter((item) => isNonEmptyString(item)).map((item) => item.trim()) : [],
    presentation: normalizedPresentation(source),
  };
}

/**
 * 把任意已读单图规格升为 v2（保留既有文本字段、已保存覆盖与上图文案）。
 * @param {unknown} spec
 * @returns {import("./type-contracts.js").ShotSpecV2}
 */
export function upgradeShotSpecV2(spec) {
  const source = isPlainObject(spec) ? spec : {};
  return {
    schema_version: SHOT_SPEC_SCHEMA_VERSION,
    purpose: typeof source.purpose === "string" ? source.purpose : "",
    keep: Array.isArray(source.keep) ? [...source.keep] : [],
    change_allowed: Array.isArray(source.change_allowed) ? [...source.change_allowed] : [],
    notes: typeof source.notes === "string" ? source.notes : "",
    presentation: isPlainObject(source.presentation) ? { ...source.presentation } : {},
    on_image_texts: Array.isArray(source.on_image_texts)
      ? source.on_image_texts.map((item) => ({ ...item })) : [],
  };
}

/**
 * 校验并规范化一份完整展示决定（共用默认的唯一写入入口）；失败抛 CONTRACT_INVALID。
 * @param {unknown} decision
 * @returns {import("./type-contracts.js").PresentationDecision}
 */
export function assertPresentationDecision(decision) {
  const problems = [];
  checkPresentationDecision(problems, "$.presentation", decision);
  if (problems.length > 0) invalid("展示决定不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return normalizedPresentation({ presentation: decision });
}

/**
 * 校验并复制一份单图展示覆盖（只存明确覆盖，未覆盖即继承）；失败抛 CONTRACT_INVALID。
 * @param {unknown} decision
 * @returns {import("./type-contracts.js").PresentationOverride}
 */
export function assertPresentationOverride(decision) {
  const problems = [];
  checkPresentationOverride(problems, "$.presentation", decision);
  if (problems.length > 0) invalid("单图展示覆盖不合法：" + problems[0].message,
    { problems: problems.slice(0, 3) });
  return isPlainObject(decision) ? { ...decision } : {};
}

/**
 * 从任意形状取展示决定对象（展示决定本身，或含 presentation 的规格）；无则 null。
 * @param {unknown} spec
 * @returns {Record<string, unknown> | null}
 */
function presentationOf(spec) {
  if (!isPlainObject(spec)) return null;
  if ("appearance_state" in spec || "contents_state" in spec || "viewpoint" in spec) return spec;
  return isPlainObject(spec.presentation) ? spec.presentation : null;
}

/**
 * 单图的有效展示决定：单图明确覆盖优先，其次共用默认，最后中性默认（未决定不默选清洁）。
 * @param {unknown} styleSpec
 * @param {unknown} shotSpec
 * @returns {{appearance_state: import("./type-contracts.js").PresentationAppearance, contents_state: import("./type-contracts.js").PresentationContents, viewpoint: import("./type-contracts.js").PresentationViewpoint, sources: {appearance_state: string, contents_state: string, viewpoint: string}}}
 */
export function effectivePresentationForShot(styleSpec, shotSpec) {
  const sharedRaw = isPlainObject(styleSpec) && isPlainObject(styleSpec.presentation)
    ? styleSpec.presentation : null;
  const shared = normalizedPresentation(styleSpec);
  const override = isPlainObject(shotSpec) && isPlainObject(shotSpec.presentation)
    ? shotSpec.presentation : {};
  /** @type {Record<string, string>} */
  const sources = {
    appearance_state: sharedRaw ? "shared" : "default",
    contents_state: sharedRaw ? "shared" : "default",
    viewpoint: sharedRaw ? "shared" : "default",
  };
  /** @type {Record<string, string>} */
  const effective = { ...shared };
  for (const key of ["appearance_state", "contents_state", "viewpoint"]) {
    if (override[key] !== undefined) {
      effective[key] = override[key];
      sources[key] = "shot";
    }
  }
  return {
    appearance_state: /** @type {import("./type-contracts.js").PresentationAppearance} */ (effective.appearance_state),
    contents_state: /** @type {import("./type-contracts.js").PresentationContents} */ (effective.contents_state),
    viewpoint: /** @type {import("./type-contracts.js").PresentationViewpoint} */ (effective.viewpoint),
    sources,
  };
}

/**
 * 商品是否为容器的三态判定（设计 §13.4.2）：只由明确分类或已确认的**精确**品类建立。
 * 未决定不是容器；文件名/角色/子串匹配不能建立容器身份。品类文本只作人读依据。
 * @param {unknown} sharedSpec 展示决定本身，或含 presentation 的规格；null/V1 视为未知
 * @param {{categoryText?: unknown, exactCategoryKind?: unknown}} [options]
 * @returns {{status: "container" | "non_container" | "unknown", basis: "presentation" | "category" | "unknown", reason: string}}
 */
export function containerStatusOf(sharedSpec, options = {}) {
  const pres = presentationOf(sharedSpec);
  const contents = pres ? pres.contents_state : undefined;
  const categoryText = isNonEmptyString(options.categoryText) ? options.categoryText.trim() : null;
  const exactKind = options.exactCategoryKind === "container" || options.exactCategoryKind === "non_container"
    ? options.exactCategoryKind : null;
  if (contents === "not_applicable") {
    return { status: "non_container", basis: "presentation",
      reason: "已明确标记本商品不是容器：内容物不适用，不问倒空。" };
  }
  if (contents === "as_shown" || contents === "empty") {
    return { status: "container", basis: "presentation",
      reason: "已明确标记本商品为容器：内容物展示需要决定。" };
  }
  if (exactKind) {
    return { status: exactKind, basis: "category",
      reason: (categoryText ? "已确认品类「" + categoryText + "」" : "已确认的精确品类")
        + (exactKind === "container" ? "属于容器。" : "不是容器。") };
  }
  return { status: "unknown", basis: "unknown",
    reason: categoryText
      ? "已确认品类「" + categoryText + "」不足以确定是否为容器；请明确选择（不是容器则内容物不适用）。"
      : "尚未确定本商品是否为容器；请明确选择（不是容器则内容物不适用）。" };
}

/**
 * 是否已明确为容器（contents_state 为 as_shown/empty）。未决定/非容器/V1 一律 false。
 * @param {unknown} sharedSpec
 * @returns {boolean}
 */
export function isContainerProduct(sharedSpec) {
  const pres = presentationOf(sharedSpec);
  const contents = pres ? pres.contents_state : undefined;
  return contents === "as_shown" || contents === "empty";
}

/**
 * 视角是否有依据支持：原可见视角恒可；其余必须出现在明确的支持清单里。
 * @param {unknown} viewpoint
 * @param {readonly string[] | null | undefined} supportedViewpoints
 * @returns {boolean}
 */
export function isViewpointSupported(viewpoint, supportedViewpoints) {
  if (viewpoint === "reference_visible") return true;
  return Array.isArray(supportedViewpoints) && supportedViewpoints.includes(viewpoint);
}

/** 参考图能证明的「非原可见」视角词表（与 PresentationViewpoint 的非默认项一致）。 @type {readonly string[]} */
export const REFERENCE_VIEWPOINTS = Object.freeze(["front", "side", "top"]);

/**
 * 参考图视角证据（设计 §13.4.2）：只有「来源 reference_observation、已确认、证据指向当前启用参考图
 * 的完整 SHA、值只含 front|side|top」的 FactSlot 才能证明视角。只读、无 AI、不按文件名/角色猜测。
 * 调用方可用它把「项目证据」与「本次实际冻结引用」分别过滤。
 * @param {ReadonlyArray<{slot: import("./type-contracts.js").FactSlot, version: number}> | null | undefined} slotEntries
 * @param {readonly string[] | null | undefined} activeReferenceShas
 * @returns {{viewpoints: string[], slots: {slot_id: string, version: number}[]}}
 */
export function referenceViewpointEvidence(slotEntries, activeReferenceShas) {
  const active = new Set(Array.isArray(activeReferenceShas) ? activeReferenceShas : []);
  /** @type {Set<string>} */
  const viewpoints = new Set();
  /** @type {{slot_id: string, version: number}[]} */
  const slots = [];
  for (const entry of Array.isArray(slotEntries) ? slotEntries : []) {
    if (!isPlainObject(entry) || !isPlainObject(entry.slot)) continue;
    const slot = entry.slot;
    if (slot.source !== "reference_observation" || slot.status !== "confirmed") continue;
    if (slot.value_type !== "enum" && slot.value_type !== "text_list") continue;
    const evidence = Array.isArray(slot.evidence) ? slot.evidence : [];
    const bound = evidence.some((item) => isPlainObject(item) && item.kind === "asset"
      && typeof item.ref === "string" && active.has(item.ref));
    if (!bound) continue;
    const values = Array.isArray(slot.value) ? slot.value : [slot.value];
    const found = values.filter((value) => REFERENCE_VIEWPOINTS.includes(value));
    if (!found.length) continue;
    for (const value of found) viewpoints.add(value);
    slots.push({ slot_id: slot.slot_id, version: entry.version });
  }
  return { viewpoints: [...viewpoints], slots };
}

/**
 * 按用途的展示决定就绪投影（设计 §13.4.3）：只问会改变本次请求且证据有歧义的必要项。
 * 未决定只在「对该用途必要」时阻断；不必要处保持中性、不默选清洁。
 * @param {unknown} roleId
 * @param {{appearance_state?: string, contents_state?: string, viewpoint?: string} | null | undefined} effective
 * @param {{containerStatus?: {status?: string} | null, supportedViewpoints?: readonly string[] | null, appearanceNecessary?: boolean, contentsNecessary?: boolean}} [options]
 * @returns {{ready: boolean, blocking: {field: string, reason: string}[]}}
 */
export function presentationReadinessForShot(roleId, effective, options = {}) {
  /** @type {{field: string, reason: string}[]} */
  const blocking = [];
  const status = options.containerStatus && typeof options.containerStatus.status === "string"
    ? options.containerStatus.status : "unknown";
  const supported = Array.isArray(options.supportedViewpoints) ? options.supportedViewpoints : null;
  const role = typeof roleId === "string" ? roleId : "";
  const displayRole = PRACTICAL_DISPLAY_ROLES.includes(role);
  // 外观不是「只要是容器就算歧义」：只有调用方拿到确凿的使用残留/清洁歧义证据时才要求决定；
  // 未决定即保持原样，绝不默认清洁（设计 §13.4.3）。
  const appearanceNecessary = options.appearanceNecessary !== undefined
    ? options.appearanceNecessary === true
    : false;
  const contentsNecessary = options.contentsNecessary !== undefined
    ? options.contentsNecessary === true
    : (displayRole && (status === "container" || status === "unknown"));
  const appearance = effective ? effective.appearance_state : undefined;
  const contents = effective ? effective.contents_state : undefined;
  const viewpoint = effective ? effective.viewpoint : undefined;
  if (appearanceNecessary && (appearance === undefined || appearance === "undecided")) {
    blocking.push({ field: "appearance_state",
      reason: "这张图会展示商品主体；请明确保持原样展示还是清洁后展示，未决定前不默选清洁。" });
  }
  if (contentsNecessary && (contents === undefined || contents === "undecided")) {
    blocking.push({ field: "contents_state",
      reason: status === "unknown"
        ? "还不能确定本商品是否为容器；请明确选择（不是容器则内容物不适用），未决定前不凑内容物或倒空。"
        : "这是容器商品；请明确内容物展示（原样 / 倒空 / 不适用），未决定前不默选。" });
  }
  if (viewpoint !== undefined && viewpoint !== "reference_visible"
      && !isViewpointSupported(viewpoint, supported)) {
    blocking.push({ field: "viewpoint",
      reason: "所选视角「" + String(viewpoint) + "」没有可支持的商品依据；请补该视角的照片、改用已证视角，或暂不做这张图。" });
  }
  return { ready: blocking.length === 0, blocking };
}

/**
 * 每条上图文案的来源当前性（设计 §13.4.4）：来源槽位存在、已确认且版本一致才算当前。
 * @param {unknown} shotSpec
 * @param {ReadonlyArray<{slot: {slot_id: string, status: string}, version: number}> | null | undefined} slotEntries
 * @returns {{text_id: string, current: boolean, reason: string | null, source_version: number | null}[]}
 */
export function imageTextCurrentness(shotSpec, slotEntries) {
  const texts = Array.isArray(shotSpec && shotSpec.on_image_texts) ? shotSpec.on_image_texts : [];
  /** @type {Map<string, {slot: {slot_id: string, status: string}, version: number}>} */
  const index = new Map();
  for (const entry of Array.isArray(slotEntries) ? slotEntries : []) {
    if (isPlainObject(entry) && isPlainObject(entry.slot) && typeof entry.slot.slot_id === "string") {
      index.set(entry.slot.slot_id, entry);
    }
  }
  return texts.map((item) => {
    const source = isPlainObject(item) && isPlainObject(item.source) ? item.source : null;
    const entry = source && typeof source.document_id === "string"
      ? index.get(source.document_id) : undefined;
    if (!entry) {
      return { text_id: item && item.text_id, current: false,
        reason: "来源事实不存在或已删除。", source_version: null };
    }
    if (entry.slot.status !== "confirmed") {
      return { text_id: item && item.text_id, current: false,
        reason: "来源事实尚未确认。", source_version: entry.version };
    }
    if (!Number.isInteger(source && source.version) || entry.version !== source.version) {
      return { text_id: item && item.text_id, current: false,
        reason: "来源事实已更新（当前 v" + entry.version + "）。", source_version: entry.version };
    }
    return { text_id: item && item.text_id, current: true, reason: null, source_version: entry.version };
  });
}

/**
 * 只消费 confirmed 且来源当前的项（设计 §13.4.4）；返回可进入独立印字段的原文。
 * @param {unknown} shotSpec
 * @param {ReadonlyArray<{slot: {slot_id: string, status: string}, version: number}> | null | undefined} slotEntries
 * @returns {import("./type-contracts.js").OnImageText[]}
 */
export function confirmedCurrentImageTexts(shotSpec, slotEntries) {
  const texts = Array.isArray(shotSpec && shotSpec.on_image_texts) ? shotSpec.on_image_texts : [];
  const current = new Map(imageTextCurrentness(shotSpec, slotEntries).map((item) => [item.text_id, item]));
  return texts
    .filter((item) => item && item.status === "confirmed" && current.get(item.text_id)?.current === true)
    .map((item) => ({ ...item, source: { ...item.source } }));
}

/**
 * 展示决定的人读摘要（只列非中性项）；供审核清单与界面共用。
 * @param {{appearance_state?: string, contents_state?: string, viewpoint?: string} | null | undefined} effective
 * @returns {string[]}
 */
export function presentationSummary(effective) {
  if (!isPlainObject(effective)) return [];
  const lines = [];
  const appearance = {
    as_shown: "外观：保持原样展示", clean_display: "外观：清洁后展示",
  };
  const contents = {
    as_shown: "内容物：原样展示", empty: "内容物：倒空展示", not_applicable: "内容物：不适用（不是容器）",
  };
  const viewpoint = { front: "视角：正面", side: "视角：侧面", top: "视角：顶视" };
  if (appearance[effective.appearance_state]) lines.push(appearance[effective.appearance_state]);
  if (contents[effective.contents_state]) lines.push(contents[effective.contents_state]);
  if (viewpoint[effective.viewpoint]) lines.push(viewpoint[effective.viewpoint]);
  return lines;
}
