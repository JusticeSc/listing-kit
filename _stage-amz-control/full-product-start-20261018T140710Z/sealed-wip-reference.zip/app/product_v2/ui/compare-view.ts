/**
 * 精看视图（设计 §13.3 A 工作台「制作与审图」的常驻精看区）：逐图候选查看、历史对照、
 * 单图返工草稿闭环与人工采用。
 *
 * 边界（设计 §13.3/§13.5）：
 *  - 这里只持精看/返工/采用三区的 DOM 与就地内存态（当前图与当前查看候选、左侧来源选择、
 *    跨项目查看记忆、按「项目 + 图 + 问题候选精确身份」分桶的返工草稿、在飞标识），
 *    不写库、不发网络、不重算业务判定；
 *  - 候选链与尝试链的唯一所有者是 generation，采用记录与单图报告的唯一所有者是
 *    selectionAdoption；返工意图的编译/落版/确认收归 generation（它向 prompts 借窄能力）；
 *  - 落库/派生/跨区渲染都经 deps 回到工作区。比较排序与默认目标由 domain/compare.js 决定，这里只投影。
 *
 * B4（计划 §17.4）：
 *  - 逐图任务列表的唯一实现在生成视图；本视图不再渲染 `review-list` 卡片，
 *    旧的 renderReviewList 及其整份重复卡片实现、tablist 键盘编排与 closeCompare 一并删除；
 *  - 候选选择改为原生 `#compare-candidate-select`（无自定义方向键编排；Tab/上下键交给浏览器），
 *    选择只改「当前查看」，不采用、不改返工草稿来源；
 *  - 左侧来源栏默认显示商品依据（冻结引用里的 product_truth；旧记录没有 uses 时按原样可读），
 *    显式选历史候选时只切左侧列表与左图，当前查看不动；
 *  - 返工草稿按精确来源身份分桶：切图收起但保留，回图继续原候选草稿；查看别的候选不改来源，
 *    只显示不一致与「返回返工对象」；同图多份非空草稿在 `#rework-drafts` 里显式选择，不取第一个。
 *
 * TypeScript 迁移（计划 §9 V2.R7.5）：本文件是唯一手工维护实现；同名 `compare-view.js`
 * 由 `npm run build:frontend` 生成，浏览器只消费生成的 `.js`。
 */
import {
  ATTEMPT_STATES,
  COMPARE_CONTRACT_VERSION,
  COMPARE_SEVERITY_TEXT,
  COMPARE_STATE_TEXT,
  REWORK_CONTRACT_VERSION,
  REWORK_MODE_LABELS,
  REWORK_MODES,
  REWORK_PROBLEMS,
  attemptStateLabel,
  compareCounts,
  compareRowHeadline,
  compareRows,
  defaultCompareTargetId,
  nextPendingShotId,
  reviewChecklist,
  reviewIsCurrent,
  selectionSetText,
  sortFindings,
  suggestReworkProblems,
  suggestedReworkDirection,
  suitePlanSummary,
} from "../domain/index.js";
import {
  ROLE_TEXT,
  SEVERITY_BADGE,
  appendTech,
  clearError,
  createElement,
  errorMessageOf,
  showError,
  techDetails,
} from "./dom.js";
import type { ActionSnapshot } from "../session.js";
import type { InputsModule } from "../project-inputs.js";
import type {
  AttemptRecord,
  CompareRow,
  PlanShot,
  PromptReferenceSelection,
  ReviewFinding,
  ReviewReport,
  ReworkMode,
  SelectionState,
  SuitePlanSummary,
} from "../domain/type-contracts.js";
import type {
  AdoptionSource,
  SelectionAdoptionModule,
  SelectionEntry,
} from "../selection-adoption.js";
import type {
  GenerationModule,
  PrepareReworkBlocked,
  ReworkIntent,
  ReworkPromptChoice,
} from "../generation.js";

/**
 * 本视图负责的精看三区 DOM 句柄（与 index.html 的 id 一一对应，由工作区一次装配）。
 * B4 起：tablist 容器与旧 review-list 句柄删除，改由原生候选选择器承担；
 * 左侧来源 figure 与返工草稿容器由工作区新增。
 */
export type CompareElements = {
  comparePanel: HTMLElement;
  compareSubject: HTMLElement;
  compareJump: HTMLButtonElement;
  compareBasisTitle: HTMLElement;
  /** 左侧来源 figure（#compare-source-figure）：商品依据/历史候选来源链的归属容器。 */
  compareSourceFigure: HTMLElement;
  compareReferences: HTMLElement;
  /** 候选选择器（#compare-candidate-select）：唯一入口是原生 select；选择只改当前查看。 */
  compareCandidateSelect: HTMLSelectElement;
  compareChecklist: HTMLElement;
  compareStatus: HTMLElement;
  compareViewedImage: HTMLImageElement;
  compareViewedCaption: HTMLElement;
  compareViewedZoom: HTMLButtonElement;
  compareBaselineImage: HTMLImageElement;
  compareBaselineSelect: HTMLSelectElement;
  compareBaselineZoom: HTMLButtonElement;
  compareReview: HTMLButtonElement;
  imageZoomDialog: HTMLDialogElement;
  imageZoomTitle: HTMLElement;
  imageZoomContent: HTMLImageElement;
  imageZoomNative: HTMLButtonElement;
  imageZoomClose: HTMLButtonElement;
  reworkOpen: HTMLButtonElement;
  reworkPanel: HTMLElement;
  reworkBasis: HTMLElement;
  reworkProblems: HTMLElement;
  reworkDirection: HTMLTextAreaElement;
  reworkPreview: HTMLButtonElement;
  reworkEdit: HTMLButtonElement;
  reworkSubmit: HTMLButtonElement;
  reworkReset: HTMLButtonElement;
  reworkCancel: HTMLButtonElement;
  reworkPreviewBox: HTMLElement;
  reworkPreviewMeta: HTMLElement;
  reworkPreviewText: HTMLElement;
  reworkTech: HTMLElement;
  reworkTechBody: HTMLElement;
  reworkSummary: HTMLElement;
  /** 同图多份非空返工草稿的显式候选选择宿主（#rework-drafts）。 */
  reworkDrafts: HTMLElement;
  reworkStatus: HTMLElement;
  reworkError: HTMLElement;
  adoptOpen: HTMLButtonElement;
  adoptClear: HTMLButtonElement;
  adoptStatus: HTMLElement;
  adoptError: HTMLElement;
  adoptProgress: HTMLElement;
};

/**
 * 窄依赖：精看面唯一所有者的命令/投影 + 工作区级收尾与跨区只读回调。
 * 不注入整个工作区；需要工作区状态的都经只读回调读取。
 * 候选预览 URL 缓存归工作区（精看/返工/尝试共用一份 object URL，关闭项目统一撤销）。
 */
export type CompareViewDeps = {
  inputs: InputsModule;
  generation: GenerationModule;
  selectionAdoption: SelectionAdoptionModule;
  beginAction(): ActionSnapshot;
  currentProjectId(): string | null;
  /** 图号 → 人类可读标签（套图方案投影）；工作区唯一实现。 */
  shotLabelOf(shotId: string): string;
  /** 时间戳短格式：唯一实现在生成视图。 */
  shortTime(iso: unknown): string;
  ensurePreviewUrl(shotId: string, actionId: string, assetSha256: string): Promise<string | null>;
  /** 阶段切换（打开精看即停靠「制作与审图」阶段）；外壳归工作区。 */
  selectStage(stageId: string): void;
  /** 焦点还给用户当前看得见的入口（任务行查看入口 → 精看候选选择器 → 阶段条）；跨阶段 DOM 归工作区。 */
  focusReviewEntry(shotId: string | null): void;
  /** 采用/返工提交后的任务列表刷新（生成视图；显式切图时只调一次，不在渲染里递归调用）。 */
  renderAttempts(): void;
  /** 生成阶段错误位写入（唯一所有者在生成视图：同时写 #generateError/#attemptError；精看区不自持第二份错误 DOM）。 */
  showAttemptError(message: string): void;
  /** 返工提交成功后把 Prompt 列表与确认单切到最新（生成视图）。 */
  renderPrompts(): void;
  renderConfirm(): void;
  /** 参考图来源链的存在性核对（存储读归工作区）。 */
  readAsset(projectId: string, sha256: string): Promise<unknown>;
  /** 返工提交成功后的项目状态派生（工作区）。 */
  deriveState(): Promise<void>;
  /** 工作区级错误上报（精看区异步收尾用）。 */
  reportError(error: unknown): void;
  /** 有后缀的抛出信息；与生成区共用工作区同一实现。 */
  suffixedErrorMessage(error: unknown, fallback: string, suffix: string): string;
};

export type CompareView = {
  /** 常驻精看同轮刷新（生成区收尾、adoption 变更通知与工作区 refreshDerived 经此回调）。 */
  renderCompare(): void;
  /** 采用进度行（生成区收尾经此回调）。 */
  renderSelectionProgress(): void;
  /** 精看入口（任务行查看入口与「下一个待处理」共用）。 */
  openCompare(shotId: string, options?: { candidateId?: string | null; focus?: boolean }): void;
  /** 原生候选选择器变更：只改当前查看。 */
  handleCandidateChange(): void;
  isComparing(shotId: string): boolean;
  /** 当前精看的图（生成视图的任务列表据此标记选中行）。 */
  currentShotId(): string | null;
  /** 当前会话里是否还有非空、未确认的返工草稿（关项目/刷新前提示用）。 */
  hasUnsavedDrafts(): boolean;
  handleBaselineChange(): void;
  handleCompareReview(): Promise<void>;
  zoomViewed(): void;
  zoomBaseline(): void;
  closeImageZoom(): void;
  toggleZoomNative(): void;
  openReworkPanel(options?: { shotId?: string | null; candidateId?: string | null }): void;
  previewRework(): Promise<void>;
  editRework(): Promise<void>;
  submitRework(): Promise<void>;
  resetRework(): void;
  cancelRework(): void;
  handleReworkKeydown(event: KeyboardEvent): void;
  handleReworkDirectionInput(): void;
  /** 人工采用/取消采用：默认对当前正看着的候选操作（与旧签名一致）。 */
  adoptCandidate(kind: "select" | "clear", shotId?: string | null, candidateId?: string | null): Promise<void>;
  /** 采用记录只读投影（阶段外壳与交付视图经同一入口读）。 */
  selectionEntryOf(shotId: string | null): SelectionEntry | null;
  selectionStateOf(shotId: string): SelectionState;
  adoptedMarkOf(shotId: string | null): { candidate_id: string | null; state: SelectionState } | null;
  adoptSourceOf(shotId: string | null, candidateId: string | null): AdoptionSource | null;
  selectionTextOf(shotId: string): string;
  /** 重开项目时的就地状态归零：与原 loadWorkspace 重置项一一对应（草稿只在当前会话保留）。 */
  resetViewState(): void;
};

/** 返工草稿的精确来源身份：项目 + 图 + 问题候选文档身份/版本/hash。草稿只属于这一个对象。 */
export type ReworkDraftSource = {
  project_id: string;
  shot_id: string;
  candidate_id: string;
  document_version: number | null;
  asset_sha256: string;
};

/** 返工草稿（按精确来源身份留内存；意图只在显式预览后产生，视图原样持有并交回，不重算）。 */
export type CompareReworkDraft = {
  source: ReworkDraftSource;
  problems: string[];
  direction: string;
  mode: ReworkMode;
  /** 人工全文时的显式选择；缺席表示尚未选择（预览返回 blocked）。 */
  promptChoice: ReworkPromptChoice | null;
  /** 超容量时用户勾选的本图商品原参考依据（sha256 子集）；缺席=默认全选。 */
  selectedProductSha256: string[] | null;
  /** 最近一次 blocked 投影（超容量/人工稿未选/勾选不合法），供渲染勾选或选择。 */
  blocked?: PrepareReworkBlocked | null;
  intent?: ReworkIntent | null;
};

/** 套图方案摘要里的单图形状（视图只读 shot_id/label/required，不重算方案）。 */
type SuiteShotSummary = SuitePlanSummary["shots"][number];

/** 单份草稿自带的返工控件集：同草稿复用同一批节点，晚到渲染不重建、不丢焦点/插入点。 */
type ReworkControlSet = {
  problems: HTMLElement;
  modes: HTMLElement;
  selection: HTMLElement;
  blockedSignature: string;
};

/**
 * 精看视图工厂。
 * @param args.elements 本视图负责的 DOM 句柄
 * @param args.deps 窄依赖：业务命令/投影 + 装配期注入的投影回调
 */
export function createCompareView(
  { elements, deps }: { elements: CompareElements; deps: CompareViewDeps },
): CompareView {
  const { inputs, generation, selectionAdoption } = deps;

  // 精看区就地状态：当前图与当前查看候选、左侧来源（商品依据/历史候选）、异步代次、跨项目查看记忆。
  let compareShotId: string | null = null;
  let compareCandidateId: string | null = null;
  let compareToken = 0;
  let compareImageToken = 0;
  let compareBaselineId: string | null = null;
  const compareViews = new Map<string, { candidateId: string | null; baselineId: string | null }>();
  let imageZoomReturnFocus: HTMLElement | null = null;

  // 返工区就地状态：草稿按「项目 + 图 + 问题候选精确身份」分桶；每份草稿自带来源身份与全文，
  // 跨图/跨候选互不覆盖。控件节点按草稿键缓存，只在显式打开/切换草稿时换装。
  let reworkDrafts = new Map<string, CompareReworkDraft>();
  let reworkControls = new Map<string, ReworkControlSet>();
  let reworkOpenByShot = new Map<string, string>();
  let reworkDraftsSignature = "";
  let reworkInFlight = false;
  let reworkDraftKey: string | null = null;
  let reworkMismatchNode: HTMLElement | null = null;
  let decisionReasonNode: HTMLElement | null = null;

  /** 套图摘要快照：精看列表与阶段无关的本地投影入口，不重算方案。 */
  function shotSummaries(): SuiteShotSummary[] {
    const plan = inputs.suitePlan();
    return plan ? suitePlanSummary(plan, inputs.suiteContext()).shots : [];
  }

  function planShotOf(shotId: string | null): PlanShot | null {
    if (!shotId) return null;
    const plan = inputs.suitePlan();
    return (plan?.shots || []).find((item) => item && item.shot_id === shotId) || null;
  }

  function memoryKey(shotId: string): string {
    return (deps.currentProjectId() || "") + ":" + shotId;
  }

  /**
   * 精看面板只是投影：候选、报告、参考图全部来自 IndexedDB 已经存在的事实，
   * 排序与默认目标由 domain/compare.js 决定（唯一权威），这里不重算报告、不写任何记录。
   */
  function attemptsByActionId(): Record<string, AttemptRecord> {
    const map: Record<string, AttemptRecord> = {};
    for (const record of generation.allAttemptRecords()) {
      if (record && typeof record.action_id === "string") map[record.action_id] = record;
    }
    return map;
  }

  /** 每张图的候选行（异常优先）+ 计划顺序；报告只在 reviewIsCurrent 为真时参与。 */
  function compareInventory(): {
    shots: SuiteShotSummary[]; rowsByShotId: Record<string, CompareRow[]>;
  } {
    const shots = shotSummaries();
    const rowsByShotId: Record<string, CompareRow[]> = {};
    const attempts = attemptsByActionId();
    for (const item of shots) {
      const chain = generation.candidateChainOf(item.shot_id);
      const reports: Record<string, ReviewReport> = {};
      for (const entry of chain) {
        const candidate = entry.record;
        if (!candidate || typeof candidate.candidate_id !== "string") continue;
        const existing = selectionAdoption.reportOf(candidate.candidate_id);
        if (existing && reviewIsCurrent(existing.report, candidate)) {
          reports[candidate.candidate_id] = existing.report;
        }
      }
      rowsByShotId[item.shot_id] = compareRows({
        candidates: chain, reportsByCandidateId: reports, attemptsByActionId: attempts,
      });
    }
    return { shots, rowsByShotId };
  }

  function candidateRowOf(shotId: string, candidateId: string | null): CompareRow | null {
    if (!candidateId) return null;
    return (compareInventory().rowsByShotId[shotId] || [])
      .find((row) => row.candidate_id === candidateId) || null;
  }

  function compareStateLabel(row: CompareRow): string {
    return COMPARE_STATE_TEXT[row.review_state] || row.review_state;
  }

  /* --------------------------------------------------------------- 当前图与当前查看 */

  /** 常驻精看：只在没有上一次当前图时选计划里的第一张图（默认只在没有用户选择时给）。 */
  function resolveCurrentShotId(shots: SuiteShotSummary[]): string | null {
    const ids = shots.map((item) => item.shot_id);
    if (compareShotId && ids.indexOf(compareShotId) >= 0) return compareShotId;
    return ids.length ? ids[0] : null;
  }

  /**
   * 精看入口：显式切图时恢复该图的查看记忆（或没有选择），并停靠「制作与审图」；
   * 只在真的换了图时调一次 renderAttempts 更新任务列表选中行，不在渲染里递归调用。
   */
  function openCompare(shotId: string, options: { candidateId?: string | null; focus?: boolean } = {}): void {
    const changedShot = compareShotId !== shotId;
    compareShotId = shotId;
    if (options.candidateId !== undefined) {
      // 卡片动作显式交给哪条候选就看哪条：无效目标保持显式（面板给出「已经不在了」说明），
      // 不静默换成排在最前的另一条候选。
      compareCandidateId = options.candidateId;
      compareBaselineId = null;
    } else if (changedShot) {
      const memory = compareViews.get(memoryKey(shotId));
      compareCandidateId = memory ? memory.candidateId : null;
      compareBaselineId = memory ? memory.baselineId : null;
    }
    deps.selectStage("generate");
    renderCompare();
    if (changedShot) deps.renderAttempts();
    if (options.focus === true) {
      if (!elements.compareCandidateSelect.disabled) elements.compareCandidateSelect.focus();
      else deps.focusReviewEntry(shotId);
    }
  }

  function isComparing(shotId: string): boolean {
    return compareShotId === shotId;
  }

  function currentShotId(): string | null {
    return compareShotId;
  }

  function rememberCompareView(): void {
    const projectId = deps.currentProjectId();
    if (projectId && compareShotId) compareViews.set(memoryKey(compareShotId), {
      candidateId: compareCandidateId, baselineId: compareBaselineId,
    });
  }

  /**
   * 只换「当前查看」：不采用、不改返工草稿来源、不关返工面板。
   * 侧栏默认来源与当前候选绑定，因此这里只重画候选选项、两图、清单与采用/返工入口状态。
   */
  function selectViewedCandidate(candidateId: string | null): void {
    compareCandidateId = candidateId;
    const shotId = compareShotId;
    if (!shotId) return;
    const rows = compareInventory().rowsByShotId[shotId] || [];
    const row = rows.find((item) => item.candidate_id === candidateId) || null;
    const shot = planShotOf(shotId);
    rememberCompareView();
    renderCandidateSelect(rows, candidateId, Boolean(candidateId && !row));
    void renderCompareImages(rows);
    renderCompareChecklist(shot, row, Boolean(candidateId && !row));
    updateReworkEntry(shot, row);
    updateAdoptEntry(shot, row);
    void renderCompareSource(shot).catch(deps.reportError);
    renderReworkMismatch();
  }

  function handleCandidateChange(): void {
    const candidateId = elements.compareCandidateSelect.value || null;
    if (!compareShotId || !candidateId) return;
    selectViewedCandidate(candidateId);
  }

  /* ------------------------------------------------------------------- 主渲染 */

  /** 没有方案/方案里没有图时收起常驻精看；这里只是投影收尾，不改任何记录。 */
  function hideComparePanel(): void {
    compareCandidateId = null;
    compareBaselineId = null;
    compareToken += 1;
    compareImageToken += 1;
    elements.comparePanel.hidden = true;
    elements.compareCandidateSelect.replaceChildren();
    elements.compareCandidateSelect.disabled = true;
    elements.compareChecklist.innerHTML = "";
    elements.compareReferences.innerHTML = "";
    elements.compareBasisTitle.textContent = "";
    elements.compareBaselineSelect.replaceChildren();
    elements.compareBaselineSelect.disabled = true;
    elements.compareBaselineImage.hidden = true;
    elements.compareBaselineZoom.disabled = true;
    elements.compareViewedImage.hidden = true;
    elements.compareViewedZoom.disabled = true;
    elements.compareReview.disabled = true;
    hideReworkPanelKeepingDrafts();
    updateReworkEntry(null, null);
    updateAdoptEntry(null, null);
  }

  function renderCompare(): void {
    const plan = inputs.suitePlan();
    if (!plan) {
      compareShotId = null;
      hideComparePanel();
      return;
    }
    const previousShot = compareShotId;
    const inventory = compareInventory();
    const shotId = resolveCurrentShotId(inventory.shots);
    compareShotId = shotId;
    if (!shotId) {
      // 计划里一张图都没有：面板不常驻。
      hideComparePanel();
      return;
    }
    if (shotId !== previousShot) {
      // 切图：恢复该图的查看记忆；没有记忆就是没有用户选择。
      const memory = compareViews.get(memoryKey(shotId));
      compareCandidateId = memory ? memory.candidateId : null;
      compareBaselineId = memory ? memory.baselineId : null;
    }
    // openCompare 已更新请求图；草稿交接要比较上次实际呈现的图，而非刚写入的请求。
    const changedRenderedShot = elements.comparePanel.dataset.shotId !== shotId;
    const shot = planShotOf(shotId);
    const rows = inventory.rowsByShotId[shotId] || [];
    // 默认只在没有用户选择时给；已选但不在链上的候选保持显式缺失，不自动替换。
    if (!compareCandidateId) compareCandidateId = defaultCompareTargetId(rows);
    const viewed = rows.find((row) => row.candidate_id === compareCandidateId) || null;
    const missingRequested = Boolean(compareCandidateId && !viewed);

    elements.comparePanel.dataset.compareContract = COMPARE_CONTRACT_VERSION;
    elements.comparePanel.dataset.shotId = shotId;
    elements.comparePanel.hidden = false;
    const counts = compareCounts(rows);
    const parts = ["候选 " + counts.total];
    if (counts.pending) parts.push("待处理 " + counts.pending);
    if (counts.unknown) parts.push("未知 " + counts.unknown);
    if (counts.unchecked) parts.push("未检查 " + counts.unchecked);
    elements.compareSubject.textContent = deps.shotLabelOf(shotId) + " · " + parts.join(" · ");
    const nextShot = nextPendingShotId({
      rowsByShotId: inventory.rowsByShotId,
      shotOrder: inventory.shots.map((item) => item.shot_id),
      currentShotId: shotId,
    });
    elements.compareJump.disabled = !nextShot;
    elements.compareJump.dataset.targetShot = nextShot || "";

    renderCandidateSelect(rows, compareCandidateId, missingRequested);
    void renderCompareImages(rows);
    renderCompareChecklist(shot, viewed, missingRequested);
    updateReworkEntry(shot, viewed);
    updateAdoptEntry(shot, viewed);
    void renderCompareSource(shot).catch(deps.reportError);

    if (changedRenderedShot) {
      // 切图收起当前草稿但保留；回图继续原候选草稿（草稿与来源都在内存里）。
      const remembered = reworkOpenByShot.get(memoryKey(shotId));
      const rememberedDraft = remembered ? reworkDrafts.get(remembered) : null;
      if (remembered && rememberedDraft && draftHasContent(rememberedDraft)) {
        openDraft(remembered, { focus: false });
      } else {
        hideReworkPanelKeepingDrafts();
      }
    } else {
      syncReworkPanel();
    }
  }

  /* ------------------------------------------------------------- 候选与两张图 */

  /** 候选选择器：原生 select，选项标签带版本/采用/检查状态；显式缺失时保留占位项。 */
  function renderCandidateSelect(rows: CompareRow[], selectedId: string | null, missing: boolean): void {
    const select = elements.compareCandidateSelect;
    select.replaceChildren();
    if (!rows.length) {
      select.append(createElement("option", { text: "这张图还没有候选", attrs: { value: "" } }));
      select.disabled = true;
      return;
    }
    select.disabled = false;
    if (missing && selectedId) {
      select.append(createElement("option", {
        text: "候选 " + String(selectedId).slice(0, 12) + "…（已经不在了）",
        attrs: { value: selectedId },
      }));
    }
    const adopted = compareShotId ? adoptedMarkOf(compareShotId) : null;
    for (const row of rows) {
      const parts = ["候选 v" + (row.version === null ? "?" : row.version)];
      if (adopted && adopted.candidate_id === row.candidate_id) {
        parts.push(adopted.state === "current" ? "已采用" : "已采用（已过期）");
      }
      parts.push(compareStateLabel(row));
      select.append(createElement("option", { text: parts.join(" · "), attrs: { value: row.candidate_id } }));
    }
    select.value = selectedId || "";
  }

  /** 右侧「当前查看候选」一图 + 左侧历史挑选项：查看与对照都不改选、不采用。 */
  async function renderCompareImages(rows: CompareRow[]): Promise<void> {
    const token = ++compareImageToken;
    const viewed = rows.find((row) => row.candidate_id === compareCandidateId) || null;
    const comparison = rows.find((row) => row.candidate_id === compareBaselineId) || null;
    if (!comparison || comparison.candidate_id === compareCandidateId) compareBaselineId = null;
    const select = elements.compareBaselineSelect;
    select.replaceChildren(createElement("option", { text: "商品依据（默认）", attrs: { value: "" } }));
    for (const row of rows) {
      if (row.candidate_id === compareCandidateId) continue;
      select.append(createElement("option", {
        text: "候选 v" + (row.version === null ? "?" : row.version)
          + (compareShotId && adoptedMarkOf(compareShotId)?.candidate_id === row.candidate_id ? " · 已采用" : ""),
        attrs: { value: row.candidate_id },
      }));
    }
    select.value = compareBaselineId || "";
    select.disabled = rows.length <= 1;
    rememberCompareView();

    const adopted = compareShotId ? adoptedMarkOf(compareShotId) : null;
    elements.compareViewedImage.hidden = true;
    elements.compareViewedImage.removeAttribute("src");
    elements.compareViewedZoom.disabled = true;
    elements.compareViewedCaption.textContent = !compareCandidateId
      ? "这张图还没有候选（查看不等于采用）。"
      : viewed
        ? "当前查看：候选 v" + (viewed.version === null ? "?" : viewed.version)
          + (adopted && adopted.candidate_id === compareCandidateId ? " · 已采用" : " · 未采用此候选")
          + "；查看和对照不会改选，也不会自动采用。"
        : "这条候选已经不在了（" + String(compareCandidateId).slice(0, 12)
          + "…）：不会自动换成别的候选，请重新选择。";
    elements.compareReview.disabled = !viewed || !compareShotId || selectionAdoption.isReviewInFlight(compareShotId);

    if (viewed) {
      const url = await deps.ensurePreviewUrl(viewed.shot_id, viewed.candidate_id, viewed.asset_sha256);
      if (token !== compareImageToken) return;
      if (!url) {
        elements.compareViewedCaption.textContent = "这条候选的图片字节缺失（sha256 "
          + String(viewed.asset_sha256).slice(0, 12) + "…）；不会用另一张图片替代，请恢复项目包后重试。";
      } else {
        elements.compareViewedImage.src = url;
        elements.compareViewedImage.hidden = false;
        elements.compareViewedImage.dataset.candidateId = viewed.candidate_id;
        elements.compareViewedZoom.disabled = false;
      }
    }
  }

  /**
   * 左侧来源栏：默认商品依据 —— 当前查看候选原请求里的 product_truth 冻结引用
   * （旧记录没有 uses 元数据时按原样可读）；没有候选/没有请求时回落到资料与事实里
   * 当前商品参考图并明确标注，不冒充原任务图。显式选历史候选时只切左列表与左图，
   * 当前查看不动。字节缺失如实说明，不换图顶替。
   */
  async function renderCompareSource(shot: PlanShot | null): Promise<void> {
    const token = ++compareToken;
    const pid = deps.currentProjectId();
    const historyRow = shot && compareBaselineId
      ? candidateRowOf(shot.shot_id, compareBaselineId) : null;
    let references: PromptReferenceSelection[] = [];
    let note = "";
    if (shot && historyRow) {
      const frozen = frozenReferencesOf(shot.shot_id, historyRow.candidate_id);
      if (frozen === null) {
        note = "这条历史对照候选已经不在候选链里；不会用别的候选顶替。";
      } else if (!frozen.length) {
        note = "这条历史候选没有留下原任务参考图来源链；不会用当前新资料冒充原图。";
      } else {
        references = frozen;
        note = "历史对照：候选 v" + (historyRow.version === null ? "?" : historyRow.version)
          + " 的原任务参考图（" + references.length + " 张）；显示来源不改当前查看。";
      }
    } else if (shot && compareCandidateId) {
      const frozen = frozenReferencesOf(shot.shot_id, compareCandidateId);
      if (frozen && frozen.length) {
        const product = productTruthOf(frozen);
        references = product.references;
        note = "商品依据（当前候选原请求里的 " + (product.legacy ? "冻结参考图" : "product_truth 商品依据")
          + "，共 " + references.length + " 张）；均按原比例展示。";
      } else {
        references = inputs.sources().references || [];
        note = references.length
          ? "商品依据（资料与事实里的当前商品参考图，共 " + references.length + " 张）；这张图还没有已提交记录。"
          : "这张图还没有可显示的参考依据。";
      }
    } else {
      references = inputs.sources().references || [];
      note = references.length
        ? "商品依据（资料与事实里的当前商品参考图，共 " + references.length + " 张）。"
        : "这张图还没有可显示的参考依据。";
    }

    const entries: Array<{ reference: PromptReferenceSelection; asset: unknown }> = [];
    for (const reference of references) {
      if (!pid) { entries.push({ reference, asset: null }); continue; }
      const asset = await deps.readAsset(pid, reference.sha256);
      entries.push({ reference, asset });
    }
    if (token !== compareToken || pid !== deps.currentProjectId()) return;
    const list = elements.compareReferences;
    list.innerHTML = "";
    for (const entry of entries) {
      const item = createElement("li", { attrs: { "data-reference-sha256": entry.reference.sha256 } });
      const url = await deps.ensurePreviewUrl("参考图", entry.reference.sha256, entry.reference.sha256);
      if (token !== compareToken) return;
      if (url) {
        item.append(createElement("img", {
          attrs: { src: url, alt: "参考图 " + entry.reference.role, loading: "lazy" },
        }));
        const zoom = createElement("button", { text: "放大参考原图", attrs: { type: "button" } });
        zoom.addEventListener("click", () => openImageZoom(url, "参考原图 · " + (ROLE_TEXT[entry.reference.role] || entry.reference.role)));
        item.append(zoom);
      } else {
        item.append(createElement("span", { className: "meta", text: "资产缺失" }));
      }
      item.append(createElement("span", {
        className: "meta", text: ROLE_TEXT[entry.reference.role] || entry.reference.role,
      }));
      appendTech(item, ["sha256 " + String(entry.reference.sha256).slice(0, 8) + "…"]);
      list.append(item);
    }
    elements.compareBasisTitle.textContent = note;

    // 左图只有显式选历史候选时才出现；默认商品依据由列表本身表达，不放空图框。
    elements.compareBaselineImage.hidden = true;
    elements.compareBaselineImage.removeAttribute("src");
    elements.compareBaselineZoom.disabled = true;
    if (!historyRow) return;
    const url = await deps.ensurePreviewUrl(historyRow.shot_id, historyRow.candidate_id, historyRow.asset_sha256);
    if (token !== compareToken) return;
    if (!url) {
      elements.compareBasisTitle.textContent = note + " 该候选图片字节缺失（sha256 "
        + String(historyRow.asset_sha256).slice(0, 12) + "…）；不会用别的图片替代。";
      return;
    }
    elements.compareBaselineImage.src = url;
    elements.compareBaselineImage.hidden = false;
    elements.compareBaselineImage.dataset.candidateId = historyRow.candidate_id;
    elements.compareBaselineZoom.disabled = false;
  }

  /** 当前查看候选原动作冻结的参考图链；已有候选但无原动作观察时返回空数组，找不到候选返回 null。 */
  function frozenReferencesOf(shotId: string, candidateId: string | null): PromptReferenceSelection[] | null {
    const source = adoptSourceOf(shotId, candidateId);
    if (!source) return null;
    const attempt = attemptsByActionId()[source.candidate.action_id];
    return attempt && Array.isArray(attempt.references) ? attempt.references : [];
  }

  /** 冻结引用里的商品依据：只要带 product_truth 用途的；旧记录没有 uses 元数据时整链按原样可读。 */
  function productTruthOf(references: PromptReferenceSelection[]): {
    references: PromptReferenceSelection[]; legacy: boolean;
  } {
    const frozen = references.filter((ref) =>
      Array.isArray(ref.uses) && ref.uses.indexOf("product_truth") >= 0);
    if (frozen.length) return { references: frozen, legacy: false };
    return { references, legacy: true };
  }

  function openImageZoom(src: string, label: string): void {
    if (!src) return;
    imageZoomReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    elements.imageZoomContent.src = src;
    elements.imageZoomContent.alt = label;
    elements.imageZoomContent.classList.remove("at-native-size");
    elements.imageZoomTitle.textContent = label;
    elements.imageZoomNative.textContent = "100% 像素";
    elements.imageZoomDialog.showModal();
    elements.imageZoomClose.focus();
  }

  function closeImageZoom(): void {
    elements.imageZoomDialog.close();
    elements.imageZoomContent.removeAttribute("src");
    if (imageZoomReturnFocus?.isConnected) imageZoomReturnFocus.focus();
  }

  function zoomViewed(): void {
    openImageZoom(elements.compareViewedImage.src, elements.compareViewedCaption.textContent || "");
  }

  function zoomBaseline(): void {
    openImageZoom(elements.compareBaselineImage.src, "历史对照候选（不改当前查看，也不改采用）");
  }

  function toggleZoomNative(): void {
    const native = elements.imageZoomContent.classList.toggle("at-native-size");
    elements.imageZoomNative.textContent = native ? "适应窗口" : "100% 像素";
  }

  function handleBaselineChange(): void {
    compareBaselineId = elements.compareBaselineSelect.value || null;
    rememberCompareView();
    void renderCompareSource(planShotOf(compareShotId)).catch(deps.reportError);
  }

  /* ------------------------------------------------------------ 清单与无候选说明 */

  function compareFindingRow(finding: ReviewFinding): HTMLLIElement {
    const item = createElement("li", {
      className: "compare-finding",
      attrs: { "data-severity": finding.severity, "data-rule-id": finding.rule_id },
    });
    const head = createElement("div", { className: "compare-card-head" });
    head.append(createElement("span", {
      className: "badge " + (SEVERITY_BADGE[finding.severity] || "is-review-unknown"),
      text: COMPARE_SEVERITY_TEXT[finding.severity] || finding.severity,
    }));
    head.append(createElement("span", { className: "name", text: finding.title }));
    head.append(createElement("span", {
      className: "meta", text: finding.rule_id + " · v" + finding.rule_version,
    }));
    item.append(head);
    item.append(createElement("p", { className: "meta", text: finding.detail }));
    if (finding.measured !== null && finding.measured !== undefined) {
      item.append(createElement("p", {
        className: "meta", text: "实测：" + JSON.stringify(finding.measured).slice(0, 160),
      }));
    }
    return item;
  }

  /** 这张图当前为什么没有新候选：准备/缺证 → 提交中 → 失败/Unknown，各说清下一步。 */
  function attemptStateText(shotId: string): { kind: string; text: string } {
    const latest = generation.latestAttemptOf(shotId);
    if (!latest) {
      return { kind: "none", text: "这张图还没有提交记录：先在「制作与审图」里的生成摘要确认范围并提交。" };
    }
    const state = latest.record.state;
    if (state === ATTEMPT_STATES.failed) {
      return { kind: "failed", text: "上次提交失败："
        + ((latest.record.error && latest.record.error.message) || "没有记录原因")
        + "；已经生成的候选仍然保留，可以继续查看或采用。" };
    }
    if (state === ATTEMPT_STATES.unknown) {
      const taskId = latest.record.task_id;
      return { kind: "unknown", text: "上次提交的结果没有确认（Unknown）：不要重复提交；"
        + (taskId ? "可以按任务编号 " + String(taskId).slice(0, 12) + "… 核对。" : "没有任务编号，只能显式新建动作。") };
    }
    if (state === ATTEMPT_STATES.succeeded) {
      return { kind: "succeeded", text: "提交已经成功，但候选字节还没有取回：继续观察或取回，不会用别的图片替代。" };
    }
    return { kind: "running", text: "这次提交还没有结束（" + attemptStateLabel(state) + "）：成功后会立即出现在这里，其他图不受影响。" };
  }

  /** 没有候选时的精看正文：本图准备/缺证/提交/失败/Unknown 原因，不放空图框。 */
  function appendNoCandidateState(box: HTMLElement, shot: PlanShot | null): void {
    const summary = shot ? (shotSummaries().find((item) => item.shot_id === shot.shot_id) || null) : null;
    if (summary && !summary.satisfied && summary.blocking.length) {
      box.append(createElement("h5", { text: "这张图还缺什么" }));
      const list = createElement("ul", { className: "compare-findings" });
      for (const item of summary.blocking) {
        list.append(createElement("li", {
          className: "meta",
          attrs: { "data-blocking-kind": item.kind || "unknown" },
          text: (item.reason || "依赖未满足")
            + (item.missing && item.missing.length ? "：" + item.missing.join("；") : ""),
        }));
      }
      box.append(list);
    }
    if (!shot) {
      box.append(createElement("p", { className: "meta", text: "先选择一张图。" }));
      return;
    }
    const state = attemptStateText(shot.shot_id);
    box.append(createElement("p", {
      className: "meta", attrs: { "data-attempt-state": state.kind }, text: state.text,
    }));
  }

  /** 审核清单 = 当前候选的待处理发现（异常优先）+ 这张图的验收依据 + 按需展开的完整报告。 */
  function renderCompareChecklist(shot: PlanShot | null, row: CompareRow | null, missing = false): void {
    const box = elements.compareChecklist;
    box.innerHTML = "";
    box.setAttribute("aria-labelledby", "compare-title");
    if (missing) {
      box.removeAttribute("data-compare-state");
      delete box.dataset.candidateId;
      box.append(createElement("p", {
        className: "prompt-warning",
        text: "这条候选已经不在了：清单、采用和返工都停在这一步，请从上方候选选择里重新选一条；"
          + "不会自动换成别的候选。",
      }));
    } else if (!row) {
      appendNoCandidateState(box, shot);
    } else {
      box.dataset.compareState = row.review_state;
      box.dataset.candidateId = row.candidate_id;
      // 候选在但最新一次提交没有成功：保留旧候选可看/可采用，同时说明新候选为什么还没到。
      if (shot) {
        const latestState = generation.latestAttemptOf(shot.shot_id)?.record.state || null;
        if (latestState && latestState !== ATTEMPT_STATES.succeeded) {
          const state = attemptStateText(shot.shot_id);
          box.append(createElement("p", {
            className: "meta", attrs: { "data-attempt-state": state.kind }, text: state.text,
          }));
        }
      }
      const report = row.report;
      if (report) {
        const findings = sortFindings(report.findings);
        const actionable = findings.filter((item) => item.severity !== "PASS");
        if (actionable.length) {
          box.append(createElement("h5", { text: "先看这些（" + actionable.length + "）" }));
          const list = createElement("ul", { className: "compare-findings" });
          for (const finding of actionable) list.append(compareFindingRow(finding));
          box.append(list);
        } else {
          // 没有待处理项时，这里一句话说明状态就够；细节在完整报告里。
          box.append(createElement("p", { className: "meta", text: compareRowHeadline(row) }));
        }
        const details = createElement("details", { className: "compare-report" });
        details.append(createElement("summary", {
          text: "完整报告（合同 " + report.review_contract_version + " · " + findings.length + " 条）",
        }));
        details.append(createElement("p", {
          className: "compare-report-row",
          text: "候选 sha256 " + String(row.asset_sha256).slice(0, 16) + "… · 报告生成 "
            + deps.shortTime(report.created_at),
        }));
        const vlm = report.vlm;
        const vlmText = vlm
          ? (vlm.outcome === "checked" ? "已完成" : "未完成（结果未知，不阻断人工审核）")
          : "未复核（未运行，未发起 AI 复核；不阻断人工采用）";
        details.append(createElement("p", {
          className: "compare-report-row",
          attrs: { "data-compare-vlm": vlm ? vlm.outcome : "not_run" },
          text: "视觉复核（按需发起）：" + vlmText + (vlm && vlm.model_id ? " · " + vlm.model_id : ""),
        }));
        const all = createElement("ul", { className: "compare-findings" });
        for (const finding of findings) all.append(compareFindingRow(finding));
        details.append(all);
        box.append(details);
      } else {
        box.append(createElement("p", { className: "meta", text: compareRowHeadline(row) }));
        const reportFailure = selectionAdoption.reportBuildFailure(row.candidate_id);
        if (reportFailure) {
          box.append(createElement("p", {
            className: "meta",
            attrs: { "data-review-report": "failed" },
            text: "自动检查报告补建失败：" + reportFailure
              + "（候选与本地图片保留，采用会被挡住；重新打开或再次采用会补建，不需要 AI）",
          }));
        }
      }
    }
    box.append(createElement("h5", { text: "这张图的验收依据" }));
    if (!shot) return;
    const specEntry = inputs.shotSpecEntry(shot.shot_id);
    const checklist = reviewChecklist(shot, {
      shotSpec: specEntry ? specEntry.spec : null, styleSpec: inputs.styleSpec(),
    });
    const criteria = createElement("ul", { className: "compare-basis-list" });
    criteria.append(createElement("li", { text: "目的：" + checklist.purpose }));
    if (checklist.must_keep.length) {
      criteria.append(createElement("li", { text: "必须保持：" + checklist.must_keep.join("；") }));
    }
    if (checklist.may_change.length) {
      criteria.append(createElement("li", { text: "允许变化：" + checklist.may_change.join("；") }));
    }
    if (checklist.style_lines.length) {
      criteria.append(createElement("li", { text: "公共风格：" + checklist.style_lines.join("；") }));
    }
    if (!checklist.saved) {
      criteria.append(createElement("li", {
        className: "meta", text: "单图规格尚未保存，这里用的是默认派生值。",
      }));
    }
    box.append(criteria);
    if (!row) return;
    const techLines = [
      "candidate " + String(row.candidate_id),
      "sha256 " + String(row.asset_sha256).slice(0, 12) + "…",
    ];
    if (row.task_id) techLines.push("task " + String(row.task_id).slice(0, 8));
    else if (row.attempt_action_id) techLines.push("action " + String(row.attempt_action_id).slice(0, 8));
    const tech = techDetails(techLines);
    if (tech) box.append(tech);
  }

  /** 单图 AI 复核（按需发起）：只响应用户显式点击；查看/切换/采用不调用此函数。
   * 未运行如实记 not_run（reviewStatusOf 投影），不折叠成 Unknown、不进 ack 门。 */
  async function handleCompareReview(): Promise<void> {
    const shotId = compareShotId, candidateId = compareCandidateId;
    if (!shotId || !candidateId) return;
    const outcome = await selectionAdoption.reviewCandidate(shotId, candidateId);
    if (shotId === compareShotId && candidateId === compareCandidateId) {
      renderCompare();
      elements.compareStatus.textContent = outcome?.failed
        ? "AI 复核未完成：" + outcome.message + "（真实失败才记 Unknown，未发起仍是未复核）"
        : "复核结果只属于所点击的这条候选，不自动采用；未复核不阻断人工采用。";
    }
  }

  /* ------------------------------------------------ 单图返工闭环（V2.5.4 / B4） */

  /** 草稿非空判定：只有真的有内容（问题/方向/已预览意图）才算未确认草稿。 */
  function draftHasContent(draft: CompareReworkDraft | null): boolean {
    if (!draft) return false;
    return draft.problems.length > 0
      || String(draft.direction || "").trim().length > 0
      || Boolean(draft.intent);
  }

  /** 草稿键 = 项目 + 图 + 问题候选文档身份/版本/hash（不用只按 shot 的 Map）。 */
  function draftKeyOf(source: ReworkDraftSource): string {
    return [
      source.project_id,
      source.shot_id,
      source.candidate_id,
      source.document_version === null ? "?" : String(source.document_version),
      source.asset_sha256,
    ].join("\u0000");
  }

  function openDraftOf(): CompareReworkDraft | null {
    return reworkDraftKey ? reworkDrafts.get(reworkDraftKey) || null : null;
  }

  /** 按精确来源取草稿；不存在时新建独立空稿（新候选不复制旧方向、不覆盖旧草稿）。 */
  function draftFor(source: ReworkDraftSource): { key: string; draft: CompareReworkDraft } {
    const key = draftKeyOf(source);
    let draft = reworkDrafts.get(key);
    if (!draft) {
      draft = {
        source,
        problems: [],
        direction: "",
        mode: "edit_candidate",
        promptChoice: null,
        selectedProductSha256: null,
        blocked: null,
        intent: null,
      };
      reworkDrafts.set(key, draft);
      reworkControls.delete(key);
    }
    return { key, draft };
  }

  function reworkSummaryOf(draft: CompareReworkDraft | null): string {
    if (draft && draft.intent) {
      return "预览已就绪：确认并生成会把它保存为 Prompt 新版本（旧版本保留），"
        + "只重新生成这张图；改过问题或方向后需要重新预览。";
    }
    return "选好问题或写下方向 → 预览返工 Prompt → 确认并生成这张图。";
  }

  function syncReworkControls(draft: CompareReworkDraft | null): void {
    if (!draft) return;
    const hasReason = draft.problems.length > 0
      || String(elements.reworkDirection.value || "").trim().length > 0;
    const busy = reworkInFlight;
    elements.reworkPreview.disabled = busy || !hasReason;
    elements.reworkEdit.disabled = true;
    elements.reworkSubmit.disabled = busy || !draft.intent;
    elements.reworkReset.disabled = busy;
    elements.reworkCancel.disabled = busy;
    elements.reworkSummary.textContent = reworkSummaryOf(draft);
  }

  /** 输入变了：旧意图不再代表将要发送的内容，必须重新预览。 */
  function dirtyReworkDraft(draft: CompareReworkDraft | null): void {
    if (!draft || !draft.intent) return;
    draft.intent = null;
    elements.reworkPreviewBox.hidden = true;
    elements.reworkStatus.hidden = true;
  }

  function renderReworkPreviewBox(draft: CompareReworkDraft | null): void {
    if (!draft || !draft.intent) {
      elements.reworkPreviewBox.hidden = true;
      return;
    }
    elements.reworkPreviewBox.hidden = false;
    elements.reworkPreviewMeta.textContent =
      "将保存为 Prompt 新版本（旧版本保留）并只重新生成这张图 · 参考图 "
      + draft.intent.preview.references + " 张 · 全文 " + draft.intent.preview.text.length + " 字";
    elements.reworkPreviewText.textContent = draft.intent.preview.text;
  }

  /** 附加块（模式 + 超容量/人工稿选择）容器：动态挂载在问题列表之后，不新增 index.html id。 */
  function ensureReworkChoiceHosts(): { modes: HTMLElement; selection: HTMLElement } {
    let modes = elements.reworkPanel.querySelector<HTMLElement>(".rework-modes");
    if (!modes) {
      modes = createElement("div", { className: "rework-modes" });
      elements.reworkProblems.insertAdjacentElement("afterend", modes);
    }
    let selection = elements.reworkPanel.querySelector<HTMLElement>(".rework-selection");
    if (!selection) {
      selection = createElement("div", { className: "rework-selection" });
      modes.insertAdjacentElement("afterend", selection);
    }
    return { modes, selection };
  }

  /**
   * 单份草稿自带的控件集：问题勾选、返工方式、超容量/人工稿选择一次建成，
   * 之后同一草稿只换装这套节点（节点身份不变），晚到渲染不会重建输入或丢插入点。
   */
  function reworkControlSetOf(key: string, draft: CompareReworkDraft): ReworkControlSet {
    let set = reworkControls.get(key);
    if (set) return set;
    const problems = createElement("div", {
      className: "rework-draft-problems", attrs: { "data-draft-key": key },
    });
    // 同一份草稿的输入 id 唯一到草稿身份（同一图多份草稿不会出现重复 id）；label 仍隐式关联。
    const keySlug = key.replace(/[^A-Za-z0-9_-]/g, "-");
    for (const problem of REWORK_PROBLEMS) {
      const label = createElement("label", {
        className: "check rework-problem",
        attrs: { title: problem.hint, "data-problem-id": problem.id },
      });
      const input = createElement("input", {
        attrs: { id: "rework-problem-" + keySlug + "-" + problem.id, type: "checkbox", value: problem.id },
      });
      input.checked = draft.problems.indexOf(problem.id) >= 0;
      input.addEventListener("change", () => {
        if (input.checked) {
          if (draft.problems.indexOf(problem.id) === -1) {
            draft.problems = draft.problems.concat([problem.id]);
          }
        } else {
          draft.problems = draft.problems.filter((id) => id !== problem.id);
        }
        dirtyReworkDraft(draft);
        syncReworkControls(draft);
        renderReworkDrafts(reworkDraftKey);
      });
      label.append(input, document.createTextNode(" " + problem.label));
      problems.append(label);
    }
    const modes = createElement("div", {
      className: "rework-draft-modes", attrs: { "data-draft-key": key },
    });
    modes.append(createElement("p", { className: "meta", text: "返工方式（模型实际收到的图序不同）：" }));
    for (const mode of REWORK_MODES) {
      const label = createElement("label", { className: "radio rework-mode", attrs: { "data-mode": mode } });
      const input = createElement("input", { attrs: { type: "radio", name: "rework-mode-" + key, value: mode } });
      input.checked = draft.mode === mode;
      input.addEventListener("change", () => {
        if (!input.checked) return;
        draft.mode = mode;
        dirtyReworkDraft(draft);
        syncReworkControls(draft);
      });
      label.append(input, document.createTextNode(" " + (REWORK_MODE_LABELS[mode] || mode)
        + (mode === "edit_candidate" ? "（默认：图 1 为当前候选）" : "（不发送候选图）")));
      modes.append(label);
    }
    const selection = createElement("div", {
      className: "rework-draft-selection", attrs: { "data-draft-key": key },
    });
    set = { problems, modes, selection, blockedSignature: "" };
    reworkControls.set(key, set);
    return set;
  }

  function blockedSignatureOf(blocked: PrepareReworkBlocked | null | undefined): string {
    if (!blocked) return "none";
    const choices = (blocked.selection || []).map((item) => item.sha256 + (item.required ? ":1" : ":0")).join(",");
    return [blocked.reason, blocked.message, blocked.capacity === undefined ? "" : String(blocked.capacity), choices].join("|");
  }

  /** 附加选择：人工稿时给出「保留/改用系统稿」，超容量时给出本图必要参考依据的普通复选框。 */
  function renderReworkChoice(set: ReworkControlSet, draft: CompareReworkDraft): void {
    const blocked = draft.blocked || null;
    const signature = blockedSignatureOf(blocked);
    if (signature === set.blockedSignature) return;
    set.blockedSignature = signature;
    const host = set.selection;
    host.textContent = "";
    if (!blocked) return;
    if (blocked.reason === "needs_manual_choice") {
      host.append(createElement("p", { className: "prompt-warning", text: blocked.message }));
      const options: { value: ReworkPromptChoice; label: string }[] = [
        { value: "keep_and_review", label: "保留人工全文并核对本次模式/图序" },
        { value: "system_rework", label: "使用系统返工稿（保留原人工历史）" },
      ];
      for (const option of options) {
        const label = createElement("label", { className: "radio rework-choice", attrs: { "data-choice": option.value } });
        const input = createElement("input", {
          attrs: { type: "radio", name: "rework-choice-" + draftKeyOf(draft.source), value: option.value },
        });
        input.checked = draft.promptChoice === option.value;
        input.addEventListener("change", () => {
          if (!input.checked) return;
          draft.promptChoice = option.value;
          dirtyReworkDraft(draft);
          syncReworkControls(draft);
        });
        label.append(input, document.createTextNode(" " + option.label));
        host.append(label);
      }
      return;
    }
    const choices = blocked.selection;
    if (!choices || choices.length === 0) {
      host.append(createElement("p", { className: "meta", text: blocked.message }));
      return;
    }
    // 首次超容量：默认只勾选必需项，用户可再增选本图必要依据（必需的不可取消）。
    if (draft.selectedProductSha256 === null) {
      draft.selectedProductSha256 = choices.filter((item) => item.required).map((item) => item.sha256);
    }
    const selected = new Set(draft.selectedProductSha256);
    host.append(createElement("p", {
      className: "prompt-warning",
      text: blocked.message + "（上限 " + String(blocked.capacity || choices.length) + " 张）",
    }));
    for (const choice of choices) {
      const label = createElement("label", { className: "check rework-source", attrs: { "data-sha256": choice.sha256 } });
      const input = createElement("input", { attrs: { type: "checkbox", value: choice.sha256 } });
      input.checked = selected.has(choice.sha256);
      input.disabled = choice.required;
      input.addEventListener("change", () => {
        const next = new Set(draft.selectedProductSha256 || []);
        if (input.checked) next.add(choice.sha256); else next.delete(choice.sha256);
        draft.selectedProductSha256 = [...next];
        dirtyReworkDraft(draft);
        syncReworkControls(draft);
      });
      label.append(input, document.createTextNode(" " + (ROLE_TEXT[choice.role] || choice.role)
        + " · " + choice.sha256.slice(0, 12) + "…" + (choice.required ? "（必需）" : "")));
      host.append(label);
    }
  }

  /** 把某份草稿的控件集换装到固定宿主；同一草稿重复调用是幂等的（节点不重建）。 */
  function attachReworkControls(key: string, draft: CompareReworkDraft): void {
    const set = reworkControlSetOf(key, draft);
    const problemHost = elements.reworkProblems.querySelector<HTMLElement>(".rework-problem-options")
      || elements.reworkProblems;
    if (set.problems.parentElement !== problemHost) problemHost.replaceChildren(set.problems);
    const hosts = ensureReworkChoiceHosts();
    if (set.modes.parentElement !== hosts.modes) hosts.modes.replaceChildren(set.modes);
    if (set.selection.parentElement !== hosts.selection) hosts.selection.replaceChildren(set.selection);
    renderReworkChoice(set, draft);
  }

  function draftSummaryText(draft: CompareReworkDraft): string {
    const parts: string[] = [];
    if (draft.problems.length) parts.push("问题 " + draft.problems.length + " 类");
    if (String(draft.direction || "").trim().length) parts.push("方向 " + String(draft.direction).trim().length + " 字");
    if (draft.intent) parts.push("已预览");
    return parts.length ? parts.join(" · ") : "尚无内容";
  }

  /** 同图多份草稿的显式选择：列出每份非空草稿的候选身份，绝不静默取第一份。 */
  function renderReworkDrafts(openKey: string | null): void {
    const host = elements.reworkDrafts;
    const projectId = deps.currentProjectId();
    const shotId = openKey ? (reworkDrafts.get(openKey)?.source.shot_id || null) : null;
    const entries: Array<[string, CompareReworkDraft]> = [];
    if (shotId && projectId) {
      for (const [key, draft] of reworkDrafts) {
        if (draft.source.shot_id !== shotId || draft.source.project_id !== projectId) continue;
        if (draftHasContent(draft) || key === openKey) entries.push([key, draft]);
      }
    }
    entries.sort((left, right) =>
      (left[1].source.document_version || 0) - (right[1].source.document_version || 0));
    const signature = entries
      .map(([key, draft]) => key + "|" + (key === openKey ? "1" : "0") + "|" + draft.problems.join(",") + "|"
        + (draft.intent ? "i" : "") + "|" + String(draft.direction).length)
      .join(";");
    if (signature === reworkDraftsSignature) return;
    reworkDraftsSignature = signature;
    host.textContent = "";
    if (entries.length < 2) {
      host.hidden = true;
      return;
    }
    host.hidden = false;
    host.append(createElement("p", {
      className: "meta",
      text: "这张图有 " + entries.length + " 份返工草稿（各自绑定来源，不会互相覆盖）；选择要继续的那一份：",
    }));
    for (const [key, draft] of entries) {
      const button = createElement("button", {
        className: "draft-entry",
        attrs: {
          type: "button",
          "data-draft-key": key,
          "data-candidate-id": draft.source.candidate_id,
          "aria-current": key === openKey ? "true" : "false",
        },
        text: "候选 v" + (draft.source.document_version === null ? "?" : draft.source.document_version)
          + " · " + draft.source.asset_sha256.slice(0, 8) + "…（" + draftSummaryText(draft) + "）"
          + (key === openKey ? " · 正在编辑" : ""),
      });
      button.addEventListener("click", () => { openDraft(key, { focus: true }); });
      host.append(button);
    }
  }

  /** 查看的门与返工草稿来源不一致时如实说明，并给显式的「返回返工对象」。 */
  function ensureReworkMismatchHost(): HTMLElement {
    if (reworkMismatchNode && reworkMismatchNode.isConnected) return reworkMismatchNode;
    reworkMismatchNode = createElement("div", { className: "rework-mismatch", attrs: { hidden: "hidden" } });
    elements.reworkBasis.insertAdjacentElement("afterend", reworkMismatchNode);
    return reworkMismatchNode;
  }

  function renderReworkMismatch(): void {
    const host = ensureReworkMismatchHost();
    const draft = openDraftOf();
    if (!draft || elements.reworkPanel.hidden) {
      host.hidden = true;
      host.textContent = "";
      return;
    }
    const source = draft.source;
    if (compareShotId === source.shot_id && compareCandidateId === source.candidate_id) {
      host.hidden = true;
      host.textContent = "";
      return;
    }
    const version = source.document_version === null ? "?" : source.document_version;
    host.hidden = false;
    host.textContent = "";
    host.append(createElement("p", {
      className: "prompt-warning",
      text: "正在查看的不是这份草稿的返工对象（草稿来源：候选 v" + version + " · "
        + source.asset_sha256.slice(0, 8) + "…）；查看别的候选不会改动这份草稿，也不会改它的模式或全文。",
    }));
    const back = createElement("button", {
      text: "返回返工对象（候选 v" + version + "）", attrs: { type: "button" },
    });
    back.addEventListener("click", () => { selectViewedCandidate(source.candidate_id); });
    host.append(back);
  }

  /** 打开某份草稿：换装它的控件集、同步方向文本与预览框，不重建节点。 */
  function openDraft(key: string, options: { focus?: boolean; row?: CompareRow | null } = {}): void {
    const draft = reworkDrafts.get(key);
    if (!draft) return;
    const row = options.row !== undefined
      ? options.row : candidateRowOf(draft.source.shot_id, draft.source.candidate_id);
    reworkDraftKey = key;
    reworkOpenByShot.set(memoryKey(draft.source.shot_id), key);
    const panel = elements.reworkPanel;
    panel.hidden = false;
    panel.dataset.reworkContract = REWORK_CONTRACT_VERSION;
    panel.dataset.shotId = draft.source.shot_id;
    panel.dataset.candidateId = draft.source.candidate_id;
    panel.dataset.draftKey = key;
    const version = draft.source.document_version === null ? "?" : draft.source.document_version;
    const basis = ["返工依据：候选 v" + version];
    if (row && row.top_finding) basis.push("先看：" + row.top_finding.title);
    elements.reworkBasis.textContent = basis.join(" · ");
    if (elements.reworkTech && elements.reworkTechBody) {
      elements.reworkTech.hidden = false;
      elements.reworkTechBody.textContent = "sha256 " + String(draft.source.asset_sha256).slice(0, 12)
        + "… · candidate " + draft.source.candidate_id + " · 草稿身份 " + key.slice(-32);
    }
    attachReworkControls(key, draft);
    if (elements.reworkDirection.value !== draft.direction) elements.reworkDirection.value = draft.direction;
    renderReworkPreviewBox(draft);
    elements.reworkStatus.hidden = true;
    clearError(elements.reworkError);
    syncReworkControls(draft);
    reworkDraftsSignature = "";
    renderReworkDrafts(key);
    renderReworkMismatch();
    if (options.focus === true) {
      const first = elements.reworkProblems.querySelector<HTMLInputElement>('input[type="checkbox"]');
      if (first) first.focus();
      panel.scrollIntoView({ block: "nearest" });
    }
  }

  /** 入口：只接受显式候选身份；缺失时可见阻断，不回退到另一条候选/另一份草稿。 */
  function openReworkPanel(options: { shotId?: string | null; candidateId?: string | null } = {}): void {
    if (reworkInFlight) return;
    const shotId = options.shotId !== undefined ? options.shotId : compareShotId;
    const candidateId = options.candidateId !== undefined
      ? options.candidateId
      : (elements.reworkOpen.dataset.candidateId || compareCandidateId);
    const projectId = deps.currentProjectId();
    if (!projectId || !shotId || !candidateId) {
      elements.compareStatus.textContent = "先选定一条候选，再返工这张图。";
      return;
    }
    const row = candidateRowOf(shotId, candidateId);
    if (!row || !row.record || row.candidate_id !== candidateId) {
      elements.compareStatus.textContent = "这条候选已经不在了，先重新选择候选。";
      return;
    }
    // 同一候选的多份草稿不自动合并：这里取的全是精确来源身份对应的那一份，不存在就新建。
    const { key } = draftFor({
      project_id: projectId,
      shot_id: shotId,
      candidate_id: row.candidate_id,
      document_version: row.version === null || row.version === undefined ? null : row.version,
      asset_sha256: row.asset_sha256,
    });
    openDraft(key, { focus: true, row });
  }

  function hideReworkPanelKeepingDrafts(): void {
    reworkDraftKey = null;
    elements.reworkPanel.hidden = true;
    elements.reworkPreviewBox.hidden = true;
    elements.reworkStatus.hidden = true;
    elements.reworkDrafts.hidden = true;
    elements.reworkDrafts.textContent = "";
    reworkDraftsSignature = "";
    if (reworkMismatchNode) {
      reworkMismatchNode.hidden = true;
      reworkMismatchNode.textContent = "";
    }
  }

  /** 收起返工区：清掉未确认的意图；草稿（问题/方向/模式/来源）留在内存里。 */
  function closeReworkPanel({ focusCandidate = false }: { focusCandidate?: boolean } = {}): void {
    const draft = openDraftOf();
    const shotId = draft ? draft.source.shot_id : compareShotId;
    if (draft) draft.intent = null;
    const hadFocus = elements.reworkPanel.contains(document.activeElement);
    hideReworkPanelKeepingDrafts();
    clearError(elements.reworkError);
    if (focusCandidate || hadFocus) focusAfterReworkClose(shotId);
  }

  /** 收起后把焦点还给看得见的入口：本图的「返工当前候选」→ 候选选择器 → 工作区入口。 */
  function focusAfterReworkClose(shotId: string | null): void {
    if (shotId && compareShotId === shotId) {
      if (!elements.reworkOpen.disabled) { elements.reworkOpen.focus(); return; }
      if (!elements.compareCandidateSelect.disabled) { elements.compareCandidateSelect.focus(); return; }
    }
    deps.focusReviewEntry(shotId);
  }

  /** 按建议重填：问题与方向回到报告先看项的默认值，预览作废；控件节点复用（不重建、不丢焦点）。 */
  function resetRework(): void {
    const draft = openDraftOf();
    if (!draft || reworkInFlight) return;
    const row = candidateRowOf(draft.source.shot_id, draft.source.candidate_id);
    draft.problems = suggestReworkProblems(row ? row.report : null);
    draft.direction = suggestedReworkDirection(row ? row.report : null);
    draft.selectedProductSha256 = null;
    draft.promptChoice = null;
    draft.blocked = null;
    draft.intent = null;
    const set = reworkDraftKey ? reworkControls.get(reworkDraftKey) : null;
    if (set) {
      for (const input of Array.from(set.problems.querySelectorAll<HTMLInputElement>('input[type="checkbox"]'))) {
        input.checked = draft.problems.indexOf(input.value) >= 0;
      }
      renderReworkChoice(set, draft);
    }
    if (elements.reworkDirection.value !== draft.direction) elements.reworkDirection.value = draft.direction;
    elements.reworkPreviewBox.hidden = true;
    elements.reworkStatus.hidden = true;
    clearError(elements.reworkError);
    syncReworkControls(draft);
    reworkDraftsSignature = "";
    renderReworkDrafts(reworkDraftKey);
  }

  function cancelRework(): void {
    if (reworkInFlight) return;
    closeReworkPanel({ focusCandidate: true });
  }

  function handleReworkKeydown(event: KeyboardEvent): void {
    if (event.key === "Escape") {
      event.preventDefault();
      cancelRework();
    }
  }

  function handleReworkDirectionInput(): void {
    const draft = openDraftOf();
    if (!draft) return;
    draft.direction = elements.reworkDirection.value;
    dirtyReworkDraft(draft);
    syncReworkControls(draft);
    reworkDraftsSignature = "";
    renderReworkDrafts(reworkDraftKey);
  }

  /** 这份草稿的来源是否仍然精确可用（候选在链上且 hash 未漂移）；不可用就显式阻断，不回退。 */
  function sourceStillExact(draft: CompareReworkDraft): CompareRow | null {
    const row = candidateRowOf(draft.source.shot_id, draft.source.candidate_id);
    if (!row || !row.record || row.candidate_id !== draft.source.candidate_id) return null;
    if (String(row.asset_sha256) !== String(draft.source.asset_sha256)) return null;
    return row;
  }

  /** 预览：owner 编译一次只读意图；视图只持有并显示，不写记录。 */
  async function previewRework(): Promise<void> {
    const draft = openDraftOf();
    if (!deps.currentProjectId() || !draft || reworkInFlight) return;
    clearError(elements.reworkError);
    const row = sourceStillExact(draft);
    if (!row) {
      draft.intent = null;
      renderReworkPreviewBox(draft);
      showError(elements.reworkError, "返工依据已经不在或已变化，先回到比较区重新选择候选；没有生成预览。");
      return;
    }
    draft.direction = elements.reworkDirection.value;
    reworkInFlight = true;
    syncReworkControls(draft);
    try {
      const outcome = await generation.prepareRework({
        shotId: draft.source.shot_id, candidateId: draft.source.candidate_id, mode: draft.mode,
        problems: [...draft.problems], direction: draft.direction, report: row.report || null,
        promptChoice: draft.promptChoice, selectedProductSha256: draft.selectedProductSha256,
      });
      if (outcome.kind === "ready") {
        draft.intent = outcome.intent;
        draft.blocked = null;
        const set = reworkDraftKey ? reworkControls.get(reworkDraftKey) : null;
        if (set) renderReworkChoice(set, draft);
        renderReworkPreviewBox(draft);
        elements.reworkStatus.hidden = false;
        elements.reworkStatus.textContent = "预览已就绪（" + outcome.intent.preview.sourceLabel + "）：确认并生成时会先把它保存为新版本，"
          + "再只提交这一张图；预览本身没有写入任何记录。";
      } else {
        draft.intent = null;
        draft.blocked = outcome;
        renderReworkPreviewBox(draft);
        const set = reworkDraftKey ? reworkControls.get(reworkDraftKey) : null;
        if (set) renderReworkChoice(set, draft);
        showError(elements.reworkError, outcome.message);
      }
    } catch (error) {
      draft.intent = null;
      draft.blocked = null;
      renderReworkPreviewBox(draft);
      showError(elements.reworkError, deps.suffixedErrorMessage(error, "预览没有生成，旧版本与输入保留。", "（预览未生成，旧版本与输入保留）"));
    } finally {
      reworkInFlight = false;
      const current = openDraftOf();
      if (current) syncReworkControls(current);
      reworkDraftsSignature = "";
      renderReworkDrafts(reworkDraftKey);
    }
  }

  /** 查看/编辑完整 Prompt 已收归确认路径：不再提供预览直落版的中间入口。 */
  async function editRework(): Promise<void> {
    const draft = openDraftOf();
    clearError(elements.reworkError);
    if (!draft || !draft.intent) {
      showError(elements.reworkError, "先预览返工 Prompt，再确认生成。");
      return;
    }
    showError(elements.reworkError, "返工全文只在确认生成时由 owner 落成新版本；人工全文请到 Prompt 列表显式编辑。");
  }

  /**
   * 确认并生成这张图：只把预览时 owner 给的意图原样交回确认。
   * 当前性、Prompt 落版、确认/预约/提交都在 owner 内部；视图不重算、不猜版本。
   * 成功/结果只更新状态：不改当前查看的候选，也不改左侧对照。
   */
  async function submitRework(): Promise<void> {
    const draft = openDraftOf();
    if (!deps.currentProjectId() || !draft || reworkInFlight) return;
    const action = deps.beginAction();
    clearError(elements.reworkError);
    if (!draft.intent) {
      showError(elements.reworkError, "先预览返工 Prompt，再确认生成。");
      return;
    }
    const shotId = draft.source.shot_id;
    if (!sourceStillExact(draft)) {
      draft.intent = null;
      renderReworkPreviewBox(draft);
      showError(elements.reworkError, "返工依据已经不在或已变化，先回到比较区重新选择候选；没有外发。");
      return;
    }
    const hadFocus = elements.reworkPanel.contains(document.activeElement);
    reworkInFlight = true;
    syncReworkControls(draft);
    try {
      const intent = draft.intent;
      const result = await generation.confirmRework({ intent });
      if (!action.alive()) return;
      if (result.kind === "stale") {
        // owner 已判过期且零外发：只呈现，不自动确认、不自动重提；旧意图作废。
        draft.intent = null;
        renderReworkPreviewBox(draft);
        showError(elements.reworkError, result.message || "返工意图已过期；请重新预览后再确认返工。");
        return;
      }
      if (result.kind === "blocked") {
        showError(elements.reworkError, result.message || "返工没有提交；旧候选与旧 Prompt 不受影响。");
        return;
      }
      const latestAttempt = generation.latestAttemptOf(shotId);
      const state = latestAttempt ? latestAttempt.record.state : null;
      draft.intent = null;
      draft.blocked = null;
      hideReworkPanelKeepingDrafts();
      deps.renderAttempts();
      deps.renderPrompts();
      deps.renderConfirm();
      await deps.deriveState();
      if (!action.alive()) return;
      if (hadFocus && compareShotId === shotId && compareCandidateId === draft.source.candidate_id
        && (document.activeElement === document.body
          || elements.reworkPanel.contains(document.activeElement))) {
        focusAfterReworkClose(shotId);
      }
      elements.compareStatus.textContent = "返工已提交（Prompt v" + (result.promptVersion || "?") + " · "
        + attemptStateLabel(state) + "）；旧候选保留，只有这张图新增了版本。";
      // 与生成区单张提交同一语义：unknown 成功返回也要如实提示定位（只增显示调用，不改控制流与返回）。
      if (state === ATTEMPT_STATES.unknown) {
        const noTaskId = !latestAttempt || !latestAttempt.record.task_id;
        deps.showAttemptError("这次返工提交的结果没有确认：不要重复提交。"
          + (noTaskId ? "没有任务编号，只能显式新建 action。" : "可以按任务编号核对。"));
      }
    } catch (error) {
      if (action.alive()) {
        showError(elements.reworkError,
          errorMessageOf(error, "返工没有提交；旧候选与旧 Prompt 不受影响。"));
      }
    } finally {
      if (action.alive()) {
        reworkInFlight = false;
        const current = openDraftOf();
        if (current) syncReworkControls(current);
      }
    }
  }

  /** 晚到刷新只同步状态：不改来源、不重建编辑控件、不动输入值/焦点/插入点。 */
  function syncReworkPanel(): void {
    const draft = openDraftOf();
    if (!draft || elements.reworkPanel.hidden) return;
    if (!sourceStillExact(draft)) {
      // 返工来源已经不在候选链里或字节漂移：如实说明，不换来源、不自动回退。
      draft.intent = null;
      renderReworkPreviewBox(draft);
      elements.reworkStatus.hidden = false;
      elements.reworkStatus.textContent = "这份草稿的返工对象已经不在了（或图片字节已变化）；不会自动换成别的候选，请重新选择候选后再返工。";
    }
    syncReworkControls(draft);
    renderReworkDrafts(reworkDraftKey);
    renderReworkMismatch();
  }

  /* ----------------------------------------------- 人工选择与失效（V2.6.1） */

  // 人工选择与采用：记录所有权在 selectionAdoption Module；这里只做视图装配
  // （状态徽标/入口按钮/就近原因）与动作转发，不直接读写记录或拼持久化顺序。
  function selectionEntryOf(shotId: string | null): SelectionEntry | null {
    return selectionAdoption.entryOf(shotId);
  }

  function selectionStateOf(shotId: string): SelectionState {
    return selectionAdoption.stateOf(shotId);
  }

  /** 某张图当前采用的候选（含过期标记）：只读投影，供候选选择器与决策行做徽标。 */
  function adoptedMarkOf(shotId: string | null): { candidate_id: string | null; state: SelectionState } | null {
    return selectionAdoption.adoptedMark(shotId);
  }

  function renderSelectionProgress(): void {
    if (!inputs.suitePlan()) {
      elements.adoptProgress.textContent = "";
      return;
    }
    const set = selectionAdoption.projection(inputs.sources()).set;
    elements.adoptProgress.textContent = set.summary.required_total > 0
      ? selectionSetText(set) + "采用只引用候选（candidate_id + sha256），不复制图片。"
      : "";
  }

  /** 决策行（采用旁的就近原因）：不以「按钮置灰」代替解释。 */
  function setDecisionReason(text: string, state: string): void {
    let node = decisionReasonNode;
    if (!node || !node.isConnected) {
      node = createElement("p", {
        className: "meta compare-decision-reason", attrs: { role: "status" },
      });
      const anchor = elements.adoptClear.parentElement || elements.comparePanel;
      anchor.insertBefore(node, elements.adoptClear.nextSibling);
      decisionReasonNode = node;
    }
    node.textContent = text;
    node.dataset.decisionState = state;
  }

  /** 精看入口与决策原因：只投影候选身份，不写任何记录（写记录在相邻的独立采用动作里）。 */
  function updateAdoptEntry(shot: { shot_id: string } | null, row: CompareRow | null): void {
    const available = Boolean(shot && row && row.record && row.record.asset_sha256);
    const selected = shot ? selectionAdoption.entryOf(shot.shot_id)?.record || null : null;
    const already = Boolean(selected && selected.action === "select" && row
      && selected.candidate_id === row.candidate_id
      && shot && selectionAdoption.stateOf(shot.shot_id) === "current");
    elements.adoptOpen.disabled = !available || already;
    elements.adoptClear.disabled = !selected || selected.action !== "select";
    let reason = "";
    let state = "ready";
    if (!shot) {
      reason = "还没有打开一张图。";
      state = "no_shot";
    } else if (!row) {
      reason = "这张图还没有可采用的候选；先在上面提交生成并保存候选。";
      state = "no_candidate";
    } else if (!row.record || !row.record.asset_sha256) {
      reason = "这条候选缺少图片字节，暂不能采用；不会用别的图片替代。";
      state = "missing_bytes";
    } else if (already) {
      reason = "已经采用的是这条候选（重复采用被挡住）；换用其他候选请先在候选选择器里切过去。";
      state = "adopted";
    } else {
      const reportFailure = selectionAdoption.reportBuildFailure(row.candidate_id);
      if (reportFailure) {
        reason = "自动检查报告补建失败：" + reportFailure
          + "（候选与本地图片保留；重新打开或再次采用会补建，不需要 AI）";
        state = "report_failed";
      } else if (shot && selectionAdoption.stateOf(shot.shot_id) === "stale"
        && selected && selected.action === "select") {
        reason = "这张图当前采用的另一条候选已过期；采用这条会更新采用记录，旧记录仍保留在历史里。";
        state = "stale_other";
      } else {
        reason = "可以采用这条候选（查看不等于采用；采用只引用候选身份与 sha256）。";
        state = "ready";
      }
    }
    elements.adoptOpen.title = reason;
    elements.adoptClear.title = elements.adoptClear.disabled
      ? "这张图当前没有采用记录，没有可取消的采用。" : "取消这张图的采用（历史记录保留）。";
    setDecisionReason(reason, state);
  }

  /** 返工入口的状态：只有「正看着一条有字节的候选」才可发起。 */
  function updateReworkEntry(shot: { shot_id: string } | null, row: CompareRow | null): void {
    const candidate = row && row.record ? row.record : null;
    const sha256 = row ? row.asset_sha256 : null;
    const available = Boolean(shot && candidate && sha256);
    elements.reworkOpen.disabled = !available;
    if (available && shot && row && candidate && sha256) {
      elements.reworkOpen.dataset.shotId = shot.shot_id;
      elements.reworkOpen.dataset.candidateId = row.candidate_id;
      elements.reworkOpen.dataset.candidateSha256 = sha256;
      elements.reworkOpen.title = "对当前查看的候选发起返工（默认编辑候选；可另选原照重生成）。";
    } else {
      delete elements.reworkOpen.dataset.shotId;
      delete elements.reworkOpen.dataset.candidateId;
      delete elements.reworkOpen.dataset.candidateSha256;
      elements.reworkOpen.title = "先选定一条有图片字节的候选，再返工这张图。";
    }
  }

  /** 采用目标：把「正看着的候选」解析成候选记录 + 文档版本 + 当前审核报告。 */
  function adoptSourceOf(shotId: string | null, candidateId: string | null): AdoptionSource | null {
    return selectionAdoption.sourceOf(shotId, candidateId);
  }

  function selectionTextOf(shotId: string): string {
    return selectionAdoption.summary(shotId);
  }

  /** One explicit human action. Identity freezes before any byte read; selection is append-only/OCC. */
  async function adoptCandidate(kind: "select" | "clear", shotId: string | null = compareShotId,
    candidateId: string | null = compareCandidateId): Promise<void> {
    if (!deps.currentProjectId() || !shotId || selectionAdoption.isSelecting()) return;
    const action = deps.beginAction();
    clearError(elements.adoptError);
    elements.adoptStatus.hidden = false;
    elements.adoptStatus.textContent = "正在保存 " + deps.shotLabelOf(shotId) + " 的人工选择…";
    try {
      await selectionAdoption.select(kind, shotId, candidateId);
      if (!action.alive()) return;
      elements.adoptStatus.textContent = deps.shotLabelOf(shotId)
        + (kind === "select" ? " 已采用候选" : " 已取消采用")
        + "；旧候选和旧采用保留在历史中。确定性硬阻断仍会阻止交付。";
    } catch (error) {
      if (!action.alive()) return;
      elements.adoptStatus.textContent = "人工选择没有保存；原采用保留。";
      showError(elements.adoptError, errorMessageOf(error, "存储失败，请重试。"));
    } finally {
      // 采用后立即重画精看与任务列表：选中态/已采用徽标与采用按钮都来自重画，
      // 走查里“等待 current”才有稳定的可观测终态；只读投影，不写库不发请求。
      // 这里不改当前查看的候选（采用不改变正在看的对象）。
      if (action.alive()) {
        deps.renderAttempts();
        renderCompare();
      }
    }
  }

  /** 重开项目时的就地状态归零：与原 loadWorkspace 重置项一一对应（草稿不跨项目保留）。 */
  function resetViewState(): void {
    compareShotId = null;
    compareCandidateId = null;
    compareBaselineId = null;
    compareToken += 1;
    compareImageToken += 1;
    reworkDrafts = new Map();
    reworkControls = new Map();
    reworkOpenByShot = new Map();
    reworkDraftsSignature = "";
    reworkInFlight = false;
    reworkDraftKey = null;
    elements.comparePanel.hidden = true;
    elements.reworkPanel.hidden = true;
    elements.reworkPreviewBox.hidden = true;
    elements.reworkDrafts.hidden = true;
    elements.reworkDrafts.textContent = "";
    if (reworkMismatchNode) {
      reworkMismatchNode.hidden = true;
      reworkMismatchNode.textContent = "";
    }
  }

  return {
    renderCompare,
    renderSelectionProgress,
    openCompare,
    handleCandidateChange,
    isComparing,
    currentShotId,
    hasUnsavedDrafts: () => {
      for (const draft of reworkDrafts.values()) if (draftHasContent(draft)) return true;
      return false;
    },
    handleBaselineChange,
    handleCompareReview,
    zoomViewed,
    zoomBaseline,
    closeImageZoom,
    toggleZoomNative,
    openReworkPanel,
    previewRework,
    editRework,
    submitRework,
    resetRework,
    cancelRework,
    handleReworkKeydown,
    handleReworkDirectionInput,
    adoptCandidate,
    selectionEntryOf,
    selectionStateOf,
    adoptedMarkOf,
    adoptSourceOf,
    selectionTextOf,
    resetViewState,
  };
}
