// Generated from app/product_v2/ui/generation-view.ts; edit the TS source and run `npm run build:frontend`.
/**
 * 生成视图（设计 §10.1 的第二个视图）：Prompt 准备/编译与人工编辑、生成前确认单、
 * 尝试与批次三区的渲染与命令。
 *
 * 边界（设计 §10.1）：这里只持 DOM（不做第二次 getElementById 分发，句柄由工作区装配
 * 一次传入）；不写库、不发网络、不重算业务判定。Prompt 版本/依据的唯一所有者是
 * prompts，确认队列/scope/mode 与尝试/候选链的唯一所有者是 generation；落库/派生/
 * 跨视图刷新都经 deps 回到工作区。确认单投影归 prompts，当前性/环境匹配的唯一判据
 * 在 generation，这里只转发，不重建规则。
 *
 * TypeScript 迁移（计划 §9 V2.R7.5）：本文件是唯一手工维护实现；同名 `generation-view.js`
 * 由 `npm run build:frontend` 生成，浏览器只消费生成的 `.js`。
 */
import { ATTEMPT_ACTIVE_STATES, ATTEMPT_RECONCILE_MODES, ATTEMPT_STATES, MANUAL_EDIT_REASON_MAX, SELECTION_STATE_TEXT, attemptCurrentEnvironmentIdentity, attemptPromptStaleness, attemptReconcileBlockedMessage, attemptReconcileEnvironment, attemptReconcileMode, attemptStateLabel, batchProgressText, candidateMatchesAttempt, promptStaleness, reviewSummaryText, selectionSummaryText, suitePlanSummary, } from "../domain/index.js";
import { ROLE_TEXT, clearError, createElement, errorMessageOf, showError, techDetails, } from "./dom.js";
/**
 * 生成视图工厂。
 * @param args.elements 本视图负责的 DOM 句柄
 * @param args.deps 窄依赖：业务所有者命令/投影 + 工作区收尾回调
 */
export function createGenerationView({ elements, deps }) {
    // 依赖别名：搬过来的实现保持原调用写法，装配面只经上面的窄接口进出。
    const inputs = deps.inputs;
    const prompts = deps.prompts;
    const generation = deps.generation;
    const modelSettings = deps.modelSettings;
    const selectionAdoption = deps.selectionAdoption;
    const beginAction = deps.beginAction;
    const localizeSlotTerms = deps.localizeSlotTerms;
    const suiteBlockingText = deps.suiteBlockingText;
    const suffixedErrorMessage = deps.suffixedErrorMessage;
    /** 确认提交在飞（同页双击闸）：视图持有的表现态，不是业务状态。 */
    let submissionInFlight = false;
    /** 本轮确认单呈现给用户的意图；提交时消费「用户看见的那份」，不重算当前最新。 */
    let displayedGenerationIntent = null;
    // 以编辑框呈现时的系统原文判定人工修改，不能拿更新后的 Prompt 与旧 DOM 比较。
    const promptEditorBaselines = new WeakMap();
    /**
     * 用户显式选择的待发送范围——`generation.prepareSummary({ scope })` 的入参。
     * `null` = 尚未显式勾选，用 owner 当前的默认队列。左列表勾选框、窄屏勾选与
     * 「实际发送摘要」读写的都是这一份（视图持有的输入，不是第二套选择模型）；
     * 业务判定、队列与授权仍在 generation，视图不重算范围。
     */
    let explicitSendScope = null;
    /** 逐图列表的稳定节点（按 shot_id 键控）：异步渲染只更新字段，不重建行、不抢焦点/勾选。 */
    const taskRows = new Map();
    /** 当前图的动作块（宿主见 ensureCurrentActionsHost）：同一张图内就地更新，换图才重建。 */
    let currentActions = null;
    let currentActionsHost = null;
    /** 窄屏选择器的选项集合签名与「首次自动选图」签名：两者都只在计划集合变化时才动 DOM。 */
    let mobileOptionSignature = null;
    let autoOpenSignature = null;
    // 一次性装配：窄屏控件是原生元素，change 只走各自 owner 命令，不互相牵连。
    elements.workbenchShotSelect.addEventListener("change", () => {
        const shotId = elements.workbenchShotSelect.value;
        // 原生 change 打开精确那张图；不发请求、不采用。换图后工作区回调一次 renderAttempts。
        if (shotId)
            deps.openCompare(shotId, { focus: false });
    });
    elements.workbenchSendCurrent.addEventListener("change", () => {
        const shotId = deps.currentShotId();
        if (!shotId) {
            elements.workbenchSendCurrent.checked = false;
            return;
        }
        toggleSendScope(shotId, elements.workbenchSendCurrent.checked);
    });
    /* --------------------------------------------------------- Prompt 编译 */
    function promptRecordOf(shotId) {
        return prompts.entryOf(shotId, null);
    }
    function currentImageProfile() {
        return prompts.profile(deps.capabilities()?.images);
    }
    function promptCurrentBasis(shotId, provider = currentImageProfile()) {
        // prompts Module 的 basis 缺省来源就是工作区的 projectSources（装配时已注入），
        // 这里不再经工作区转一手，读到的是同一份只读投影。
        return prompts.basis(shotId, provider);
    }
    /** 未保存的编辑草稿：重渲染时保留用户输入，不让界面动作吞掉正在写的文本。 */
    function capturePromptEdits() {
        const drafts = new Map();
        const areas = elements.promptList.querySelectorAll("textarea.prompt-edit-text");
        for (const area of areas) {
            const shotId = area.getAttribute("data-shot-id");
            const baseline = promptEditorBaselines.get(area);
            if (baseline === undefined || area.value === baseline)
                continue;
            const reason = area.parentElement
                ? area.parentElement.querySelector("input.prompt-edit-reason")
                : null;
            if (shotId)
                drafts.set(shotId, { text: area.value, reason: reason ? reason.value : "" });
        }
        return drafts;
    }
    function renderPrompts() {
        const drafts = capturePromptEdits();
        const ready = Boolean(inputs.suitePlan());
        elements.promptLocked.hidden = ready;
        elements.promptEditor.hidden = !ready;
        elements.promptList.innerHTML = "";
        if (!ready)
            return;
        const summary = suitePlanSummary(inputs.suitePlan(), inputs.suiteContext());
        elements.promptStatus.textContent = summary
            ? "共 " + summary.total + " 张，依据已满足 " + summary.satisfiable + " 张可编译。"
            : "";
        if (!summary)
            return;
        summary.shots.forEach((item, index) => {
            // 已保存计划恒有 shot_id；null 仅存在于未落库草稿，跳过即可。
            const shotId = item.shot_id;
            if (typeof shotId !== "string")
                return;
            const entry = promptRecordOf(shotId);
            const stale = entry ? promptStaleness(entry.record, promptCurrentBasis(shotId)) : null;
            const card = createElement("div", {
                className: "shot-spec",
                attrs: {
                    "data-shot-id": shotId,
                    "data-prompt-state": entry ? (stale && stale.stale ? "stale" : "saved") : "none",
                },
            });
            const head = createElement("div", { className: "shot-spec-head" });
            head.append(createElement("span", { className: "name", text: (index + 1) + ". " + item.label }));
            head.append(createElement("span", {
                className: "meta", text: entry ? "版本 v" + entry.version : "未编译",
            }));
            head.append(createElement("span", {
                className: item.satisfied ? "badge" : "badge is-critical",
                text: item.satisfied ? "可编译" : "缺依据",
            }));
            if (stale && stale.stale) {
                head.append(createElement("span", { className: "badge is-critical", text: "已过期" }));
            }
            if (entry && entry.record.origin === "manual_edit") {
                head.append(createElement("span", { className: "badge is-proposed", text: "人工编辑" }));
            }
            card.append(head);
            if (entry) {
                card.append(createElement("pre", {
                    className: "prompt-text", text: entry.record.compiled.text,
                    attrs: { tabindex: "0", role: "region", "aria-label": item.label + "：完整发送 Prompt" },
                }));
                const refs = entry.record.compiled.source_refs || [];
                const provider = entry.record.compiled.provider || {};
                card.append(createElement("p", {
                    className: "meta",
                    text: "请求：" + (provider.model_id || "?") + " · " + (provider.size || "?")
                        + " · 参考图 " + (entry.record.request_snapshot.references || []).length + " 张",
                }));
                card.append(createElement("p", {
                    className: "meta prompt-meta",
                    text: "来源 " + refs.length + " 条 · " + entry.record.compiled.text.length
                        + " 字 · hash " + entry.record.hash.slice(0, 12) + "…",
                }));
                card.append(createElement("p", { className: "meta prompt-hash", text: entry.record.hash }));
                for (const warning of entry.record.compiled.warnings || []) {
                    card.append(createElement("p", {
                        className: "meta prompt-warning",
                        text: "提示：" + localizeSlotTerms(warning.message),
                    }));
                }
                if (entry.record.origin === "manual_edit") {
                    card.append(createElement("p", {
                        className: "meta",
                        text: "人工编辑 v" + entry.version + "（原因：" + entry.record.edit_reason + "；被编辑版本 v"
                            + (entry.record.edited_from ? entry.record.edited_from.version : "?") + " 保留）",
                    }));
                }
                if (stale && stale.stale) {
                    card.append(createElement("p", {
                        className: "meta prompt-warning",
                        text: "依据已变化（" + stale.reasons.map((reason) => reason.field).join("、") + "）。"
                            + (entry.record.origin === "manual_edit"
                                ? "人工全文没有被覆盖；请按当前依据重新确认，或明确丢弃后重新准备。"
                                : "系统会本地重新准备，不调用模型。"),
                    }));
                }
            }
            else if (!item.satisfied) {
                card.append(createElement("p", {
                    className: "meta", text: "暂时缺依据：" + suiteBlockingText(item.blocking),
                }));
            }
            const toolbar = createElement("div", { className: "toolbar" });
            const compileButton = createElement("button", {
                text: entry?.record.origin === "manual_edit" ? "丢弃人工全文并重新准备" : "重新本地准备",
                className: entry?.record.origin === "manual_edit" ? "danger" : "", attrs: { type: "button" },
            });
            compileButton.disabled = !item.satisfied || inputs.isAnalysisRunning();
            compileButton.addEventListener("click", () => {
                if (entry?.record.origin === "manual_edit")
                    void handleDiscardManualPrompt(shotId);
                else
                    void handleCompilePrompt(shotId);
            });
            toolbar.append(compileButton);
            let reconfirmButton = null;
            if (entry?.record.origin === "manual_edit" && stale?.stale) {
                reconfirmButton = createElement("button", {
                    text: "按当前依据确认此人工全文", attrs: { type: "button" },
                });
                reconfirmButton.disabled = !item.satisfied || inputs.isAnalysisRunning();
                reconfirmButton.addEventListener("click", () => { void handleReconfirmManualPrompt(shotId); });
                toolbar.append(reconfirmButton);
            }
            card.append(toolbar);
            if (entry) {
                const draft = drafts.get(shotId) || null;
                const unsaved = draft !== null && draft.text !== entry.record.compiled.text;
                const block = createElement("div", { className: "prompt-edit-block" });
                block.append(createElement("label", {
                    className: "meta",
                    attrs: { for: "prompt-edit-" + shotId },
                    text: "人工编辑全文（保存为新版本；原版本保留）",
                }));
                const area = createElement("textarea", {
                    className: "prompt-edit-text",
                    attrs: { id: "prompt-edit-" + shotId, "data-shot-id": shotId, rows: "6" },
                });
                area.value = draft && unsaved ? draft.text : entry.record.compiled.text;
                promptEditorBaselines.set(area, entry.record.compiled.text);
                block.append(area);
                area.addEventListener("input", () => {
                    if (reconfirmButton)
                        reconfirmButton.disabled = !item.satisfied || inputs.isAnalysisRunning() || area.value !== entry.record.compiled.text;
                });
                block.append(createElement("label", {
                    className: "meta",
                    attrs: { for: "prompt-edit-reason-" + shotId },
                    text: "编辑原因（必填，写入版本记录）",
                }));
                const reason = createElement("input", {
                    className: "prompt-edit-reason",
                    attrs: {
                        id: "prompt-edit-reason-" + shotId, type: "text", autocomplete: "off",
                        maxlength: String(MANUAL_EDIT_REASON_MAX),
                    },
                });
                if (draft && unsaved && draft.reason)
                    reason.value = draft.reason;
                block.append(reason);
                const saveEdit = createElement("button", { text: "保存为新版本", attrs: { type: "button" } });
                saveEdit.disabled = inputs.isAnalysisRunning();
                saveEdit.addEventListener("click", () => { handleSaveEditedPrompt(shotId); });
                block.append(saveEdit);
                card.append(block);
            }
            elements.promptList.append(card);
        });
    }
    /** 本地准备是 prompts Module 的动作；这里只传 DOM 草稿并呈现结果文案。 */
    async function prepareSystemPrompts() {
        if (!deps.currentProjectId() || prompts.isPreparing())
            return;
        const action = beginAction();
        if (!action.projectId)
            return;
        const gate = !inputs.suitePlan()
            ? "先添加图片任务；本地准备不会调用模型。"
            : (!deps.understandingReady() ? "请人工确认核心事实；各图片用途的额外缺项就地补足。"
                : (!currentImageProfile() ? "等待有效图像配置；打开模型设置可恢复。" : null));
        if (gate) {
            elements.localPreparationStatus.textContent = gate;
            return;
        }
        elements.localPreparationStatus.textContent = "正在本地准备已就绪图片任务；不会调用模型…";
        renderConfirm();
        try {
            const result = await prompts.prepare(capturePromptEdits());
            if (!action.alive())
                return;
            if (result.reason === "no_plan" || result.reason === "facts" || result.reason === "configuration") {
                elements.localPreparationStatus.textContent = result.reason === "no_plan"
                    ? "先添加图片任务；本地准备不会调用模型。"
                    : result.reason === "facts" ? "请人工确认核心事实；各图片用途的额外缺项就地补足。"
                        : "等待有效图像配置；打开模型设置可恢复。";
                return;
            }
            if (result.reason === "in_flight" || result.reason === "stale_session"
                || result.reason === "no_project")
                return;
            elements.localPreparationStatus.textContent = result.errors.length
                ? "部分任务尚未准备：" + result.errors.join("；")
                : "本地准备完成" + (result.prepared ? "（更新 " + result.prepared + " 张）" : "")
                    + "；未调用模型。人工文本保留，提交前请核对下面的摘要。";
            await deps.deriveState();
        }
        finally {
            if (action.alive()) {
                renderPrompts();
                renderConfirm();
                renderAttempts();
            }
        }
    }
    async function handleReconfirmManualPrompt(shotId) {
        const entry = promptRecordOf(shotId);
        if (!entry || entry.record.origin !== "manual_edit")
            return;
        const action = beginAction();
        const area = elements.promptList.querySelector('textarea.prompt-edit-text[data-shot-id="' + shotId + '"]');
        if (area && area.value !== entry.record.compiled.text) {
            showError(elements.promptError, "此全文有未保存修改；先保存，再重新确认，不会确认另一份旧文本。");
            return;
        }
        clearError(elements.promptError);
        try {
            const saved = await prompts.reconfirm(shotId, area ? area.value : null, action);
            if (!saved)
                return;
            if (!action.alive())
                return;
            renderPrompts();
            renderConfirm();
            renderAttempts();
            elements.promptStatus.textContent = "人工全文原文保留，已按当前依据重新确认为 v" + saved.version + "；未调用模型。";
        }
        catch (error) {
            if (action.alive())
                showError(elements.promptError, errorMessageOf(error, "重新确认失败；原人工全文保留。"));
        }
    }
    async function handleDiscardManualPrompt(shotId) {
        const entry = promptRecordOf(shotId);
        if (!entry || entry.record.origin !== "manual_edit")
            return;
        const action = beginAction();
        const area = elements.promptList.querySelector('textarea.prompt-edit-text[data-shot-id="' + shotId + '"]');
        const previousDraft = area?.value;
        clearError(elements.promptError);
        try {
            const payload = await prompts.discard(shotId, action);
            if (!action.alive() || !payload)
                return;
            if (area && area.value === previousDraft)
                area.value = payload.compiled.text;
            renderPrompts();
            renderConfirm();
            renderAttempts();
            elements.promptStatus.textContent = "已明确丢弃人工覆盖并恢复当前系统 Prompt；历史全文保留，未调用模型。";
        }
        catch (error) {
            if (action.alive())
                showError(elements.promptError, errorMessageOf(error, "丢弃未完成；原全文与输入保留。"));
        }
    }
    async function handleCompilePrompt(shotId) {
        if (!deps.currentProjectId() || !inputs.suitePlan() || !deps.understandingReady())
            return;
        const action = beginAction();
        clearError(elements.promptError);
        try {
            const result = await prompts.compileAndSave(shotId, { action });
            if (!action.alive())
                return;
            renderPrompts();
            renderConfirm();
            renderAttempts();
            await deps.deriveState();
            if (!action.alive())
                return;
            elements.promptStatus.textContent = "已保存 " + shotId + " 的 Prompt 版本 v"
                + result.saved.version + "。";
        }
        catch (error) {
            if (!action.alive())
                return;
            showError(elements.promptError, suffixedErrorMessage(error, "编译未完成，旧版本已保留。", "（旧版本已保留）"));
            renderPrompts();
            renderConfirm();
            renderAttempts();
        }
    }
    /** 人工编辑：保存为新版本；失败时保留旧版本与用户输入，不清空文本区。 */
    async function handleSaveEditedPrompt(shotId) {
        if (!deps.currentProjectId() || !inputs.suitePlan() || !deps.understandingReady())
            return;
        const action = beginAction();
        clearError(elements.promptError);
        const entry = promptRecordOf(shotId);
        if (!entry) {
            showError(elements.promptError, "先编译并保存这张图的 Prompt，再编辑。");
            return;
        }
        const area = document.getElementById("prompt-edit-" + shotId);
        const reasonInput = document.getElementById("prompt-edit-reason-" + shotId);
        try {
            const saved = await prompts.edit(shotId, area ? area.value : "", reasonInput ? reasonInput.value : "", action);
            if (!action.alive())
                return;
            renderPrompts();
            renderConfirm();
            renderAttempts();
            await deps.deriveState();
            if (!action.alive())
                return;
            elements.promptStatus.textContent = "已保存 " + shotId + " 的人工编辑版本 v" + saved.version
                + "（被编辑版本 v" + entry.version + " 保留）。";
        }
        catch (error) {
            if (action.alive()) {
                showError(elements.promptError, suffixedErrorMessage(error, "编辑未保存，旧版本与输入已保留。", "（旧版本与输入已保留）"));
            }
        }
    }
    /* ---------------------------------------------------------- 生成前确认 */
    /** 单图当前性：转发 generation.isConfirmedShotCurrent（执行与按钮同一判据）。 */
    function queueShotIsCurrent(queue, shotId) {
        return generation.isConfirmedShotCurrent(queue, shotId);
    }
    /** 确认记录是否仍然对得上「这一批将要提交的东西」（owner 只读投影）。 */
    function confirmationIsCurrent() {
        return generation.hasCurrent();
    }
    /** 提交这张图的条件：这张图在某个现存授权队列里仍有效（generation 统一判据）。 */
    function confirmationIsCurrentForShot(shotId) {
        if (!shotId)
            return false;
        return generation.shotHasCurrent(shotId);
    }
    function renderConfirm() {
        const ready = Boolean(inputs.suitePlan());
        elements.confirmLocked.hidden = ready;
        elements.confirmEditor.hidden = !ready;
        elements.confirmSummary.innerHTML = "";
        elements.confirmBlockers.innerHTML = "";
        elements.confirmRisks.innerHTML = "";
        elements.confirmList.innerHTML = "";
        elements.confirmRecord.textContent = "";
        elements.confirmAction.disabled = true;
        displayedGenerationIntent = null;
        if (!ready)
            return;
        // 显式勾选的范围里已经没有现存图片（换项目/方案删图）：丢弃这份输入，回到 owner 默认队列。
        if (explicitSendScope !== null) {
            const planSummary = suitePlanSummary(inputs.suitePlan(), inputs.suiteContext());
            const planIds = new Set((planSummary ? planSummary.shots : []).map((item) => item.shot_id));
            if (explicitSendScope.some((shotId) => !planIds.has(shotId)))
                explicitSendScope = null;
        }
        if (explicitSendScope !== null && explicitSendScope.length === 0) {
            // 空集不能交给 owner（空 scope 会被当作「未指定」回落成整套）：这里如实呈现 0 张。
            displayedGenerationIntent = null;
            elements.confirmStatus.textContent = "尚未选择任何待发送图片：在逐图列表里勾选要发送的图，再核对摘要。";
            elements.confirmAction.disabled = true;
            elements.confirmAction.textContent = "确认并生成 0 张";
            elements.confirmRecord.textContent = "至少勾选一张已就绪图片才能确认外发；查看、对照与采用不受影响。";
            return;
        }
        let sheet = null;
        try {
            // 所见摘要由 generation 准备：视图只保存并原样交回，不重算、不猜版本。
            // 用户显式勾选的范围就是 prepareSummary 的 scope；未勾选时用 owner 当前默认队列。
            displayedGenerationIntent = generation.prepareSummary(explicitSendScope !== null ? { scope: explicitSendScope } : {});
            // owner 进入失败重试/显式另发等模式时队列由 owner 选定：用户范围不覆盖它，这里丢弃显式范围。
            if (displayedGenerationIntent && explicitSendScope !== null
                && displayedGenerationIntent.mode !== "initial") {
                explicitSendScope = null;
                displayedGenerationIntent = generation.prepareSummary();
            }
            sheet = displayedGenerationIntent ? displayedGenerationIntent.all : null;
        }
        catch (error) {
            showError(elements.confirmError, "生成前确认投影失败：" + errorMessageOf(error, "未知错误"));
            return;
        }
        if (!sheet || !displayedGenerationIntent) {
            elements.confirmStatus.textContent = "尚未取得有效图像能力；恢复服务后再确认，不会提交未经核对的请求。";
            return;
        }
        const intent = displayedGenerationIntent;
        const sending = intent.sheet;
        const sendingIds = new Set(sending?.shots.map((item) => item.shot_id) || []);
        elements.confirmStatus.textContent = "本次明确发送 " + (sending?.total || 0) + " 张；"
            + "用途缺项／过期任务不外发；已有成功、进行中或 Unknown 不自动重提。";
        elements.confirmSummary.append(createElement("p", {
            className: "confirm-summary", text: sending ? sending.external_summary.statement : "当前没有可新增发送的已就绪图片任务。",
        }));
        const costQuote = sending?.external_summary.cost_quote;
        if (costQuote) {
            elements.confirmSummary.append(createElement("p", {
                className: "confirm-summary",
                attrs: { "data-cost-upper-bound-fen": String(costQuote.upper_bound_fen) },
                text: costQuote.test_double
                    ? "离线替身演练：不产生模型费用；以下计费数量仅用于核对本次范围。"
                    : "本次模型费用上界 ¥" + (costQuote.upper_bound_fen / 100).toFixed(2)
                        + "；按实际发送的 " + costQuote.input_images + " 张参考图、" + costQuote.output_images + " 张输出计。",
            }));
            if (costQuote.source_url) {
                elements.confirmSummary.append(createElement("a", {
                    className: "meta", text: "官方价格依据（核对于 " + costQuote.verified_at + "）",
                    attrs: { href: costQuote.source_url, target: "_blank", rel: "noopener noreferrer" },
                }));
            }
        }
        else if (sending) {
            elements.confirmSummary.append(createElement("p", {
                className: "confirm-blocker", text: "费用上界尚未核实，不能确认发送。请检查图像模型配置与官方计费信息。",
            }));
        }
        const costsByShot = new Map(costQuote?.shots.map((item) => [item.shot_id, item]) || []);
        if (intent.mode === "explicit_new") {
            elements.confirmSummary.append(createElement("p", {
                className: "prompt-warning",
                text: "这是另一个新动作，不是核对原任务。原 Unknown 可能已经被受理，另发可能重复扣费；原记录与采用不删除、不覆盖。",
            }));
        }
        elements.confirmSummary.append(createElement("p", {
            className: "meta",
            text: "只发送本次摘要列出的 Prompt 与参考图。候选编辑会发送明确选定的问题候选作为模型源；从原照重生成只发送商品依据。不发送其他历史或其他项目数据。",
        }));
        if (intent.exclusions.length > 0) {
            elements.confirmSummary.append(createElement("p", {
                className: "meta",
                text: "本次不发送：" + intent.exclusions.map((item) => item.shot_id + "（" + (item.reason === "not_in_plan" ? "不在当前方案" : "有阻断/已过期") + "）").join("；"),
            }));
        }
        for (const blocker of sheet.blockers) {
            const row = createElement("p", { className: "confirm-blocker" });
            row.append(createElement("span", { text: "#" + blocker.order + " " + blocker.label + " · " + blocker.code }));
            row.append(createElement("span", { className: "meta", text: localizeSlotTerms(blocker.message) }));
            row.append(createElement("span", {
                className: "meta", text: "返回：" + blocker.fix.region + " · " + blocker.fix.action,
            }));
            const fix = createElement("button", { text: "去补足此项", attrs: { type: "button" } });
            fix.addEventListener("click", () => {
                if (blocker.fix.region === "model_settings") {
                    modelSettings.open("image");
                    return;
                }
                const task = { intake: "intake", understanding: "intake", suite: "plan",
                    style: "generate", shot_spec: "generate", prompt: "generate" }[blocker.fix.region];
                deps.selectStage(task);
                if (blocker.fix.region === "prompt") {
                    document.getElementById("prompt-details").open = true;
                }
            });
            row.append(fix);
            elements.confirmBlockers.append(row);
        }
        for (const risk of sheet.risks) {
            elements.confirmRisks.append(createElement("p", {
                className: "confirm-risk",
                text: risk.label + " · " + risk.code + "：" + localizeSlotTerms(risk.message),
            }));
        }
        for (const item of sheet.shots) {
            const row = createElement("div", {
                className: "confirm-shot",
                attrs: { "data-shot-id": item.shot_id, "data-blocked": String(item.blockers.length > 0) },
            });
            const head = createElement("div", { className: "confirm-shot-head" });
            head.append(createElement("span", { className: "name", text: item.order + ". " + item.label }));
            head.append(createElement("span", {
                className: "badge",
                text: (item.role_label || item.role_id || "未分类") + (item.required ? " · 必需" : " · 可选"),
            }));
            head.append(createElement("span", {
                className: item.blockers.length > 0 ? "badge is-critical" : "badge is-confirmed",
                text: sendingIds.has(item.shot_id) ? "本次发送" : item.blockers.length ? "本次不发送：缺项／过期" : "本次不重复提交",
            }));
            head.append(createElement("span", {
                className: "meta",
                text: item.prompt.version === null
                    ? "未编译"
                    : "Prompt v" + item.prompt.version + " · " + String(item.prompt.hash).slice(0, 12) + "…",
            }));
            row.append(head);
            if (item.intent)
                row.append(createElement("p", { className: "meta", text: "任务：" + item.intent }));
            row.append(createElement("p", {
                className: "meta",
                text: "参考图 " + item.references.length + " 张（"
                    + (item.references.map((ref) => ROLE_TEXT[ref.role] || ref.role).join("、") || "无") + "）"
                    + (item.prompt.chars === null ? "" : " · 提示词 " + item.prompt.chars + " 字"),
            }));
            const shotCost = costsByShot.get(item.shot_id);
            if (shotCost && !costQuote?.test_double)
                row.append(createElement("p", {
                    className: "meta",
                    text: "本次计费上界 ¥" + (shotCost.upper_bound_fen / 100).toFixed(2)
                        + "（" + shotCost.input_images + " 张输入参考图、" + shotCost.output_images + " 张输出）",
                }));
            const referenceTech = techDetails(item.references.map((ref) => (ROLE_TEXT[ref.role] || ref.role) + " sha256 " + ref.sha256_prefix));
            if (referenceTech)
                row.append(referenceTech);
            if (item.risks.length > 0) {
                row.append(createElement("p", {
                    className: "meta prompt-warning",
                    attrs: { title: item.risks.map((risk) => risk.code).join("、") },
                    text: "风险：" + item.risks
                        .map((risk) => localizeSlotTerms(risk.message || risk.code)).join("；"),
                }));
            }
            elements.confirmList.append(row);
        }
        const identity = intent.identity;
        elements.confirmAction.disabled = !sending?.can_submit || !identity?.configured || inputs.isAnalysisRunning()
            || prompts.isPreparing() || submissionInFlight || modelSettings.refreshing
            || Boolean(generation.batchStateReader()?.active);
        elements.confirmAction.textContent = (intent.mode === "explicit_new" ? "确认并另发 " : "确认并生成 ")
            + (sending?.total || 0) + " 张";
        elements.confirmRecord.textContent = identity?.configured
            ? "一次点击先保存这份授权，再按摘要外发；不会要求第二次提交。"
            : "原目标凭据未就绪。打开模型设置补凭据；本地事实、Prompt、采用和导出不受影响。";
    }
    async function handleConfirmGeneration() {
        if (!deps.currentProjectId() || !inputs.suitePlan() || submissionInFlight
            || prompts.isPreparing() || modelSettings.refreshing)
            return;
        const authorized = displayedGenerationIntent;
        if (!authorized)
            return;
        const action = beginAction();
        submissionInFlight = true;
        elements.confirmAction.disabled = true;
        clearError(elements.confirmError);
        try {
            // 只交出用户看过的那份摘要：授权文档/所见版本/当前性核对都在 owner 内部完成。
            const result = await generation.confirmAndRun({ intent: authorized });
            // stale：owner 已算出新摘要并零外发；把新摘要直接读给用户，避免"只说过期、不知道变成什么"。
            // 不自动确认、不自动重提；下面 finally 的 renderConfirm 会按 owner 当前投影重新呈现。
            if (result.kind === "stale" && action.alive()) {
                const fresh = result.intent?.sheet?.external_summary?.statement || "";
                showError(elements.confirmError, (result.message || "摘要已变化；请核对新摘要后再确认。") + (fresh ? "当前摘要：" + fresh : ""));
            }
            else if (result.kind === "blocked" && action.alive()) {
                showError(elements.confirmError, result.message || "这次确认没有外发；请核对当前状态后再试。");
            }
        }
        catch (error) {
            if (action.alive())
                showError(elements.confirmError, errorMessageOf(error, "生成没有完成；授权与历史保留。"));
        }
        finally {
            submissionInFlight = false;
            // 确认写库后派生项目状态（PLAN_REVIEW → READY_TO_GENERATE）：与编译保存同一语义，
            // 否则确认存在但状态不前进，-05 类“确认存在且状态前进”断言永远红。
            try {
                if (action.alive())
                    await deps.deriveState();
            }
            catch { /* 状态派生失败不吞确认结果 */ }
            if (action.alive()) {
                renderConfirm();
                renderAttempts();
            }
        }
    }
    /* ------------------------------------------------------------ 生成执行 */
    /** 尝试状态行：命令结果就近写入的唯一实现；owner 旁路文案也经 applyNotice 落到这里。 */
    function setAttemptStatus(text) {
        elements.attemptStatus.textContent = text;
    }
    /** 上一份已应用的 owner 错误文本：只在 owner 从"有错误"变回"无错误"时同步清 DOM。 */
    let appliedOwnerError = "";
    /**
     * owner 投影变化的应用（订阅 generation 后由工作区调用）：先按只读投影重渲染尝试/候选行
     * 与批次进度（含跨区刷新），再写 owner 的旁路文案——顺序与旧回调一致（render 后 status），
     * 否则状态行会被计数摘要盖掉。忙碌/进度仍只读飞行标识与批次投影，不解读业务状态。
     */
    function applyNotice() {
        renderAttempts();
        const notice = generation.notice();
        if (notice.status)
            setAttemptStatus(notice.status);
        if (notice.error)
            showAttemptError(notice.error);
        else if (appliedOwnerError)
            clearAttemptError();
        appliedOwnerError = notice.error;
    }
    /** 生成与尝试两个位置共用同一份错误文本：错误就近显示在对应阶段。 */
    function showAttemptError(message) {
        showError(elements.generateError, message || "");
        showError(elements.attemptError, message || "");
    }
    function clearAttemptError() {
        clearError(elements.generateError);
        clearError(elements.attemptError);
    }
    /** 图像能力投影：只读 capabilities，不重算判定。 */
    function imageProviderBlock() {
        const caps = deps.capabilities();
        const images = caps && caps.images ? caps.images : null;
        return images && images.provider ? images.provider : null;
    }
    function attemptBadgeClass(state) {
        if (state === ATTEMPT_STATES.succeeded)
            return "is-attempt-done";
        if (state === ATTEMPT_STATES.failed)
            return "is-attempt-failed";
        if (state === ATTEMPT_STATES.unknown)
            return "is-attempt-unknown";
        return "is-attempt-active";
    }
    function shortTime(iso) {
        if (!iso)
            return "?";
        try {
            // Date 接受的输入是 string|number|Date；其余形状直接走下面的 String 回退。
            const date = new Date(iso);
            return date.toLocaleString("zh-CN", { hour12: false });
        }
        catch (error) {
            return String(iso);
        }
    }
    /** 当前 Prompt 指针：尝试的新旧依据比对输入（版本 + hash）。 */
    function currentPromptPointer(shotId) {
        const entry = promptRecordOf(shotId);
        return entry ? { version: entry.version, hash: entry.record.hash } : null;
    }
    /** 单张「保存候选图片」按钮入口：只翻译结果，不做批次策略。 */
    async function handleStoreCandidate(shotId) {
        clearAttemptError();
        const result = await generation.storeCandidate(shotId);
        if (result.stored) {
            // 报告摘要只读 adoption 的投影（确定性报告由 adoption 单向消费）；未建好就不显示摘要。
            const candidateId = result.candidate_id;
            const entry = candidateId ? selectionAdoption.reportOf(candidateId) : null;
            setAttemptStatus("候选已保存（" + result.width + "×" + result.height + "）。"
                + (entry ? " " + reviewSummaryText(entry.report) : ""));
        }
        else if (result.failed) {
            showAttemptError(result.message);
        }
        else if (result.reason === "already_stored") {
            setAttemptStatus("这条记录的候选已在本地，无需重复保存。");
        }
        else if (result.reason === "not_succeeded") {
            showAttemptError("这次生成还没有成功结论，暂不能保存候选。");
        }
        else if (result.reason === "no_task_id") {
            showAttemptError("这条记录没有任务编号，无法取回候选。");
        }
        else if (result.reason === "no_attempt") {
            showAttemptError("这张图还没有生成记录。");
        }
        return result;
    }
    /* ------------------------------------- 逐图任务列表（B4 冻结 A：唯一逐图列表） */
    /**
     * 当前图动作块的宿主：动态创建 `#workbench-current-actions` 挂在精看面板内部，
     * 位置在「完整报告」（#compare-checklist）之前、采用/返工动作之后——
     * 精看不因任务刷新重建，宿主只创建一次。
     */
    function ensureCurrentActionsHost() {
        const panel = elements.comparePanel || document.getElementById("compare-panel");
        if (!panel)
            return null;
        if (currentActionsHost && currentActionsHost.parentElement === panel)
            return currentActionsHost;
        let host = panel.querySelector("#workbench-current-actions");
        if (!host) {
            host = createElement("div", {
                className: "workbench-current-actions", attrs: { id: "workbench-current-actions" },
            });
            const checklist = panel.querySelector("#compare-checklist");
            if (checklist && checklist.parentElement === panel)
                panel.insertBefore(host, checklist);
            else
                panel.append(host);
        }
        currentActionsHost = host;
        return host;
    }
    /**
     * 待发送勾选判据：读的是 owner 当前 intent 的同一份范围与硬门排除项，
     * 不另建选择模型、不重算业务判定。
     */
    function sendScopeDecision(shotId, hasPrompt) {
        const intent = displayedGenerationIntent;
        const scope = explicitSendScope !== null ? explicitSendScope : (intent ? intent.scope : []);
        const checked = scope.includes(shotId);
        const excluded = Boolean(intent && intent.exclusions.some((item) => item.shot_id === shotId));
        const reason = !hasPrompt
            ? "这张图还没有可用的 Prompt：发送摘要会排除它。"
            : (excluded ? "当前依据有阻断或已过期：发送摘要会排除这张图。" : "");
        // 已经在范围里的图永远允许移出（即使被硬门排除），否则用户会被自己的一次勾选锁住。
        return { checked, disabled: (excluded || !hasPrompt) && !checked, reason };
    }
    /** 勾选/取消一张图的待发送范围：唯一入口；随后同一轮重算摘要与列表，视图不裁队列。 */
    function toggleSendScope(shotId, checked) {
        const base = explicitSendScope !== null
            ? explicitSendScope
            : (displayedGenerationIntent ? [...displayedGenerationIntent.scope] : []);
        const next = new Set(base);
        if (checked)
            next.add(shotId);
        else
            next.delete(shotId);
        explicitSendScope = [...next];
        renderConfirm();
        renderAttempts();
    }
    /** 采用状态徽标：身份 + 状态；完整摘要只进 title，不占列表版面。 */
    function adoptionBadge(entry, state) {
        const identity = entry && (state === "current" || state === "stale")
            ? " v" + entry.record.candidate_version : "";
        return {
            text: SELECTION_STATE_TEXT[state] + identity,
            className: state === "current" ? "is-adopted" : (state === "stale" ? "is-attempt-stale" : "is-missing"),
            title: selectionSummaryText(entry ? entry.record : null, state),
        };
    }
    function setTitle(node, text) {
        if (text)
            node.setAttribute("title", text);
        else
            node.removeAttribute("title");
    }
    /** 建一行：图名/任务状态徽标/采用状态徽标/原生标注的待发送勾选/查看入口。 */
    function createTaskRow(shotId) {
        const row = createElement("div", {
            className: "workbench-task attempt-row", attrs: { "data-shot-id": shotId, tabindex: "-1" },
        });
        const head = createElement("div", { className: "workbench-task-head" });
        const name = createElement("span", { className: "name" });
        const stateBadge = createElement("span", { className: "badge" });
        head.append(name, stateBadge);
        const meta = createElement("div", { className: "workbench-task-meta" });
        const adoption = createElement("span", { className: "badge" });
        meta.append(adoption);
        const actions = createElement("div", { className: "workbench-task-actions" });
        const checkId = "workbench-send-" + shotId;
        const check = createElement("input", { attrs: { id: checkId, type: "checkbox" } });
        const checkLabel = createElement("label", {
            className: "check", attrs: { for: checkId }, text: "待发送",
        });
        const view = createElement("button", {
            text: "查看", attrs: { type: "button", "data-compare-action": shotId },
        });
        // 查看只切换精看目标：不采用、不改待发送范围、不提交。
        view.addEventListener("click", (event) => { deps.openCompare(shotId, { focus: event.detail === 0 }); });
        check.addEventListener("change", () => { toggleSendScope(shotId, check.checked); });
        actions.append(check, checkLabel, view);
        row.append(head, meta, actions);
        return { row, name, stateBadge, adoptionBadge: adoption, check, checkLabel, view };
    }
    /**
     * 归位：同一节点集合只更新字段；只有真的乱序才移动节点。
     * 稳定态完全不动 DOM，因此焦点、勾选与滚动位置不会被异步渲染打断。
     */
    function placeTaskRow(nodes, previous) {
        const list = elements.attemptList;
        if (previous === null) {
            if (list.firstElementChild !== nodes.row)
                list.prepend(nodes.row);
        }
        else if (previous.nextElementSibling !== nodes.row) {
            list.insertBefore(nodes.row, previous.nextElementSibling);
        }
        return nodes.row;
    }
    function updateTaskRow(nodes, args) {
        nodes.name.textContent = args.label;
        nodes.row.setAttribute("data-attempt-state", args.stateKey);
        nodes.row.setAttribute("data-selection-state", args.selectionState);
        nodes.stateBadge.className = "badge " + args.stateClass;
        nodes.stateBadge.textContent = args.stateLabel;
        setTitle(nodes.stateBadge, args.title);
        nodes.adoptionBadge.className = "badge " + args.adoption.className;
        nodes.adoptionBadge.textContent = args.adoption.text;
        setTitle(nodes.adoptionBadge, args.adoption.title);
        if (args.isCurrent) {
            nodes.row.classList.add("is-current");
            nodes.row.setAttribute("aria-current", "true");
        }
        else {
            nodes.row.classList.remove("is-current");
            nodes.row.removeAttribute("aria-current");
        }
        // 勾选/禁用就地更新：焦点所在的勾选框不会被替换掉。
        if (nodes.check.checked !== args.decision.checked)
            nodes.check.checked = args.decision.checked;
        nodes.check.disabled = args.decision.disabled;
        nodes.check.setAttribute("aria-label", args.label + "：是否加入待发送范围");
        setTitle(nodes.check, args.decision.reason);
        setTitle(nodes.checkLabel, args.decision.reason);
        nodes.view.setAttribute("aria-pressed", String(args.isCurrent));
    }
    /** 窄屏选择器：选项集合变化才重建；文案变化就地更新，避免抢走键盘正在浏览的选择。 */
    function syncMobileShotSelect(options) {
        const select = elements.workbenchShotSelect;
        const signature = options.map((item) => item.shotId).join("|");
        if (signature !== mobileOptionSignature) {
            mobileOptionSignature = signature;
            select.replaceChildren(...options.map((item) => createElement("option", {
                attrs: { value: item.shotId }, text: item.text,
            })));
        }
        else {
            const nodes = Array.from(select.options);
            options.forEach((item, index) => {
                const option = nodes[index];
                if (option && option.textContent !== item.text)
                    option.textContent = item.text;
            });
        }
        const current = deps.currentShotId();
        // 有焦点时不动 value：键盘还在原生下拉里选图时，异步渲染不得改这个选择。
        if (current && !select.matches(":focus") && select.value !== current)
            select.value = current;
    }
    /** 窄屏「当前图加入待发送范围」：只切发送范围，不查看、不采用。 */
    function syncMobileSendCurrent(decision) {
        const box = elements.workbenchSendCurrent;
        if (!decision) {
            if (box.checked)
                box.checked = false;
            box.disabled = true;
            box.title = "先在逐图列表里选择一张图。";
            return;
        }
        if (box.checked !== decision.checked)
            box.checked = decision.checked;
        box.disabled = decision.disabled;
        box.title = decision.reason || "";
    }
    /**
     * 唯一逐图列表：每张图一行（图名/任务状态/采用状态/待发送勾选/查看），
     * 按 shot_id 键控就地更新；候选缩略图与报告正文不进列表，精看面板负责细节。
     */
    function renderAttempts() {
        const ready = Boolean(inputs.suitePlan());
        elements.attemptLocked.hidden = ready;
        elements.attemptEditor.hidden = !ready;
        if (!ready) {
            clearTaskList();
            clearCurrentActions();
            syncMobileShotSelect([]);
            syncMobileSendCurrent(null);
            setAttemptStatus("先在方案里添加图片任务。");
            renderBatch();
            deps.renderCompare();
            deps.renderSelectionProgress();
            return;
        }
        const summary = suitePlanSummary(inputs.suitePlan(), inputs.suiteContext());
        const confirmed = confirmationIsCurrent();
        const provider = imageProviderBlock();
        elements.attemptProvider.textContent = provider
            ? "图像 provider：" + (provider.provider_id || "未声明") + " · " + (provider.model_id || "未声明")
                + (provider.configured === false ? " · 未配置（提交会被拒绝，不会调用模型）" : " · 已配置")
            : "图像 provider：尚未读到能力信息；提交前请确认服务端可用。";
        const counts = { total: 0, none: 0, active: 0, succeeded: 0, failed: 0, unknown: 0 };
        const shots = summary ? summary.shots : [];
        const currentShotId = deps.currentShotId();
        const planSignature = shots.map((item) => item.shot_id).join("|");
        const mobileOptions = [];
        const seen = new Set();
        let previous = null;
        let autoOpenShotId = null;
        for (const [index, item] of shots.entries()) {
            const shotId = item.shot_id;
            seen.add(shotId);
            const chain = generation.attemptChainOf(shotId);
            const latest = generation.latestAttemptOf(shotId);
            const record = latest ? latest.record : null;
            const state = record ? record.state : null;
            const entry = promptRecordOf(shotId);
            const stale = record ? attemptPromptStaleness(record, currentPromptPointer(shotId)) : null;
            counts.total += 1;
            if (!record)
                counts.none += 1;
            else if (state === ATTEMPT_STATES.succeeded)
                counts.succeeded += 1;
            else if (state === ATTEMPT_STATES.failed)
                counts.failed += 1;
            else if (state === ATTEMPT_STATES.unknown)
                counts.unknown += 1;
            else
                counts.active += 1;
            let nodes = taskRows.get(shotId);
            if (!nodes) {
                nodes = createTaskRow(shotId);
                taskRows.set(shotId, nodes);
            }
            const stateLabel = record ? attemptStateLabel(state) : "尚未生成";
            const selectionState = selectionAdoption.stateOf(shotId);
            const attemptTitle = [
                entry ? "Prompt v" + entry.version : "Prompt 未编译",
                record ? "action " + record.action_id : "",
                record && record.task_id ? "task " + record.task_id : "",
                stale && stale.stale ? "基于旧版本 v" + String(stale.attempt_version) : "",
            ].filter(Boolean).join(" · ");
            updateTaskRow(nodes, {
                label: item.label,
                stateLabel,
                stateClass: record ? attemptBadgeClass(state) : "is-missing",
                stateKey: record && state ? state : "none",
                title: attemptTitle,
                adoption: adoptionBadge(selectionAdoption.entryOf(shotId), selectionState),
                selectionState,
                decision: sendScopeDecision(shotId, Boolean(entry)),
                isCurrent: shotId === currentShotId,
            });
            previous = placeTaskRow(nodes, previous);
            mobileOptions.push({
                shotId,
                text: item.label + " · " + stateLabel + " · " + SELECTION_STATE_TEXT[selectionState],
            });
            if (shotId === currentShotId) {
                renderCurrentActions({
                    shotId, label: item.label, order: index + 1, record, state, entry, chain, stale,
                });
            }
            if (!currentShotId && !autoOpenShotId)
                autoOpenShotId = shotId;
        }
        for (const [shotId, nodes] of taskRows) {
            if (seen.has(shotId))
                continue;
            nodes.row.remove();
            taskRows.delete(shotId);
        }
        if (!currentShotId || !seen.has(currentShotId))
            clearCurrentActions();
        syncMobileShotSelect(mobileOptions);
        syncMobileSendCurrent(currentShotId
            ? sendScopeDecision(currentShotId, Boolean(promptRecordOf(currentShotId)))
            : null);
        const activeText = counts.active > 0 ? "进行中 " + counts.active + " 张；" : "";
        setAttemptStatus("共 " + counts.total + " 张；未生成 " + counts.none + " 张；"
            + activeText + "已成功 " + counts.succeeded + " 张；结果未知 " + counts.unknown + " 张；失败 "
            + counts.failed + " 张。" + (confirmed ? "可以整套生成或逐张提交。" : "确认缺失或已过期，暂不能提交。"));
        renderBatch();
        deps.renderCompare();
        deps.renderSelectionProgress();
        deps.refreshDerived();
        // 常驻精看默认看第一张由 renderCompare 承担；这里只在用户已停靠制作与审图时才把
        // 第一次出现的新计划选入精看并停靠——不在方案/资料段把用户拽走（外壳 keep-task 规则）。
        const generateVisible = elements.attemptList.offsetParent !== null;
        if (!currentShotId && autoOpenShotId && autoOpenSignature !== planSignature && generateVisible) {
            autoOpenSignature = planSignature;
            deps.openCompare(autoOpenShotId, { focus: false });
        }
    }
    /** 列表行全清（计划缺失/换项目）：节点按 shot_id 键控，清空时同步释放引用。 */
    function clearTaskList() {
        for (const [shotId, nodes] of taskRows) {
            nodes.row.remove();
            taskRows.delete(shotId);
        }
    }
    /** 当前图动作块清空：宿主本身保留（精看容器不随任务刷新重建）。 */
    function clearCurrentActions() {
        if (currentActions) {
            currentActions.setCredentialTarget(null);
            currentActions = null;
        }
        if (currentActionsHost)
            currentActionsHost.replaceChildren();
    }
    /** 建立/复用当前图动作块：同一张图内就地更新，换图才重建节点。 */
    function ensureCurrentActions(shotId) {
        const host = ensureCurrentActionsHost();
        if (!host)
            return null;
        if (currentActions && currentActions.shotId === shotId && currentActions.host === host)
            return currentActions;
        host.replaceChildren();
        const heading = createElement("p", { className: "meta workbench-current-head" });
        const tech = createElement("details", { className: "tech-details" });
        const techBody = createElement("p", { className: "meta" });
        tech.append(createElement("summary", { text: "技术详情" }), techBody);
        const note = createElement("p", { className: "meta attempt-note", attrs: { hidden: "hidden" } });
        const error = createElement("p", { className: "attempt-error-text", attrs: { hidden: "hidden" } });
        const toolbar = createElement("div", { className: "toolbar attempt-actions" });
        const submit = createElement("button", {
            className: "primary", text: "生成这张图", attrs: { type: "button" },
        });
        const nextAction = createElement("button", { attrs: { type: "button", hidden: "hidden" } });
        const reconcile = createElement("button", { text: "核对任务", attrs: { type: "button", hidden: "hidden" } });
        const credentials = createElement("button", {
            attrs: { type: "button", hidden: "hidden", "data-original-credentials": shotId },
        });
        const store = createElement("button", {
            className: "primary", text: "保存候选图片", attrs: { type: "button", hidden: "hidden" },
        });
        const history = createElement("details", { className: "attempt-history", attrs: { hidden: "hidden" } });
        let credentialTarget = null;
        // 入口仍只走本视图既有的私有命令方法：不复制业务逻辑、不新增动作。
        submit.addEventListener("click", () => { void handleSubmitAttempt(shotId); });
        nextAction.addEventListener("click", () => { void handleSubmitAttempt(shotId, { explicitNew: true }); });
        reconcile.addEventListener("click", () => { void handleReconcileAttempt(shotId); });
        store.addEventListener("click", () => { void handleStoreCandidate(shotId); });
        credentials.addEventListener("click", () => {
            if (!credentialTarget)
                return;
            modelSettings.open("image", credentialTarget.byok ? credentialTarget.providerId : undefined);
        });
        toolbar.append(submit, nextAction, reconcile, credentials, store);
        host.append(heading, tech, note, error, toolbar, history);
        currentActions = {
            shotId, host, heading, techBody, note, error, submit, nextAction, reconcile, credentials, store, history,
            historySignature: "",
            setCredentialTarget: (target) => { credentialTarget = target; },
        };
        return currentActions;
    }
    /**
     * 当前图的动作块：提交、新建 action、核对原任务、取回候选只对当前正在看的那张图生效，
     * 全部复用既有 owner 命令；这里只把状态翻译成可用态与就近说明。
     */
    function renderCurrentActions(args) {
        const nodes = ensureCurrentActions(args.shotId);
        if (!nodes)
            return;
        const record = args.record;
        const state = args.state;
        const parts = ["当前图：" + args.order + ". " + args.label];
        parts.push(record ? attemptStateLabel(state) : "尚未生成");
        if (record) {
            parts.push("提交 " + shortTime(record.created_at));
            if (record.updated_at !== record.created_at)
                parts.push("更新 " + shortTime(record.updated_at));
            if (record.task_id)
                parts.push("task " + record.task_id);
        }
        nodes.heading.textContent = parts.join(" · ");
        nodes.techBody.textContent = [
            "action " + (record ? record.action_id : "无"),
            args.entry
                ? "Prompt v" + args.entry.version + " · hash " + args.entry.record.hash.slice(0, 12) + "…"
                : "Prompt 未编译",
            args.stale && args.stale.stale ? "本记录依据 Prompt v" + String(args.stale.attempt_version) : "",
        ].filter(Boolean).join(" · ");
        const batchState = generation.batchStateReader();
        const batchActive = Boolean(batchState && batchState.active);
        const inFlight = generation.isAttemptInFlight(args.shotId) || inputs.isAnalysisRunning() || batchActive;
        const shotConfirmed = confirmationIsCurrentForShot(args.shotId);
        const canSubmit = shotConfirmed && Boolean(args.entry) && !inFlight;
        const reconcileMode = record ? attemptReconcileMode(record) : ATTEMPT_RECONCILE_MODES.none;
        const stuckPending = Boolean(state === ATTEMPT_STATES.pending_submit && record && !record.task_id);
        const activeState = Boolean(record && state && ATTEMPT_ACTIVE_STATES.includes(state));
        let gate = ATTEMPT_RECONCILE_MODES.none;
        if (record && reconcileMode === ATTEMPT_RECONCILE_MODES.by_task) {
            const environment = attemptCurrentEnvironmentIdentity(modelSettings.imageEnvironment(record.provider.provider_id, record.execution_identity.credential_reference.source));
            gate = attemptReconcileEnvironment(record, environment).mode;
        }
        // 按任务编号核对仍受冻结执行身份约束：环境不匹配时只给补原凭据入口，不发核对。
        const canReconcile = Boolean(record && reconcileMode === ATTEMPT_RECONCILE_MODES.by_task
            && gate === ATTEMPT_RECONCILE_MODES.by_task);
        const blockedReconcile = Boolean(record && reconcileMode === ATTEMPT_RECONCILE_MODES.by_task
            && gate !== ATTEMPT_RECONCILE_MODES.by_task);
        // 候选与本地字节：只说明本图状态与恢复入口，不复述报告正文。
        let storeAvailable = false;
        const notes = [];
        if (record && state === ATTEMPT_STATES.succeeded) {
            const stored = generation.candidateForAttemptOf(args.shotId, record.action_id);
            if (stored && candidateMatchesAttempt(stored, record)) {
                const candidate = stored.record;
                notes.push("候选已保存到本地 · " + candidate.width + "×" + candidate.height + " · "
                    + candidate.media_type + " · " + Math.max(1, Math.round(candidate.byte_size / 1024))
                    + " KB（sha256 " + candidate.asset_sha256.slice(0, 12) + "…）");
            }
            else if (stored) {
                notes.push("候选记录与来源 Attempt 不一致：不显示预览；记录与本地字节保留，等待复核。");
            }
            else {
                notes.push("上游已完成，候选字节尚未保存到本地。");
                storeAvailable = true;
            }
        }
        const lastNote = record && record.change_log.length
            ? record.change_log[record.change_log.length - 1].note : null;
        if (lastNote)
            notes.push("最近一次变化：" + lastNote);
        if (stuckPending || Boolean(state === ATTEMPT_STATES.unknown && record && !record.task_id)) {
            notes.push("这次提交没有留下任务编号（可能已到达上游）。系统不会自动重提；可以显式新建 action，或先核对（若已有编号）。");
        }
        if (args.stale && args.stale.stale) {
            notes.push("这条记录基于 Prompt v" + String(args.stale.attempt_version) + "；当前是 v"
                + String(args.stale.current_version) + "。要按新版出图，请先重新确认，再新建 action。");
        }
        if (!shotConfirmed) {
            notes.push("这张图还没有有效的生成前确认：先在「生成前确认」确认整套，或走一次返工确认。");
        }
        else if (!args.entry) {
            notes.push("先编译并保存这张图的 Prompt。");
        }
        if (blockedReconcile && record)
            notes.push(attemptReconcileBlockedMessage(record));
        nodes.note.hidden = notes.length === 0;
        nodes.note.textContent = notes.join(" ");
        if (record && record.error) {
            nodes.error.hidden = false;
            nodes.error.textContent = (state === ATTEMPT_STATES.unknown ? "未知原因：" : "失败原因：")
                + record.error.family + " / " + record.error.code + "：" + record.error.message
                + "（重试策略 " + record.error.retry_policy + "）";
        }
        else {
            nodes.error.hidden = true;
            nodes.error.textContent = "";
        }
        nodes.submit.hidden = Boolean(record);
        nodes.submit.disabled = !canSubmit;
        let nextLabel = "";
        if (record) {
            if (activeState && !stuckPending)
                nextLabel = inFlight ? "提交中…" : "上游处理中，先核对";
            else if (stuckPending || state === ATTEMPT_STATES.unknown)
                nextLabel = "新建 action（放弃核对）";
            else if (state === ATTEMPT_STATES.failed)
                nextLabel = "重试（新建 action）";
            else if (state === ATTEMPT_STATES.succeeded)
                nextLabel = "再生成一张（新建 action）";
        }
        nodes.nextAction.hidden = nextLabel === "";
        nodes.nextAction.textContent = nextLabel;
        // 进行中只给只读状态：不提供任何可能重复消费授权的入口；无任务编号的卡住 pending
        // 例外（系统不会自动重提，用户只能显式新建 action）。
        nodes.nextAction.disabled = (activeState && !stuckPending) || !args.entry || inFlight;
        nodes.reconcile.hidden = !record || reconcileMode !== ATTEMPT_RECONCILE_MODES.by_task;
        nodes.reconcile.disabled = inFlight || !canReconcile;
        nodes.credentials.hidden = !blockedReconcile;
        if (blockedReconcile && record) {
            const byok = record.execution_identity.credential_reference.source === "byok";
            nodes.credentials.textContent = byok ? "给原目标补凭据" : "查看原目标配置";
            nodes.setCredentialTarget({ byok, providerId: record.provider.provider_id });
        }
        else {
            nodes.setCredentialTarget(null);
        }
        // 批次运行中也要能用：取回失败时提示区正让用户点这个按钮，而它只做本地保存，
        // 同一张的并发保存由 isCandidateInFlight 挡住（模块内直接 no-op）。
        nodes.store.hidden = !storeAvailable;
        nodes.store.disabled = generation.isAttemptInFlight(args.shotId)
            || inputs.isAnalysisRunning() || generation.isCandidateInFlight(args.shotId);
        // 历史只在链签名变化时重建；同一份历史不为每次渲染重排 DOM。
        if (args.chain.length > 1) {
            const signature = args.chain
                .map((item) => item.version + ":" + item.record.state + ":" + item.record.updated_at).join("|");
            nodes.history.hidden = false;
            if (signature !== nodes.historySignature) {
                nodes.historySignature = signature;
                nodes.history.replaceChildren(createElement("summary", { text: "历史 " + args.chain.length + " 条状态记录（提交与核对均追加保留）" }), ...args.chain.slice().reverse().map((item) => createElement("p", {
                    className: "attempt-history-row",
                    text: "v" + item.version + " · " + attemptStateLabel(item.record.state)
                        + " · action " + item.record.action_id
                        + (item.record.task_id ? " · task " + item.record.task_id : "")
                        + " · " + shortTime(item.record.updated_at),
                })));
            }
        }
        else {
            nodes.history.hidden = true;
            nodes.historySignature = "";
            nodes.history.replaceChildren();
        }
    }
    /** 单张提交（按钮入口）：只负责把核心结果翻译成界面反馈，执行顺序在生成 Module。 */
    async function handleSubmitAttempt(shotId, options = {}) {
        if (!shotId)
            return;
        const action = options.action || beginAction();
        if (options.explicitNew) {
            generation.enterExplicitNew(shotId);
            // owner 已按这张图选定 scope/mode：视图的显式待发送范围不再适用，先交还给 owner。
            explicitSendScope = null;
            deps.selectStage("generate");
            renderConfirm();
            elements.confirmAction.focus();
            return;
        }
        clearAttemptError();
        const outcome = await generation.submitAttempt(shotId, { ...options, action });
        if (!action.alive())
            return outcome;
        if (outcome.skipped) {
            if (outcome.reason === "no_confirmation") {
                showAttemptError("生成前确认缺失或已过期：先回到「生成前确认」重新确认，再提交。");
            }
            else if (outcome.reason === "blocked") {
                const blocking = outcome.blocking;
                if (blocking) {
                    showAttemptError("同一张图已经有一条进行中的生成（"
                        + attemptStateLabel(blocking.state) + "，action " + blocking.action_id
                        + "）。先核对并按结论处理，再新建 action。");
                }
            }
            else if (outcome.reason === "no_prompt") {
                showAttemptError("这张图还没有可用的 Prompt 版本：先编译并保存。");
            }
            else if (outcome.reason === "shot_missing") {
                showAttemptError("这张图已不在套图方案里，先刷新套图规划。");
            }
            else if (outcome.reason === "no_references") {
                showAttemptError("这张图没有可用参考图（至少需要一张）。");
            }
            else if (outcome.reason === "reference_read_failed") {
                showAttemptError(outcome.message);
            }
            else if (outcome.reason === "environment_unknown") {
                showAttemptError(outcome.message
                    || "提交前读不到有效的图像环境身份；不猜身份，先确认服务端可用。");
            }
            return outcome;
        }
        if (outcome.thrown) {
            showAttemptError(outcome.message);
            return outcome;
        }
        const record = outcome.record;
        if (!record)
            return outcome;
        setAttemptStatus("action " + record.action_id + "：" + attemptStateLabel(record.state)
            + (record.task_id ? "（task " + record.task_id + "）" : "") + "。");
        if (record.state === ATTEMPT_STATES.unknown) {
            showAttemptError("这次提交的结果没有确认：不要重复提交。"
                + (record.task_id ? "可以按任务编号核对。" : "没有任务编号，只能显式新建 action。"));
        }
        else if (record.state === ATTEMPT_STATES.failed && record.error) {
            showAttemptError("这次提交明确失败：" + record.error.message
                + "（重试策略 " + record.error.retry_policy + "）。");
        }
        if (outcome.candidate && outcome.candidate.failed) {
            showAttemptError(outcome.candidate.message);
        }
        else if (outcome.candidate && outcome.candidate.stored && outcome.candidate.sha256) {
            setAttemptStatus(elements.attemptStatus.textContent + " 候选已保存到本地（sha256 "
                + outcome.candidate.sha256.slice(0, 12) + "…）。");
        }
        return outcome;
    }
    /** 单张核对（按钮入口）：只负责把核心结果翻译成界面反馈，执行顺序在生成 Module。 */
    async function handleReconcileAttempt(shotId, options = {}) {
        if (!shotId)
            return;
        const action = options.action || beginAction();
        clearAttemptError();
        const result = await generation.reconcileAttempt(shotId, { ...options, action });
        if (!action.alive())
            return result;
        if (result.skipped) {
            if (result.reason === "no_task") {
                showAttemptError("这条记录没有任务编号，无法核对；只能显式新建 action。");
            }
            else if (result.reason === "environment_blocked") {
                showAttemptError(result.message || "当前环境与冻结身份不一致，未发出核对请求。");
            }
            else if (result.reason === "no_identity") {
                showAttemptError(result.message || "这条 Attempt 没有冻结执行身份，不能按原身份核对。");
            }
            return result;
        }
        if (result.failed) {
            showAttemptError(result.message);
            return result;
        }
        if (result.advanced) {
            setAttemptStatus("已核对 task " + result.task_id + "："
                + attemptStateLabel(result.state) + "。");
            if (result.candidate && result.candidate.failed) {
                showAttemptError(result.candidate.message);
            }
            else if (result.candidate && result.candidate.stored && result.candidate.sha256) {
                setAttemptStatus(elements.attemptStatus.textContent + " 候选已保存到本地（sha256 "
                    + result.candidate.sha256.slice(0, 12) + "…）。");
            }
        }
        else {
            setAttemptStatus("已核对 task " + result.task_id + "：没有新结论（"
                + result.note + "）。");
        }
        return result;
    }
    function renderBatch() {
        if (!elements.batchBar)
            return;
        const ready = Boolean(inputs.suitePlan());
        elements.batchBar.hidden = !ready;
        if (!ready)
            return;
        const state = generation.deriveBatch();
        const batchState = generation.batchStateReader();
        const running = Boolean(batchState && batchState.active);
        const confirmed = confirmationIsCurrent();
        const progress = [batchProgressText(state)];
        if (running && batchState) {
            if (batchState.phase === "poll") {
                progress.push("批次进行中：正在按任务编号核对上游进度");
            }
            else {
                progress.push(batchState.currentShotId
                    ? "批次进行中：正在提交「" + deps.shotLabelOf(batchState.currentShotId) + "」"
                    : "批次进行中");
            }
        }
        if (batchState && batchState.halted) {
            progress.push("已停止新增提交（" + batchState.haltReason + "）；已提交的记录全部保留");
        }
        if (batchState && batchState.stopped) {
            progress.push("已停止新增提交；已提交的记录全部保留");
        }
        elements.batchProgress.textContent = progress.join("；") + "。";
        const hints = [];
        if (!confirmed)
            hints.push("生成前确认缺失或已过期：先回到「生成前确认」重新确认。");
        if (state.counts.blocked_no_prompt > 0) {
            hints.push("有 " + state.counts.blocked_no_prompt + " 张还没编译 Prompt。");
        }
        if (state.review_queue.length > 0) {
            hints.push("有 " + state.review_queue.length
                + " 张没有任务编号、无法核对：系统不会自动重提，需要显式新建 action。");
        }
        if (state.fetch_queue.length > 0) {
            hints.push("有 " + state.fetch_queue.length
                + " 张已生成但候选还没保存到本地：可以点「保存候选图片」逐张保存，或点「保存候选」一次保存剩余。");
        }
        if (batchState && batchState.fetchBlocked) {
            hints.push("候选保存受阻：" + batchState.fetchBlocked);
        }
        if (batchState && batchState.fetchNotice && !batchState.fetchBlocked) {
            hints.push(batchState.fetchNotice + "候选记录保持原样，可以点「保存候选图片」重试。");
        }
        elements.batchHint.textContent = hints.join(" ");
        elements.batchHint.hidden = hints.length === 0;
        elements.queueList.replaceChildren();
        // 队列只给状态文字摘要（B4：不再在这里铺候选/逐图卡）；pending/current/targetMatched 归 generation.queues()。
        for (const { queue, pending, current, targetMatched: matched } of generation.queues()) {
            if (!pending.length)
                continue;
            const target = queue.payload.fingerprint.snapshot.execution_target;
            if (!target)
                continue;
            const row = createElement("div", { className: "generation-queue" });
            row.append(createElement("p", {
                className: "meta", text: "原队列 v" + queue.version + " · " + target.model_id + " · "
                    + target.protocol + " · 凭据 " + target.credential_source + " · 尚未提交 " + pending.length
                    + " 张（当前依据有效 " + current.length + " 张）：" + pending.map((shotId) => deps.shotLabelOf(shotId)).join("、")
                    + "。" + String(queue.payload.external_summary.statement),
            }));
            const resume = createElement("button", { text: "按原摘要继续未提交队列", attrs: { type: "button" } });
            resume.disabled = running || submissionInFlight || !matched || !current.length;
            resume.addEventListener("click", () => { void generation.runBatch({ confirmation: queue }); });
            const credentials = createElement("button", { text: "给原目标补凭据", attrs: { type: "button" } });
            credentials.addEventListener("click", () => modelSettings.open("image", target.provider_id));
            row.append(resume, credentials);
            elements.queueList.append(row);
        }
        elements.batchStop.hidden = !running;
        elements.batchReconcile.hidden = state.reconcile_queue.length === 0;
        elements.batchReconcile.disabled = running || state.reconcile_queue.length === 0;
        elements.batchReconcile.textContent = "核对进行中（" + state.reconcile_queue.length + " 张）";
        elements.batchRetry.hidden = state.retry_queue.length === 0;
        elements.batchRetry.disabled = running || state.retry_queue.length === 0;
        elements.batchRetry.textContent = "查看失败图的重试摘要（" + state.retry_queue.length + " 张）";
    }
    /** 生成/确认/尝试三区同轮刷新：全量渲染与输入侧命令收尾共用一处，避免三份写法。 */
    function render() {
        renderPrompts();
        renderConfirm();
        renderAttempts();
    }
    return {
        renderPrompts,
        prepareSystemPrompts,
        handleCompilePrompt,
        handleSaveEditedPrompt,
        handleReconfirmManualPrompt,
        handleDiscardManualPrompt,
        promptRecordOf,
        currentImageProfile,
        promptCurrentBasis,
        renderConfirm,
        handleConfirmGeneration,
        confirmationIsCurrent,
        confirmationIsCurrentForShot,
        queueShotIsCurrent,
        isSubmitting: () => submissionInFlight,
        render,
        renderAttempts,
        renderBatch,
        applyNotice,
        showAttemptError,
        shortTime,
    };
}
