商品套图交付包

项目：蜂蜜玻璃罐·人工事实无AI复核
生成时间：2026-10-08T07:19:50.365Z
包含图片：4 张（每张一个已采用候选）

清单：
- 主图·干净背景：images/shot_main_clean-act-e67c7dd57f1b41d6a4925d1445a39c15.png（candidate act-e67c7dd57f1b41d6a4925d1445a39c15 · sha256 aacabc44f2d0…）
- 卖点信息图：images/shot_infographic_benefits-act-77d17b8e91ee4c92809c0e39ca91b920.png（candidate act-77d17b8e91ee4c92809c0e39ca91b920 · sha256 7247b9d8809c…）
- 场景图·使用中：images/shot_scene_lifestyle-act-3235b3c73a5d4c75b1a8a835fc603b16.png（candidate act-3235b3c73a5d4c75b1a8a835fc603b16 · sha256 8747ecd95851…）
- 细节图·材质工艺：images/shot_detail_material-act-860d41d7ca8c48b49188a3c4fef31a83.png（candidate act-860d41d7ca8c48b49188a3c4fef31a83 · sha256 2049eaa87a36…）

manifest.json 记录每张图的来源与指纹；checks.json 记录门禁与审核发现。
本包只包含已采用的候选；未采用候选与完整历史请用「导出项目包」。