商品套图交付包

项目：正式开发—人工套图主链
生成时间：2026-10-05T11:44:19.808Z
包含图片：2 张（每张一个已采用候选）

清单：
- 主图·干净背景：images/shot_main_clean-act-144e4fba7b214ffdadecf9453e7b02ad.png（candidate act-144e4fba7b214ffdadecf9453e7b02ad · sha256 9d34b3e53e06…）
- 场景图·使用中：images/shot_scene_lifestyle-act-73499842a25441c6be9a3f48d9205923.png（candidate act-73499842a25441c6be9a3f48d9205923 · sha256 63aac5275511…）

manifest.json 记录每张图的来源与指纹；checks.json 记录门禁与审核发现。
本包只包含已采用的候选；未采用候选与完整历史请用「导出项目包」。